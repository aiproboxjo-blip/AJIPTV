#!/usr/bin/env bash
# Builds the FFmpeg audio decoders (AC3, E-AC3, DTS, TrueHD, AAC, MP3, ...) for ExoPlayer FROM SOURCE,
# the official way (androidx/media: libraries/decoder_ffmpeg + build_ffmpeg.sh, FFmpeg 6.0, no GPL flags).
# Everything stays in media3-src/ and is used by the ":ffmpeg-module" Gradle project.
# usage: bash build-ffmpeg.sh <media3 version, e.g. 1.4.1>
set -eu
MEDIA3_VER="${1:-1.4.1}"
HOST=linux-x86_64
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
NDK_VER="26.1.10909125"          # NDK r26b, the version the media3 docs recommend

echo "== installing NDK $NDK_VER and CMake"
yes | "$SDKM" --licenses > /dev/null 2>&1 || true
yes | "$SDKM" --install "ndk;$NDK_VER" "cmake;3.22.1" > /dev/null
NDK="$SDK/ndk/$NDK_VER"
[ -d "$NDK" ] || { echo "NDK not found at $NDK"; exit 1; }

echo "== fetching media3 $MEDIA3_VER sources and FFmpeg 6.0"
rm -rf media3-src
git clone --depth 1 --branch "$MEDIA3_VER" https://github.com/androidx/media.git media3-src
MODULE="$PWD/media3-src/libraries/decoder_ffmpeg/src/main"
git clone --depth 1 --branch release/6.0 https://github.com/FFmpeg/FFmpeg.git "$MODULE/jni/ffmpeg"

echo "== building FFmpeg decoders"
cd "$MODULE/jni"
chmod +x build_ffmpeg.sh
./build_ffmpeg.sh "$MODULE" "$NDK" "$HOST" 21 \
  vorbis opus flac alac pcm_mulaw pcm_alaw mp3 amrnb amrwb aac ac3 eac3 dca mlp truehd

echo "== done"
ls -la "$MODULE/jni/ffmpeg/android-libs" || true

// The official media3 FFmpeg extension, compiled from the sources that build-ffmpeg.sh fetched
// (media3-src/libraries/decoder_ffmpeg) together with the FFmpeg libraries it built.
plugins { id("com.android.library") }

val media3 = (project.findProperty("media3") as String?) ?: "1.4.1"
val src = "../media3-src/libraries/decoder_ffmpeg/src/main"

android {
    namespace = "androidx.media3.decoder.ffmpeg"
    compileSdk = 34
    defaultConfig {
        minSdk = 21
        ndk { abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a")) }
    }
    sourceSets {
        getByName("main") {
            java.srcDir("$src/java")
            manifest.srcFile("$src/AndroidManifest.xml")
        }
    }
    externalNativeBuild {
        cmake {
            path = file("$src/jni/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-decoder:$media3")
    implementation("androidx.annotation:annotation:1.8.0")
    compileOnly("org.checkerframework:checker-qual:3.43.0")
}

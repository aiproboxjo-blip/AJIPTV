package com.aj.iptv.player

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.net.Uri
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.BehindLiveWindowException
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.aj.iptv.Img
import java.util.Locale

/** Builds Xtream Codes stream URLs. */
object Xtream {
    var HOST = "Maveniptv.tv"
    var PORT = 2095

    fun live(user: String, pass: String, streamId: String, ext: String = "m3u8") =
        "http://$HOST:$PORT/live/$user/$pass/$streamId.$ext"

    fun movie(user: String, pass: String, id: String, ext: String = "mp4") =
        "http://$HOST:$PORT/movie/$user/$pass/$id.$ext"

    fun episode(user: String, pass: String, id: String, ext: String = "mp4") =
        "http://$HOST:$PORT/series/$user/$pass/$id.$ext"
}

/** Playlist handed from the lists to the player (same process, no Intent size limits). */
object PlayQueue {
    var urls: List<String> = emptyList()
    var names: List<String> = emptyList()
    var icons: List<String> = emptyList()
}

/**
 * One ExoPlayer reused for every channel (fast zapping), buffer sized by preset,
 * short network timeouts, automatic retry.
 */
@OptIn(UnstableApi::class)
class AjPlayer(
    context: Context, live: Boolean, buf: Int, tunnel: Boolean = false,
    maxQuality: Boolean = false, ffPrefer: Boolean = false, seekMs: Long = 10_000L
) {

    enum class State { LOADING, PLAYING, ERROR, ENDED }

    var onState: ((State) -> Unit)? = null
    var lastError: PlaybackException? = null
    @Volatile var videoDecoder: String = ""
    @Volatile var audioDecoder: String = ""

    private var currentUrl: String? = null
    private var retries = 0

    private val http = DefaultHttpDataSource.Factory()
        .setUserAgent("AJIPTV/2.0")
        .setConnectTimeoutMs(8_000)
        .setReadTimeoutMs(8_000)
        .setAllowCrossProtocolRedirects(true)

    private val b = buf.coerceIn(0, 2)

    private val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            if (live) intArrayOf(15_000, 25_000, 40_000)[b] else intArrayOf(25_000, 40_000, 60_000)[b],
            if (live) intArrayOf(30_000, 50_000, 80_000)[b] else intArrayOf(50_000, 70_000, 90_000)[b],
            1_000,
            2_500
        )
        .setTargetBufferBytes(intArrayOf(40, 80, 128)[b] * 1024 * 1024)
        .setPrioritizeTimeOverSizeThresholds(false)
        .build()

    // Adaptive quality by default; "max quality" forces the highest variant. Prefer AAC/MP3 audio when several tracks exist.
    private val selector = DefaultTrackSelector(context.applicationContext).also {
        it.parameters = it.buildUponParameters()
            .setForceHighestSupportedBitrate(maxQuality)
            .setTunnelingEnabled(tunnel)
            .setPreferredAudioMimeTypes(MimeTypes.AUDIO_AAC, MimeTypes.AUDIO_MPEG)
            .build()
    }

    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext)
        .setTrackSelector(selector)
        .setMediaSourceFactory(DefaultMediaSourceFactory(http))
        .setLoadControl(loadControl)
        .setRenderersFactory(
            Renderers.create(context.applicationContext)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(
                    if (ffPrefer && !Renderers.nextAvailable()) DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                    else DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
                )
        )
        .setAudioAttributes(AudioAttributes.DEFAULT, true)
        .setHandleAudioBecomingNoisy(true)
        .setSeekBackIncrementMs(seekMs)
        .setSeekForwardIncrementMs(seekMs)
        .build()
        .also { it.playWhenReady = true }

    init {
        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onVideoDecoderInitialized(
                eventTime: AnalyticsListener.EventTime, decoderName: String,
                initializedTimestampMs: Long, initializationDurationMs: Long
            ) {
                videoDecoder = decoderName
            }

            override fun onAudioDecoderInitialized(
                eventTime: AnalyticsListener.EventTime, decoderName: String,
                initializedTimestampMs: Long, initializationDurationMs: Long
            ) {
                audioDecoder = decoderName
            }
        })
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> onState?.invoke(State.LOADING)
                    Player.STATE_READY -> { retries = 0; onState?.invoke(State.PLAYING) }
                    Player.STATE_ENDED -> onState?.invoke(State.ENDED)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                lastError = error
                if (error.cause is BehindLiveWindowException) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                if (retries < 3) {
                    retries++
                    player.prepare()
                } else {
                    onState?.invoke(State.ERROR)
                }
            }
        })
    }

    fun play(url: String, startMs: Long = 0L) {
        if (url == currentUrl && startMs == 0L && player.playbackState != Player.STATE_IDLE) return
        currentUrl = url
        retries = 0
        onState?.invoke(State.LOADING)
        player.setMediaItem(MediaItem.fromUri(url), if (startMs > 0L) startMs else C.TIME_UNSET)
        player.prepare()
    }

    fun stop() = player.stop()
    fun pause() = player.pause()
    fun resume() = player.play()
    fun release() = player.release()
}

/** Seek (forward / rewind) helpers shared by both players. */
object Seek {
    fun stepMs(prefs: SharedPreferences): Long = prefs.getInt("seekStep", 10).coerceIn(5, 120) * 1000L

    /** Holding the key makes the jump bigger: x3 after a few repeats, x6 after many. */
    fun accelerate(base: Long, repeat: Int): Long = when {
        repeat >= 12 -> base * 6
        repeat >= 5 -> base * 3
        else -> base
    }

    fun label(ms: Long): String =
        if (ms >= 60_000L && ms % 60_000L == 0L) "${ms / 60_000L}د" else "${ms / 1000L}ث"

    fun time(ms: Long): String {
        val s = ms / 1000L
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val sec = s % 60L
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }
}

/** Reaches the optional in-app VLC engine without a compile-time dependency on it. */
object VlcBridge {
    const val CLASS = "com.aj.iptv.player.VlcActivity"
    fun available(): Boolean = try {
        Class.forName(CLASS); true
    } catch (e: Throwable) {
        false
    }
}

/**
 * NextLib (io.github.anilbeesetti:nextlib-media3ext) adds FFmpeg decoders (AC3, E-AC3, DTS, TrueHD, ...)
 * to ExoPlayer through NextRenderersFactory, a drop-in DefaultRenderersFactory. Loaded by reflection.
 */
object Renderers {
    const val NEXT = "io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory"

    fun nextAvailable(): Boolean = try {
        Class.forName(NEXT); true
    } catch (e: Throwable) {
        false
    }

    fun create(ctx: Context): DefaultRenderersFactory = try {
        Class.forName(NEXT).getConstructor(Context::class.java).newInstance(ctx) as DefaultRenderersFactory
    } catch (e: Throwable) {
        DefaultRenderersFactory(ctx)
    }
}

/** True when an FFmpeg audio decoder library (NextLib or Jellyfin build) is bundled and its native code loads. */
object FfmpegInfo {
    fun available(): Boolean = Renderers.nextAvailable() || try {
        Class.forName("androidx.media3.decoder.ffmpeg.FfmpegLibrary")
            .getMethod("isAvailable").invoke(null) as Boolean
    } catch (e: Throwable) {
        false
    }

    /** Human readable reason: not bundled / native code failed / working. */
    fun status(): String = if (Renderers.nextAvailable()) "NextLib مضمّنة ✓" else try {
        val c = Class.forName("androidx.media3.decoder.ffmpeg.FfmpegLibrary")
        val ok = c.getMethod("isAvailable").invoke(null) as Boolean
        if (ok) "تعمل ✓" else "موجودة بس الكود الأصلي ما اشتغل ✗"
    } catch (e: ClassNotFoundException) {
        "غير مضمّنة بهالبناء ✗"
    } catch (e: Throwable) {
        "خطأ: " + e.javaClass.simpleName
    }
}

/** One-line stream description: quality, resolution, codec, fps and measured download speed. */
@OptIn(UnstableApi::class)
object StreamInfo {
    /** Quality label from the wider side, so cinemascope 3840x1608 still counts as 4K. */
    fun quality(w: Int, h: Int): String = when {
        w >= 3200 || h >= 2000 -> "4K"
        w >= 2400 || h >= 1300 -> "2K"
        w >= 1700 || h >= 1000 -> "FHD"
        w >= 1100 || h >= 700 -> "HD"
        w > 0 || h > 0 -> "SD"
        else -> ""
    }

    /** Audio formats that many devices cannot decode, or play silently over HDMI passthrough. */
    val HEAVY_AUDIO = setOf("AC3", "E-AC3", "Atmos", "DTS", "TrueHD")

    /** Codec name of the (first) audio track, whether or not this device supports it. */
    fun audioCodecName(p: ExoPlayer): String? {
        val af = p.audioFormat
        if (af != null) return audioName(af.sampleMimeType)
        val g = p.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 } ?: return null
        return audioName(g.getTrackFormat(0).sampleMimeType)
    }

    /** Codec name when the file has audio but this device cannot decode it, otherwise null. */
    fun audioUnsupported(p: ExoPlayer): String? {
        if (p.audioFormat != null) return null
        val g = p.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 } ?: return null
        return audioName(g.getTrackFormat(0).sampleMimeType)
    }

    private fun audioName(mime: String?): String {
        val m = mime.orEmpty()
        return when {
            m.contains("eac3-joc") -> "Atmos"
            m.contains("eac3") -> "E-AC3"
            m.contains("ac3") -> "AC3"
            m.contains("mp4a") -> "AAC"
            m.contains("mpeg") -> "MP3"
            m.contains("true-hd") || m.contains("truehd") -> "TrueHD"
            m.contains("dts") -> "DTS"
            m.contains("opus") -> "Opus"
            m.contains("vorbis") -> "Vorbis"
            else -> m.substringAfter('/').uppercase()
        }
    }

    private fun channels(n: Int) = when (n) {
        1 -> "1.0"
        2 -> "2.0"
        6 -> "5.1"
        8 -> "7.1"
        else -> if (n > 0) "${n}ch" else ""
    }

    fun isSoftware(name: String) =
        name.startsWith("OMX.google.") || name.startsWith("c2.android.") ||
            name.contains(".sw.") || name.contains("software", ignoreCase = true)

    /** Two lines for the info pill: picture quality, then speed / audio / decoder / dropped frames. */
    fun details(a: AjPlayer, ctx: Context): Pair<String, String> {
        val p = a.player
        val f = p.videoFormat
        val l1 = if (f == null) {
            "جارٍ قياس الجودة..."
        } else {
            val h = f.height
            val q = quality(f.width, h)
            val mime = f.sampleMimeType.orEmpty()
            val codec = when {
                mime.contains("hevc") -> "HEVC"
                mime.contains("avc") -> "H.264"
                mime.contains("av01") -> "AV1"
                mime.contains("vp9") -> "VP9"
                else -> ""
            }
            val res = if (f.width > 0 && h > 0) "${f.width}x$h" else ""
            val fps = if (f.frameRate > 0f) "${Math.round(f.frameRate)}fps" else ""
            listOf(q, res, codec, fps).filter { it.isNotEmpty() }.joinToString("  •  ")
        }
        val bps = DefaultBandwidthMeter.getSingletonInstance(ctx).bitrateEstimate
        val speed = if (bps > 0) "⚡ " + String.format(Locale.US, "%.1f Mbps", bps / 1_000_000.0) else ""
        val af = p.audioFormat
        val audio = if (af != null) {
            "🔊 " + audioName(af.sampleMimeType) + " " + channels(af.channelCount) +
                (if (a.audioDecoder.contains("ffmpeg", ignoreCase = true)) " (FFmpeg)" else "")
        } else {
            val g = p.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_AUDIO && it.length > 0 }
            if (g != null) "🔇 صوت غير مدعوم (" + audioName(g.getTrackFormat(0).sampleMimeType) + ")" else ""
        }
        val dec = a.videoDecoder
        val decTxt = if (dec.isEmpty()) "" else if (isSoftware(dec)) "🐢 برمجي" else "🚀 عتاد"
        val c = p.videoDecoderCounters
        var drop = ""
        if (c != null) {
            c.ensureUpdated()
            if (c.droppedBufferCount > 0) drop = "⚠ " + c.droppedBufferCount + " إطار"
        }
        val l2 = listOf(speed, audio, decTxt, drop).filter { it.isNotEmpty() }.joinToString("  •  ")
        return Pair(l1, l2)
    }

    fun text(p: ExoPlayer, ctx: Context): String {
        val f = p.videoFormat ?: return "جارٍ قياس الجودة..."
        val h = f.height
        val q = quality(f.width, h)
        val mime = f.sampleMimeType.orEmpty()
        val codec = when {
            mime.contains("hevc") -> "HEVC"
            mime.contains("avc") -> "H.264"
            mime.contains("av01") -> "AV1"
            mime.contains("vp9") -> "VP9"
            else -> ""
        }
        val res = if (f.width > 0 && h > 0) "${f.width}x$h" else ""
        val fps = if (f.frameRate > 0f) "${Math.round(f.frameRate)}fps" else ""
        val bps = DefaultBandwidthMeter.getSingletonInstance(ctx).bitrateEstimate
        val speed = if (bps > 0) String.format(Locale.US, "%.1f Mbps", bps / 1_000_000.0) else ""
        return listOf(q, res, codec, fps, speed).filter { it.isNotEmpty() }.joinToString("  •  ")
    }
}

/** Full-screen player. Queue comes from PlayQueue; extras: "index", "live". */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var aj: AjPlayer
    private lateinit var pv: PlayerView
    private lateinit var title: TextView
    private lateinit var chList: ListView
    private lateinit var seekTv: TextView
    private val hideSeek = Runnable { if (::seekTv.isInitialized) seekTv.visibility = View.GONE }
    private lateinit var pill: LinearLayout
    private lateinit var pillIcon: ImageView
    private lateinit var pillName: TextView
    private lateinit var pillL1: TextView
    private lateinit var pillL2: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (!::aj.isInitialized || !::pill.isInitialized) return
            val (l1, l2) = StreamInfo.details(aj, this@PlayerActivity)
            pillL1.text = l1
            pillL2.text = l2
            if (pill.visibility == View.VISIBLE) handler.postDelayed(this, 1000)
        }
    }
    private val hideInfo = Runnable { if (::pill.isInitialized) pill.visibility = View.GONE }

    private fun movePill(controlsVisible: Boolean) {
        val lp = pill.layoutParams as FrameLayout.LayoutParams
        lp.bottomMargin = (resources.displayMetrics.heightPixels * (if (controlsVisible) 0.27 else 0.06)).toInt()
        pill.layoutParams = lp
    }

    private var prompted = false
    private var hintedSlow = false

    /** A few seconds after playback starts: warn about unsupported audio / software 4K decoding. */
    private fun checkHealth() {
        if (!::aj.isInitialized || isFinishing) return
        val codec = StreamInfo.audioUnsupported(aj.player)
        // AC3 / DTS may be silent even when "supported" (HDMI passthrough), so VLC takes those over too.
        val heavy = StreamInfo.audioCodecName(aj.player) in StreamInfo.HEAVY_AUDIO &&
            VlcBridge.available() && prefs.getInt("engine", 0) != 1 && !FfmpegInfo.available()
        if ((codec != null || heavy) && !prompted) {
            prompted = true
            if (VlcBridge.available() && prefs.getInt("engine", 0) != 1) {
                // The platform cannot decode this audio: continue in the built-in VLC engine.
                savePos()
                openVlc()
                return
            }
            if (FfmpegInfo.available() && !prefs.getBoolean("ffaudio", false)) {
                // The platform cannot decode this audio: switch to the FFmpeg decoder and restart.
                prefs.edit().putBoolean("ffaudio", true).apply()
                intent.putExtra("index", index)
                Toast.makeText(this, "جارٍ تفعيل فك الصوت بـ FFmpeg...", Toast.LENGTH_LONG).show()
                recreate()
            } else {
                Toast.makeText(this, "صوت ($codec) غير مدعوم على هذا الجهاز", Toast.LENGTH_LONG).show()
            }
            return
        }
        val f = aj.player.videoFormat
        val dec = aj.videoDecoder
        if (!hintedSlow && f != null && f.width >= 2500 && dec.isNotEmpty() && StreamInfo.isSoftware(dec)) {
            hintedSlow = true
            Toast.makeText(this, "جهازك بيفك هالجودة بالبرمجيات (بدون تسريع) وممكن يقطّع. جرّب جهاز أقوى أو مشغّل خارجي", Toast.LENGTH_LONG).show()
        }
    }

    /** Bottom pill: channel icon, name, quality, speed, audio, decoder. Shown a few seconds, and with the controls. */
    private fun flashInfo() {
        if (!::pill.isInitialized) return
        pillName.text = PlayQueue.names.getOrElse(index) { "" }
        val icon = PlayQueue.icons.getOrElse(index) { "" }
        if (icon.isBlank()) {
            pillIcon.visibility = View.GONE
        } else {
            pillIcon.visibility = View.VISIBLE
            Img.load(icon, pillIcon, 96)
        }
        pill.visibility = View.VISIBLE
        handler.removeCallbacks(tick); handler.post(tick)
        handler.removeCallbacks(hideInfo); handler.postDelayed(hideInfo, 8000)
    }
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private var index = 0
    private var live = true
    private var triedTs = false
    private var mode = 0
    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val modeNames = arrayOf("تلقائي", "ملائم", "تمديد", "تكبير")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setBackgroundDrawable(ColorDrawable(0xFF000000.toInt()))
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        mode = prefs.getInt("aspect", 0).coerceIn(0, 3)
        if (PlayQueue.urls.isEmpty()) { finish(); return }
        index = intent.getIntExtra("index", 0).coerceIn(0, PlayQueue.urls.size - 1)
        live = intent.getBooleanExtra("live", true)
        if (prefs.getInt("engine", 0) == 2 && VlcBridge.available()) { openVlc(); return }

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        pv = PlayerView(this).apply {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShutterBackgroundColor(0xFF000000.toInt())
            setBackgroundColor(0xFF000000.toInt())
            setShowSubtitleButton(true)
            setShowNextButton(false)
            setShowPreviousButton(false)
            controllerShowTimeoutMs = 4000
        }
        val spinner = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
        }
        title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            setShadowLayer(6f, 0f, 0f, 0xFF000000.toInt())
            setPadding(32, 24, 32, 0)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        val ratio = Button(this).apply {
            text = "نسبة العرض"
            setOnClickListener {
                mode = (mode + 1) % modes.size
                prefs.edit().putInt("aspect", mode).apply()
                applyMode()
                Toast.makeText(this@PlayerActivity, modeNames[mode], Toast.LENGTH_SHORT).show()
            }
        }
        val ext = Button(this).apply {
            text = "مشغّل خارجي"
            setOnClickListener { openExternal() }
        }
        val chBtn = Button(this).apply {
            text = "القنوات"
            setOnClickListener { pv.hideController(); showList() }
        }
        bar.addView(ratio); bar.addView(ext)
        if (live) bar.addView(chBtn, 0)
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            bar.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
            if (::pill.isInitialized) movePill(v == View.VISIBLE)
            if (v == View.VISIBLE) flashInfo()
        })

        root.addView(pv, FrameLayout.LayoutParams(-1, -1))
        root.addView(spinner)
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        val maxW = (resources.displayMetrics.widthPixels * 0.6).toInt()
        pillIcon = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x22FFFFFF) }
            clipToOutline = true
        }
        pillName = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = maxW
        }
        pillL1 = TextView(this).apply {
            setTextColor(0xFF7FB0FF.toInt()); textSize = 13f; maxLines = 1; maxWidth = maxW
        }
        pillL2 = TextView(this).apply {
            setTextColor(0xFFC9D1DB.toInt()); textSize = 12f; maxLines = 1; maxWidth = maxW
            ellipsize = TextUtils.TruncateAt.END
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 8, 0) }
        texts.addView(pillName); texts.addView(pillL1); texts.addView(pillL2)
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 44, 16); visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(0xD90A0F18.toInt()); setStroke(2, 0x884C8DFF.toInt()); cornerRadius = 200f
            }
        }
        pill.addView(pillIcon, LinearLayout.LayoutParams(88, 88))
        pill.addView(texts)
        seekTv = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
            setPadding(40, 20, 40, 20); visibility = View.GONE
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 100f }
        }
        root.addView(seekTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = (resources.displayMetrics.heightPixels * 0.06).toInt() })
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        chList = ListView(this).apply {
            visibility = View.GONE
            divider = null
            setBackgroundColor(0xE6080B10.toInt())
            selector = ColorDrawable(0x55D9B26B)
            setOnItemClickListener { _, _, i, _ -> index = i; start(); hideList() }
        }
        root.addView(chList, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.38).toInt(), -1, Gravity.START))
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (chList.visibility == View.VISIBLE) hideList() else finish()
            }
        })

        aj = AjPlayer(this, live, prefs.getInt("buf", 1), prefs.getBoolean("tunnel", false), prefs.getBoolean("maxq", false), prefs.getBoolean("ffaudio", false), Seek.stepMs(prefs))
        pv.player = aj.player
        aj.player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (mode == 0) autoFit(videoSize)
            }
        })
        applyMode()
        aj.onState = { s ->
            spinner.visibility = if (s == AjPlayer.State.LOADING) View.VISIBLE else View.GONE
            when (s) {
                AjPlayer.State.ERROR -> {
                    val u = PlayQueue.urls[index]
                    if (!triedTs && u.endsWith(".m3u8")) {
                        triedTs = true
                        aj.play(u.removeSuffix(".m3u8") + ".ts")
                    } else {
                        val code = aj.lastError?.errorCode
                        val unsupported = code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
                            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
                        if (VlcBridge.available() && prefs.getInt("engine", 0) != 1) openVlc()
                        title.text = if (unsupported) "جهازك لا يدعم هذه الجودة. جرّب «مشغّل خارجي»"
                        else "تعذّر التشغيل: " + PlayQueue.names[index]
                    }
                }
                AjPlayer.State.PLAYING -> { flashInfo(); handler.postDelayed({ checkHealth() }, 1500) }
                AjPlayer.State.ENDED -> {
                    if (!live) {
                        prefs.edit().remove(posKey()).apply()
                        if (index < PlayQueue.urls.size - 1) { index++; start() }
                    }
                }
                else -> {}
            }
        }
        start()
    }

    private fun applyMode() {
        if (mode == 0) autoFit(aj.player.videoSize) else pv.resizeMode = modes[mode]
    }

    /** Auto: fill the screen when the video is close to it, keep cinema bars for very wide films. */
    private fun autoFit(v: VideoSize) {
        if (v.width == 0 || v.height == 0) {
            pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            return
        }
        val vr = v.width * v.pixelWidthHeightRatio / v.height
        val dm = resources.displayMetrics
        val sr = dm.widthPixels.toFloat() / dm.heightPixels
        val d = Math.abs(vr / sr - 1f)
        pv.resizeMode =
            if (d < 0.22f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private fun posKey() = "pos_" + PlayQueue.urls[index].hashCode()

    private fun start() {
        triedTs = false
        title.text = PlayQueue.names[index]
        flashInfo()
        val saved = if (live) 0L else prefs.getLong(posKey(), 0L)
        aj.play(PlayQueue.urls[index], if (saved > 10_000L) saved else 0L)
    }

    private fun savePos() {
        if (live || !::aj.isInitialized) return
        val d = aj.player.duration
        val p = aj.player.currentPosition
        val e = prefs.edit()
        if (d != C.TIME_UNSET && p > d - 30_000L) e.remove(posKey()) else e.putLong(posKey(), p)
        e.apply()
    }

    private fun zap(d: Int) {
        val n = PlayQueue.urls.size
        index = (index + d + n) % n
        start()
    }

    private fun openExternal() {
        aj.pause()
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(PlayQueue.urls[index]), "video/*")
        try {
            startActivity(Intent.createChooser(i, "افتح بواسطة"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "ما في مشغّل خارجي مثبّت", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Live: OK opens the channel list, up/down change channel, MENU opens the controls.
     * While the list is open the keys go to the list.
     */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (live && ::pv.isInitialized && ::chList.isInitialized && e.action == KeyEvent.ACTION_DOWN) {
            if (chList.visibility == View.VISIBLE) {
                if (e.keyCode == KeyEvent.KEYCODE_MENU) { hideList(); return true }
                return super.dispatchKeyEvent(e)
            }
            if (!pv.isControllerFullyVisible) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { showList(); return true }
                    KeyEvent.KEYCODE_MENU -> { pv.showController(); return true }
                }
            }
        }
        // Movies: left/right seek directly (hold = faster), OK pauses, MENU opens the controls.
        if (!live && ::pv.isInitialized && ::chList.isInitialized && ::aj.isInitialized &&
            e.action == KeyEvent.ACTION_DOWN && !pv.isControllerFullyVisible && chList.visibility != View.VISIBLE
        ) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-1, e.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(1, e.repeatCount); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> { togglePause(); return true }
                KeyEvent.KEYCODE_MENU -> { pv.showController(); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    private fun showSeekText(text: String) {
        seekTv.text = text
        seekTv.visibility = View.VISIBLE
        handler.removeCallbacks(hideSeek)
        handler.postDelayed(hideSeek, 1200)
    }

    private fun seekBy(sign: Int, repeat: Int) {
        val p = aj.player
        val dur = p.duration
        val step = Seek.accelerate(Seek.stepMs(prefs), repeat)
        var t = p.currentPosition + sign * step
        t = if (dur != C.TIME_UNSET) t.coerceIn(0L, maxOf(0L, dur - 1000L)) else t.coerceAtLeast(0L)
        p.seekTo(t)
        showSeekText(
            (if (sign > 0) "⏩ +" else "⏪ -") + Seek.label(step) + "   " + Seek.time(t) +
                (if (dur != C.TIME_UNSET) " / " + Seek.time(dur) else "")
        )
    }

    private fun togglePause() {
        val p = aj.player
        if (p.isPlaying) { p.pause(); showSeekText("⏸") } else { p.play(); showSeekText("▶") }
    }

    private val gestures by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (live || !::aj.isInitialized) return false
                val w = resources.displayMetrics.widthPixels
                if (e.x < w * 0.4f) seekBy(-1, 0) else if (e.x > w * 0.6f) seekBy(1, 0)
                return true
            }
        })
    }

    /** Phone: double-tap the left / right side to rewind / forward. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!live) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    /** Continue the same queue and position in the built-in VLC engine. */
    private fun openVlc() {
        startActivity(
            android.content.Intent().setClassName(this, VlcBridge.CLASS)
                .putExtra("index", index).putExtra("live", live)
        )
        finish()
    }

    private fun showList() {
        val labels = PlayQueue.names.mapIndexed { i, n -> (if (i == index) "▶ " else "") + n }
        chList.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(0xFFFFFFFF.toInt()); t.textSize = 17f
                t.setPadding(32, 24, 32, 24); t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END
                return t
            }
        }
        chList.visibility = View.VISIBLE
        chList.setSelection(index)
        chList.requestFocus()
    }

    private fun hideList() {
        chList.visibility = View.GONE
        pv.requestFocus()
    }

    override fun onStart() { super.onStart(); if (::aj.isInitialized) aj.resume() }
    override fun onStop() { super.onStop(); savePos(); if (::aj.isInitialized) aj.pause() }
    override fun onDestroy() { super.onDestroy(); handler.removeCallbacksAndMessages(null); if (::aj.isInitialized) aj.release() }
}

pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "AJIPTV"
include(":app", ":admin")
// The FFmpeg module exists only after build-ffmpeg.sh fetched and built its sources.
if (File(rootDir, "media3-src/libraries/decoder_ffmpeg").exists()) include(":ffmpeg-module")

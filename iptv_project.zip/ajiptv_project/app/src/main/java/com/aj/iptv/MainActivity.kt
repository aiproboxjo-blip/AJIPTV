package com.aj.iptv

import android.content.Intent
import android.speech.RecognizerIntent
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.aj.iptv.player.PlayQueue
import com.aj.iptv.player.PlayerActivity
import com.aj.iptv.player.Xtream
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

enum class Kind(val label: String, val catAction: String, val listAction: String) {
    LIVE("بث مباشر", "get_live_categories", "get_live_streams"),
    MOVIE("أفلام", "get_vod_categories", "get_vod_streams"),
    SERIES("مسلسلات", "get_series_categories", "get_series")
}

data class Item(val id: String, val name: String, val ext: String = "", val iconUrl: String = "")
data class Fav(val kind: Kind, val item: Item)

class MainActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(3)
    private val imageCache = ConcurrentHashMap<String, Bitmap>()
    private val imageJobs = ConcurrentHashMap.newKeySet<String>()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private val bg = Color.parseColor("#0B1A2E")
    private var user = ""
    private var pass = ""
    private var screen = 0
    private var onBack: (() -> Unit)? = null
    private val voiceSearchRequest = 7301
    private var voiceSearchField: EditText? = null

    @Deprecated("Deprecated in Android API; retained for compatibility with the current project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceSearchRequest && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) {
                voiceSearchField?.setText(spoken)
                voiceSearchField?.setSelection(spoken.length)
            } else {
                toast("لم يتم التعرّف على الكلام، حاول مرة أخرى")
            }
        }
    }

    private fun startVoiceSearch(field: EditText) {
        voiceSearchField = field
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-JO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "قل اسم القناة أو الفيلم أو المسلسل")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        try {
            startActivityForResult(intent, voiceSearchRequest)
        } catch (_: Exception) {
            toast("البحث الصوتي غير متاح على هذا الجهاز. تأكد من وجود خدمة التعرف على الصوت.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val b = onBack
                if (b != null) b() else finish()
            }
        })
        user = prefs.getString("u", "").orEmpty()
        pass = prefs.getString("p", "").orEmpty()
        showSplash()
    }

    // ---------- network + cache ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(extra: String = ""): String {
        val u = "http://${Xtream.HOST}:${Xtream.PORT}/player_api.php?username=${enc(user)}&password=${enc(pass)}$extra"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Shows cached data instantly, then refreshes from the server. */
    private fun load(key: String, extra: String, tok: Int, show: (String) -> Unit) {
        val f = File(cacheDir, "$key.json")
        if (f.exists()) try { show(f.readText()) } catch (_: Exception) { }
        io.execute {
            try {
                val t = api(extra)
                JSONTokener(t).nextValue()
                f.writeText(t)
                ui.post {
                    if (tok == screen && !isFinishing) try { show(t) } catch (_: Exception) { }
                }
            } catch (e: Exception) {
                ui.post {
                    if (tok == screen && !f.exists()) toast("تعذّر التحميل، تحقق من الاتصال")
                }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- favorites ----------
    private fun favs(): MutableList<Fav> {
        val out = ArrayList<Fav>()
        try {
            val a = JSONArray(prefs.getString("fav", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Fav(Kind.valueOf(o.getString("k")), Item(o.getString("id"), o.getString("n"), o.optString("e"), o.optString("i"))))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun toggleFav(k: Kind, item: Item) {
        val l = favs()
        val ex = l.find { it.kind == k && it.item.id == item.id }
        if (ex != null) l.remove(ex) else l.add(Fav(k, item))
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("k", it.kind.name).put("id", it.item.id).put("n", it.item.name).put("e", it.item.ext).put("i", it.item.iconUrl))
        }
        prefs.edit().putString("fav", a.toString()).apply()
    }

    // ---------- UI helpers ----------
    private fun adapter(items: List<String>) =
        object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(Color.WHITE)
                t.textSize = 18f
                t.setPadding(48, 30, 48, 30)
                return t
            }
        }

    /** TV-friendly poster row for server-provided channel icons, movie posters and series covers. */
    private fun contentAdapter(items: List<Item>, favoriteIds: Set<String> = emptySet()) = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id.hashCode().toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val item = getItem(position)
            val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(18, 10, 18, 10)
                isFocusable = false
                val poster = ImageView(this@MainActivity).apply {
                    tag = "poster"
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(Color.parseColor("#1B3048"))
                }
                addView(poster, LinearLayout.LayoutParams(88, 112).apply { marginEnd = 22 })
                val title = TextView(this@MainActivity).apply {
                    tag = "title"
                    setTextColor(Color.WHITE)
                    textSize = 19f
                    maxLines = 2
                    gravity = Gravity.CENTER_VERTICAL
                }
                addView(title, LinearLayout.LayoutParams(0, -1, 1f))
                minimumHeight = 128
                background = tileBg()
            }
            val poster = row.findViewWithTag<ImageView>("poster")
            val title = row.findViewWithTag<TextView>("title")
            title.text = (if (item.id in favoriteIds) "★  " else "") + item.name
            poster.setImageDrawable(null)
            poster.contentDescription = item.name
            val url = item.iconUrl.trim()
            if (url.isNotEmpty()) {
                val cached = imageCache[url]
                if (cached != null) poster.setImageBitmap(cached)
                else if (imageJobs.add(url)) {
                    io.execute {
                        var bitmap: Bitmap? = null
                        try {
                            val conn = URL(url).openConnection() as HttpURLConnection
                            conn.connectTimeout = 7000
                            conn.readTimeout = 10000
                            conn.setRequestProperty("User-Agent", "AJIPTV/1.0")
                            conn.inputStream.use { bitmap = BitmapFactory.decodeStream(it) }
                            conn.disconnect()
                        } catch (_: Exception) { }
                        if (bitmap != null) imageCache[url] = bitmap!!
                        imageJobs.remove(url)
                        ui.post {
                            if (!isFinishing && poster.getTag(1234567) == url) { /* tag checked below via URL tag */ }
                            // Find visible rows by re-binding; ListView will reuse the cached bitmap on redraw.
                            if (bitmap != null && poster.getTag(1234567) == url) poster.setImageBitmap(bitmap)
                        }
                    }
                    poster.setTag(1234567, url)
                }
            } else {
                poster.setImageDrawable(ColorDrawable(Color.parseColor("#203A58")))
                poster.setTag(1234567, "")
            }
            return row
        }
    }

    private fun newList() = ListView(this).apply {
        divider = null
        isFocusable = true
        selector = ColorDrawable(Color.parseColor("#664C8DFF"))
    }

    private fun tileBg(): StateListDrawable {
        fun rect(c: Int, stroke: Int = Color.TRANSPARENT, width: Int = 0) =
            GradientDrawable().apply {
                setColor(c)
                cornerRadius = 28f
                if (width > 0) setStroke(width, stroke)
            }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), rect(Color.parseColor("#2459A8"), Color.parseColor("#80C7FF"), 3))
            addState(intArrayOf(android.R.attr.state_pressed), rect(Color.parseColor("#2459A8"), Color.parseColor("#80C7FF"), 2))
            addState(intArrayOf(), rect(Color.parseColor("#142B46"), Color.parseColor("#294765"), 1))
        }
    }

    private fun tile(label: String) = Button(this).apply {
        text = label
        textSize = 21f
        isAllCaps = false
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(18, 14, 18, 14)
        minHeight = 112
        background = tileBg()
        isFocusable = true
        isFocusableInTouchMode = true
        stateListAnimator = null
    }

    private fun page(title: String, content: View, extra: View? = null) {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 16, 28, 22)
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 18)
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 27f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        brand.addView(TextView(this).apply {
            text = "AJIPTV  •  تجربة مشاهدة أسهل"
            setTextColor(Color.parseColor("#91A9C4"))
            textSize = 13f
            setPadding(0, 4, 0, 0)
        })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val status = TextView(this).apply {
            text = "● متصل بالتطبيق"
            setTextColor(Color.parseColor("#8ED9B0"))
            textSize = 13f
            setPadding(18, 10, 18, 10)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#183A3B"))
                cornerRadius = 24f
            }
        }
        header.addView(status)
        col.addView(header, LinearLayout.LayoutParams(-1, -2))
        extra?.let {
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = 12
            col.addView(it, lp)
        }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(col)
    }

    private fun play(urls: List<String>, names: List<String>, index: Int, live: Boolean) {
        PlayQueue.urls = urls
        PlayQueue.names = names
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", index).putExtra("live", live))
    }

    private fun openItem(kind: Kind, s: List<Item>, i: Int, back: () -> Unit) {
        when (kind) {
            Kind.LIVE -> play(s.map { Xtream.live(user, pass, it.id) }, s.map { it.name }, i, true)
            Kind.MOVIE -> {
                val m = s[i]
                play(listOf(Xtream.movie(user, pass, m.id, m.ext.ifEmpty { "mp4" })), listOf(m.name), 0, false)
            }
            Kind.SERIES -> showEpisodes(s[i].id, s[i].name, back)
        }
    }

    // ---------- screens ----------
    private fun showSplash() {
        val f = FrameLayout(this).apply { setBackgroundColor(bg) }
        f.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, FrameLayout.LayoutParams(360, 360, Gravity.CENTER))
        setContentView(f)
        ui.postDelayed({
            if (!isFinishing) { if (user.isNotEmpty()) showHome() else showLogin() }
        }, 900)
    }

    private fun showLogin() {
        screen++; onBack = null
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 32, 64, 32); setBackgroundColor(bg)
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(260, 260))
        fun field(h: String, secret: Boolean) = EditText(this).apply {
            hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val u = field("اسم المستخدم", false)
        val p = field("كلمة المرور", true)
        val err = TextView(this).apply { setTextColor(Color.parseColor("#FF6B6B")); gravity = Gravity.CENTER }
        val btn = tile("دخول")
        btn.setOnClickListener {
            user = u.text.toString().trim(); pass = p.text.toString().trim()
            if (user.isEmpty() || pass.isEmpty()) { err.text = "أدخل اسم المستخدم وكلمة المرور"; return@setOnClickListener }
            btn.isEnabled = false; err.text = "جارٍ التحقق..."
            io.execute {
                val ok = try { JSONObject(api()).getJSONObject("user_info").optInt("auth") == 1 } catch (e: Exception) { false }
                ui.post {
                    if (ok) {
                        prefs.edit().putString("u", user).putString("p", pass).apply()
                        showHome()
                    } else {
                        btn.isEnabled = true; err.text = "فشل الدخول: تحقق من البيانات أو الاتصال"
                    }
                }
            }
        }
        col.addView(u, LinearLayout.LayoutParams(-1, -2))
        col.addView(p, LinearLayout.LayoutParams(-1, -2))
        col.addView(err, LinearLayout.LayoutParams(-1, -2))
        col.addView(btn, LinearLayout.LayoutParams(-1, 140).apply { topMargin = 16 })
        setContentView(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(col) })
        u.requestFocus()
    }

    private fun showHome() {
        screen++; onBack = null

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(34, 18, 34, 28)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 14)
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(TextView(this).apply {
            text = "AJIPTV"
            setTextColor(Color.WHITE)
            textSize = 32f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        heading.addView(TextView(this).apply {
            text = "كل ما تريد مشاهدته، في مكان واحد"
            setTextColor(Color.parseColor("#9DB3CC"))
            textSize = 16f
            setPadding(0, 2, 0, 0)
        })
        top.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "واجهة التلفزيون"
            setTextColor(Color.parseColor("#C8E5FF"))
            textSize = 15f
            setPadding(22, 12, 22, 12)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#173A5F"))
                cornerRadius = 26f
                setStroke(1, Color.parseColor("#35658F"))
            }
        })
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(30, 22, 30, 22)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#1A4776"), Color.parseColor("#10243B"), Color.parseColor("#101E30"))
            ).apply {
                cornerRadius = 30f
                setStroke(1, Color.parseColor("#315A7F"))
            }
        }
        hero.addView(TextView(this).apply {
            text = "شاهد بطريقتك"
            setTextColor(Color.WHITE)
            textSize = 25f
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        hero.addView(TextView(this).apply {
            text = "اختر البث المباشر أو تصفّح مكتبة الأفلام والمسلسلات"
            setTextColor(Color.parseColor("#D1E2F3"))
            textSize = 16f
            setPadding(0, 8, 0, 0)
        })
        root.addView(hero, LinearLayout.LayoutParams(-1, 0, 0.8f).apply {
            bottomMargin = 12
        })

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val tiles: List<Pair<String, () -> Unit>> = listOf(
            "📺\nالبث المباشر" to { showCategories(Kind.LIVE) },
            "🎬\nالأفلام" to { showCategories(Kind.MOVIE) },
            "🎞️\nالمسلسلات" to { showCategories(Kind.SERIES) },
            "⭐\nالمفضلة" to { showFavorites() },
            "👤\nالحساب" to { showAccount() },
            "⚙️\nالإعدادات" to { showSettings() }
        )
        var first: View? = null
        for (r in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..2) {
                val (label, action) = tiles[r * 3 + c]
                val b = tile(label)
                b.setOnClickListener { action() }
                row.addView(b, LinearLayout.LayoutParams(0, 0, 1f).apply {
                    setMargins(8, 8, 8, 8)
                })
                if (first == null) first = b
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 2.2f))
        root.addView(TextView(this).apply {
            text = "استخدم أزرار الاتجاهات في الريموت للتنقل ثم اضغط OK للاختيار"
            setTextColor(Color.parseColor("#6F8AA7"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        first?.requestFocus()
    }

    private fun showCategories(kind: Kind) {
        val tok = ++screen; onBack = { showHome() }
        val list = newList()
        page(kind.label, list)
        list.requestFocus()
        load("cats_${kind.name}_${user.hashCode()}", "&action=${kind.catAction}", tok) { t ->
            val arr = JSONArray(t)
            val ids = ArrayList<String>(); val names = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                ids.add(o.get("category_id").toString()); names.add(o.getString("category_name"))
            }
            list.adapter = adapter(names)
            list.setOnItemClickListener { _, _, i, _ -> showItems(kind, ids[i], names[i]) }
        }
    }

    private fun showItems(kind: Kind, catId: String, catName: String) {
        val tok = ++screen; onBack = { showCategories(kind) }
        val list = newList()
        val q = EditText(this).apply {
            hint = "بحث  (اضغط مطولاً للمفضلة)"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(); setPadding(48, 20, 48, 20)
        }
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        searchRow.addView(q, LinearLayout.LayoutParams(0, 64, 1f).apply { marginEnd = 12 })
        val mic = tile("🎙 بحث صوتي").apply {
            textSize = 17f
            minHeight = 64
            setPadding(18, 8, 18, 8)
            contentDescription = "البحث الصوتي"
            setOnClickListener { startVoiceSearch(q) }
        }
        searchRow.addView(mic, LinearLayout.LayoutParams(220, 64))
        page(catName, list, extra = searchRow)
        list.requestFocus()
        var all: List<Item> = emptyList()
        var shown: List<Item> = emptyList()
        fun render() {
            val pos = list.firstVisiblePosition
            val t = q.text.toString().trim().lowercase()
            val favIds = favs().filter { it.kind == kind }.map { it.item.id }.toSet()
            shown = all.filter { t.isEmpty() || it.name.lowercase().contains(t) }
            list.adapter = contentAdapter(shown, favIds)
            list.setSelection(pos)
            list.setOnItemClickListener { _, _, i, _ ->
                openItem(kind, shown, i) { showItems(kind, catId, catName) }
            }
            list.setOnItemLongClickListener { _, _, i, _ -> toggleFav(kind, shown[i]); render(); true }
        }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = render()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val idKey = if (kind == Kind.SERIES) "series_id" else "stream_id"
        load("it_${kind.name}_${user.hashCode()}_$catId", "&action=${kind.listAction}&category_id=$catId", tok) { t ->
            val arr = JSONArray(t)
            all = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                val image = when {
                    o.optString("stream_icon").isNotBlank() -> o.optString("stream_icon")
                    o.optString("cover").isNotBlank() -> o.optString("cover")
                    o.optString("cover_big").isNotBlank() -> o.optString("cover_big")
                    o.optString("movie_image").isNotBlank() -> o.optString("movie_image")
                    else -> ""
                }
                Item(o.get(idKey).toString(), o.getString("name"), o.optString("container_extension"), image)
            }
            render()
        }
    }

    private fun showEpisodes(seriesId: String, title: String, back: () -> Unit) {
        val tok = ++screen; onBack = back
        val list = newList()
        page(title, list)
        list.requestFocus()
        load("ep_${user.hashCode()}_$seriesId", "&action=get_series_info&series_id=$seriesId", tok) { t ->
            val raw = JSONObject(t).opt("episodes")
            val seasons = LinkedHashMap<String, JSONArray>()
            if (raw is JSONObject) {
                raw.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { seasons[it] = raw.getJSONArray(it) }
            } else if (raw is JSONArray) {
                for (i in 0 until raw.length()) seasons["${i + 1}"] = raw.optJSONArray(i) ?: JSONArray()
            }
            val items = ArrayList<Item>()
            for ((s, arr) in seasons) {
                for (j in 0 until arr.length()) {
                    val o = arr.getJSONObject(j)
                    val num = o.optString("episode_num", "${j + 1}")
                    val ttl = o.optString("title")
                    val label = "الموسم $s - الحلقة $num" + if (ttl.isNotEmpty()) " | $ttl" else ""
                    items.add(Item(o.get("id").toString(), label, o.optString("container_extension")))
                }
            }
            list.adapter = adapter(items.map { it.name })
            list.setOnItemClickListener { _, _, i, _ ->
                play(
                    items.map { Xtream.episode(user, pass, it.id, it.ext.ifEmpty { "mp4" }) },
                    items.map { title + " - " + it.name },
                    i, false
                )
            }
        }
    }

    private fun showFavorites() {
        screen++; onBack = { showHome() }
        val list = newList()
        page("المفضلة  (اضغط مطولاً للحذف)", list)
        list.requestFocus()
        fun render() {
            val fl = favs()
            val icon = mapOf(Kind.LIVE to "📺 ", Kind.MOVIE to "🎬 ", Kind.SERIES to "🎞️ ")
            list.adapter = contentAdapter(fl.map { it.item.copy(name = (icon[it.kind] ?: "") + it.item.name) }, fl.map { it.item.id }.toSet())
            list.setOnItemClickListener { _, _, i, _ ->
                val f = fl[i]
                if (f.kind == Kind.LIVE) {
                    val l = fl.filter { it.kind == Kind.LIVE }.map { it.item }
                    openItem(Kind.LIVE, l, l.indexOf(f.item)) { showFavorites() }
                } else {
                    openItem(f.kind, listOf(f.item), 0) { showFavorites() }
                }
            }
            list.setOnItemLongClickListener { _, _, i, _ -> toggleFav(fl[i].kind, fl[i].item); render(); true }
        }
        render()
    }

    private fun showAccount() {
        val tok = ++screen; onBack = { showHome() }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(64, 32, 64, 32); text = "جارٍ التحميل..."
        }
        page("الحساب", tv)
        load("acc_${user.hashCode()}", "", tok) { t ->
            val u = JSONObject(t).getJSONObject("user_info")
            val exp = u.optString("exp_date").toLongOrNull()
                ?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it * 1000)) } ?: "غير محدود"
            tv.text = "المستخدم: ${u.optString("username")}\n" +
                "الحالة: ${u.optString("status")}\n" +
                "ينتهي: $exp\n" +
                "الاتصالات: ${u.optString("active_cons")} / ${u.optString("max_connections")}"
        }
    }

    private fun showSettings() {
        screen++; onBack = { showHome() }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(64, 16, 64, 16)
        }
        val sizes = arrayOf("صغير", "متوسط", "كبير")
        val buf = tile("")
        fun upd() { buf.text = "حجم تخزين المشغّل المؤقت: " + sizes[prefs.getInt("buf", 1).coerceIn(0, 2)] }
        upd()
        buf.setOnClickListener {
            prefs.edit().putInt("buf", (prefs.getInt("buf", 1) + 1) % 3).apply(); upd()
        }
        val clear = tile("مسح الكاش")
        clear.setOnClickListener { cacheDir.listFiles()?.forEach { it.delete() }; toast("تم مسح الكاش") }
        val out = tile("تسجيل الخروج")
        out.setOnClickListener {
            prefs.edit().remove("u").remove("p").apply()
            cacheDir.listFiles()?.forEach { it.delete() }
            user = ""; pass = ""; showLogin()
        }
        for (b in listOf(buf, clear, out)) {
            col.addView(b, LinearLayout.LayoutParams(-1, 130).apply { setMargins(0, 12, 0, 12) })
        }
        col.addView(TextView(this).apply { text = "AJIPTV 1.2"; setTextColor(Color.GRAY); gravity = Gravity.CENTER })
        page("الإعدادات", ScrollView(this).apply { addView(col) })
        buf.requestFocus()
    }
}

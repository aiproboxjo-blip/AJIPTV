AJIPTV - Server Content Artwork Update

This source update adds artwork thumbnails to the content lists for live channels, movies, and series.
It reads artwork URLs supplied by the existing Xtream Codes API response (stream_icon, cover, cover_big, movie_image), loads images asynchronously, and caches decoded images in memory for smoother TV browsing.
Existing login and Xtream server settings remain unchanged.

Note: This is source code, not a built/verified APK. Build with Android Studio/Gradle and test against your authorized Xtream server. Some servers omit artwork URLs or return inaccessible image URLs; those entries will show a placeholder.

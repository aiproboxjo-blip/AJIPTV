plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// Each GitHub build gets a higher number, so updates install over the old app.
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toInt()

android {
    namespace = "com.aj.iptv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aj.iptv"; minSdk = 21; targetSdk = 34
        versionCode = 100 + runNo; versionName = "2.2.$runNo"
    }
    signingConfigs {
        create("fixed") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null) {
                storeFile = file(ks); storeType = "pkcs12"
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (System.getenv("KEYSTORE_FILE") != null) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
}
val media3Version = "1.3.1"
val jellyfinFfmpegVersion = "1.3.1+1" // Built against Media3 1.3.1

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")

    // Prebuilt FFmpeg AudioRenderer and native libraries. Keep this version aligned with Media3.
    // EXTENSION_RENDERER_MODE_ON in AjPlayer uses FFmpeg when the platform decoder cannot decode
    // a format such as AC3, while retaining the platform decoder for formats it supports.
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:$jellyfinFfmpegVersion")
}

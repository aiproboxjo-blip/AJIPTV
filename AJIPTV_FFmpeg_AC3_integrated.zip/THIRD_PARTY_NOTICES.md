# Third-party notices and codec licensing

## Jellyfin AndroidX Media3 FFmpeg decoder

AJIPTV includes `org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+1`, aligned with AndroidX Media3 `1.3.1`.
The published decoder artifact is licensed under GNU General Public License v3.0 (GPL-3.0). A copy is included at `LICENSES/GPL-3.0.txt`.

Project page: https://github.com/jellyfin/jellyfin-androidx-media
Artifact metadata: https://central.sonatype.com/artifact/org.jellyfin.media3/media3-ffmpeg-decoder/1.3.1%2B1

The artifact includes native FFmpeg components. Before distributing AJIPTV APKs, review the exact FFmpeg build configuration and satisfy applicable GPL/source-code, notices, and redistribution requirements for the exact binary being shipped. This notice is not a legal opinion. If you need to keep AJIPTV proprietary, do not distribute this GPL-licensed dependency until a qualified licensing review confirms a compliant option.

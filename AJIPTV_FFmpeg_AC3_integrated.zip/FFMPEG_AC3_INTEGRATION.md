# AJIPTV FFmpeg / AC3 integration notes

## Current dependency alignment

- AndroidX Media3 modules: `1.3.1`
- Jellyfin FFmpeg decoder: `1.3.1+1` (published for Media3 1.3.1)
- Android Gradle Plugin: `8.5.2`
- Kotlin Gradle plugin: `1.9.24`
- `compileSdk` / `targetSdk`: `34`
- `minSdk`: `21`
- Java/Kotlin target: `17`
- NDK: not needed to consume the published prebuilt AAR; required only if replacing it with a locally built FFmpeg decoder.

## Renderer behavior

`AjPlayer` uses `DefaultRenderersFactory` with extension renderers enabled. In the default mode (`EXTENSION_RENDERER_MODE_ON`), Android's standard decoder retains priority and the FFmpeg extension is available when the platform renderer does not support the input format. The existing `ffaudio` preference can choose `EXTENSION_RENDERER_MODE_PREFER` to prioritize the extension. Decoder initialization is logged under `AJIPTV-Decoder` to help diagnose whether the audio renderer initializes.

The FFmpeg decoder is loaded by Media3's extension mechanism; it is not enough to add the Gradle dependency if the renderer mode is disabled. Do not mix this decoder version with Media3 1.9.x or other versions: upgrade the complete Media3 family and the Jellyfin decoder together only after compatibility review.

## Build / verification

The GitHub Actions workflow compiles both Android modules and uploads debug APKs. This environment did not have Gradle installed and could not access Maven Central, so an actual Android build and runtime AC3/AAC playback test could not be run here. The workflow result and on-device tests are required before calling the integration verified.

Suggested device tests:
1. Play a known AC3 live stream and verify audible output; check Logcat for `AJIPTV-Decoder`.
2. Play AAC and MP3 streams and verify the existing platform path still works.
3. Play a known 4K stream and verify video decoding remains hardware accelerated where supported.
4. Test both default FFmpeg fallback mode and the optional FFmpeg-preferred setting.

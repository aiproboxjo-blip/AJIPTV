package com.aj.iptv.admin

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

object Cfg {
    const val DB = "https://ajiptv-5b2d8-default-rtdb.firebaseio.com"
    const val KEY = "AIzaSyA0mwuUyNQyBFQsiUlDAc30sY54KBMDP5s"
    const val APK = "https://github.com/aiproboxjo-blip/AJIPTV/releases/latest/download/AJIPTV.apk"
}

class AdminActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("admin", MODE_PRIVATE) }
    private val bg = Color.parseColor("#05080D")
    private val surface = Color.parseColor("#0D141F")
    private val line = Color.parseColor("#1F2C3F")
    private val accent = Color.parseColor("#4C8DFF")
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }

    private var idToken = ""
    private var expiresAt = 0L
    private var devices = LinkedHashMap<String, JSONObject>()
    private var onBack: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val b = onBack
                if (b != null) b() else finish()
            }
        })
        if (prefs.getString("refresh", "").orEmpty().isNotEmpty()) {
            showBusy("جارٍ التحميل...")
            io.execute {
                try { token(); ui.post { reload { showList() } } } catch (e: Exception) { ui.post { showLogin() } }
            }
        } else {
            showLogin()
        }
    }

    // ---------- helpers ----------
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun today(): String = fmt.format(Date())
    private fun pretty(id: String) = if (id.length == 8) id.substring(0, 4) + " - " + id.substring(4) else id

    private fun friendly(e: Exception): String {
        val m = e.message.orEmpty()
        return when {
            m.contains("INVALID") || m.contains("EMAIL_NOT_FOUND") -> "الإيميل أو كلمة المرور غير صحيحة"
            m.contains("OPERATION_NOT_ALLOWED") -> "فعّل Email/Password من Firebase"
            m.contains("Permission denied") -> "ما عندك صلاحية. تأكد من قواعد Firebase"
            else -> m.take(100).ifEmpty { "تحقق من الإنترنت" }
        }
    }

    private fun http(method: String, url: String, body: String? = null, type: String = "application/json"): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10_000
        c.readTimeout = 20_000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", type)
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw Exception(text.ifEmpty { "HTTP $code" })
        return text
    }

    private fun field(h: String, type: Int = InputType.TYPE_CLASS_TEXT) = EditText(this).apply {
        hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        inputType = type
        background = GradientDrawable().apply { setColor(surface); setStroke(dp(1), line); cornerRadius = dp(10).toFloat() }
        setPadding(dp(14), dp(12), dp(14), dp(12))
    }

    private fun button(label: String, primary: Boolean = false) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 16f; stateListAnimator = null
        setTextColor(if (primary) Color.parseColor("#0A0F18") else Color.WHITE)
        background = GradientDrawable().apply {
            setColor(if (primary) Color.parseColor("#E8EDF4") else surface)
            setStroke(dp(1), line); cornerRadius = dp(12).toFloat()
        }
    }

    private fun lp(top: Int = 10) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(20), dp(20), dp(20), dp(20))
    }

    private fun showBusy(msg: String) {
        val c = column().apply { gravity = Gravity.CENTER }
        c.addView(TextView(this).apply { text = msg; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER })
        setContentView(c)
    }

    // ---------- Firebase auth + database ----------
    private fun saveTokens(r: JSONObject, idKey: String, refreshKey: String, expKey: String) {
        idToken = r.getString(idKey)
        expiresAt = System.currentTimeMillis() + r.getString(expKey).toLong() * 1000 - 60_000
        prefs.edit().putString("refresh", r.getString(refreshKey)).apply()
    }

    private fun signIn(email: String, pass: String) {
        val r = JSONObject(
            http(
                "POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${Cfg.KEY}",
                JSONObject().put("email", email).put("password", pass).put("returnSecureToken", true).toString()
            )
        )
        saveTokens(r, "idToken", "refreshToken", "expiresIn")
        prefs.edit().putString("email", email).apply()
    }

    private fun token(): String {
        if (idToken.isNotEmpty() && System.currentTimeMillis() < expiresAt) return idToken
        val rt = prefs.getString("refresh", "").orEmpty()
        if (rt.isEmpty()) throw Exception("سجّل الدخول")
        val r = JSONObject(
            http(
                "POST", "https://securetoken.googleapis.com/v1/token?key=${Cfg.KEY}",
                "grant_type=refresh_token&refresh_token=$rt", "application/x-www-form-urlencoded"
            )
        )
        saveTokens(r, "id_token", "refresh_token", "expires_in")
        return idToken
    }

    private fun reload(done: () -> Unit) {
        io.execute {
            try {
                val t = http("GET", "${Cfg.DB}/devices.json?auth=${token()}")
                val m = LinkedHashMap<String, JSONObject>()
                if (t.trim() != "null") {
                    val o = JSONObject(t)
                    o.keys().forEach { m[it] = o.getJSONObject(it) }
                }
                ui.post { devices = m; done() }
            } catch (e: Exception) {
                ui.post { toast("تعذّر التحميل: " + friendly(e)); done() }
            }
        }
    }

    // ---------- screens ----------
    private fun showLogin() {
        onBack = null
        val col = column().apply { gravity = Gravity.CENTER }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(dp(110), dp(110)))
        col.addView(TextView(this).apply {
            text = "AJIPTV Admin"; setTextColor(Color.WHITE); textSize = 24f
            typeface = Typeface.SERIF; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10))
        })
        val email = field("الإيميل", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        email.setText(prefs.getString("email", ""))
        val pw = field("كلمة المرور", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val err = TextView(this).apply { setTextColor(Color.parseColor("#FF6B6B")); gravity = Gravity.CENTER }
        val btn = button("دخول", true)
        btn.setOnClickListener {
            val e = email.text.toString().trim(); val p = pw.text.toString()
            if (e.isEmpty() || p.isEmpty()) { err.text = "اكتب الإيميل وكلمة المرور"; return@setOnClickListener }
            btn.isEnabled = false; err.text = "جارٍ الدخول..."
            io.execute {
                try {
                    signIn(e, p)
                    ui.post { reload { showList() } }
                } catch (ex: Exception) {
                    ui.post { btn.isEnabled = true; err.text = friendly(ex) }
                }
            }
        }
        col.addView(email, lp()); col.addView(pw, lp()); col.addView(err, lp()); col.addView(btn, lp(14))
        setContentView(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(col) })
    }

    private fun label(id: String, d: JSONObject): String {
        val exp = d.optString("exp")
        val st = when {
            !d.optBoolean("active", true) -> "🔴 موقوف"
            exp.isNotEmpty() && exp < today() -> "🟠 منتهي"
            else -> "🟢 فعّال"
        }
        val name = d.optString("name").ifEmpty { "بدون اسم" }
        return name + "\n" + pretty(id) + "  •  " + st + (if (exp.isNotEmpty()) "  •  $exp" else "")
    }

    private fun showList() {
        onBack = null
        val col = column()
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.SERIF }
        val out = button("خروج")
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); head.addView(out)
        val search = field("بحث: اسم، رمز، أو يوزر")
        val list = ListView(this).apply { divider = null; setBackgroundColor(bg) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val add = button("＋ إضافة جهاز", true)
        val refresh = button("🔄 تحديث")
        bar.addView(add, LinearLayout.LayoutParams(0, -2, 2f).apply { rightMargin = dp(8) })
        bar.addView(refresh, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(head); col.addView(search, lp()); col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        col.addView(bar, lp())

        var shown: List<String> = emptyList()
        fun render() {
            val q = search.text.toString().trim().lowercase()
            shown = devices.keys.filter { k ->
                val d = devices[k]!!
                q.isEmpty() || k.lowercase().contains(q) || d.optString("name").lowercase().contains(q) ||
                    d.optString("user").lowercase().contains(q)
            }.sortedBy { devices[it]!!.optString("name").lowercase() }
            title.text = "الأجهزة (" + devices.size + ")"
            list.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, shown.map { label(it, devices[it]!!) }) {
                override fun getView(p: Int, v: View?, g: ViewGroup): View {
                    val t = super.getView(p, v, g) as TextView
                    t.setTextColor(Color.WHITE); t.textSize = 16f; t.setPadding(dp(8), dp(14), dp(8), dp(14))
                    return t
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = render()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        list.setOnItemClickListener { _, _, i, _ -> showEdit(shown[i]) }
        add.setOnClickListener { showEdit(null) }
        refresh.setOnClickListener { reload { render() } }
        out.setOnClickListener {
            prefs.edit().remove("refresh").apply(); idToken = ""; devices.clear(); showLogin()
        }
        render()
        setContentView(col)
    }

    private fun showEdit(id: String?) {
        onBack = { showList() }
        val d = if (id != null) devices[id] else null
        val col = column()
        col.addView(TextView(this).apply {
            text = if (id == null) "جهاز جديد" else "تعديل الجهاز"
            setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.SERIF
        })
        val idF = field("رمز الجهاز (8 أحرف/أرقام، يظهر عند الزبون)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)
        if (id != null) { idF.setText(pretty(id)); idF.isEnabled = false }
        val nameF = field("اسم الزبون"); nameF.setText(d?.optString("name").orEmpty())
        val hostF = field("السيرفر (host)", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        hostF.setText(d?.optString("host") ?: prefs.getString("host", "Maveniptv.tv"))
        val portF = field("البورت", InputType.TYPE_CLASS_NUMBER)
        portF.setText(d?.optInt("port", 0)?.takeIf { it > 0 }?.toString() ?: prefs.getString("port", "2095"))
        val userF = field("اسم المستخدم"); userF.setText(d?.optString("user").orEmpty())
        val passF = field("الباسورد"); passF.setText(d?.optString("pass").orEmpty())
        val expF = field("تاريخ الانتهاء (yyyy-MM-dd) أو فاضي")
        expF.setText(d?.optString("exp").orEmpty())
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun addMonths(m: Int) {
            val cal = Calendar.getInstance()
            val cur = try { fmt.parse(expF.text.toString().trim()) } catch (e: Exception) { null }
            if (cur != null && cur.after(cal.time)) cal.time = cur
            cal.add(Calendar.MONTH, m)
            expF.setText(fmt.format(cal.time))
        }
        for ((label, m) in listOf("+ شهر" to 1, "+ 3 أشهر" to 3, "+ سنة" to 12)) {
            val b = button(label)
            b.setOnClickListener { addMonths(m) }
            quick.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        }
        val activeCb = CheckBox(this).apply {
            text = "الحساب فعّال"; setTextColor(Color.WHITE); isChecked = d?.optBoolean("active", true) ?: true
        }
        val noteF = field("ملاحظة (إلك فقط)"); noteF.setText(d?.optString("note").orEmpty())
        val msgF = field("رسالة بتظهر للزبون (اختياري)"); msgF.setText(d?.optString("msg").orEmpty())
        val save = button("حفظ", true)
        val share = button("📤 إرسال رابط التحميل للزبون")
        val del = button("🗑 حذف الجهاز")

        listOf(idF, nameF, hostF, portF, userF, passF, expF).forEach { col.addView(it, lp()) }
        col.addView(quick, lp()); col.addView(activeCb, lp()); col.addView(noteF, lp()); col.addView(msgF, lp())
        col.addView(save, lp(16)); col.addView(share, lp())
        if (id != null) col.addView(del, lp())

        save.setOnClickListener {
            val rawId = (id ?: idF.text.toString()).uppercase().filter { it.isLetterOrDigit() }
            val exp = expF.text.toString().trim()
            when {
                rawId.length != 8 -> { toast("رمز الجهاز لازم يكون 8 أحرف/أرقام"); return@setOnClickListener }
                userF.text.isBlank() || passF.text.isBlank() -> { toast("اكتب اسم المستخدم والباسورد"); return@setOnClickListener }
                exp.isNotEmpty() && !Regex("\\d{4}-\\d{2}-\\d{2}").matches(exp) -> {
                    toast("التاريخ لازم بهالشكل: 2026-12-31"); return@setOnClickListener
                }
            }
            val host = hostF.text.toString().trim()
            val port = portF.text.toString().trim().toIntOrNull() ?: 0
            val o = JSONObject()
                .put("name", nameF.text.toString().trim()).put("host", host).put("port", port)
                .put("user", userF.text.toString().trim()).put("pass", passF.text.toString().trim())
                .put("exp", exp).put("active", activeCb.isChecked)
                .put("note", noteF.text.toString().trim()).put("msg", msgF.text.toString().trim())
                .put("updated", System.currentTimeMillis())
            save.isEnabled = false
            io.execute {
                try {
                    http("PUT", "${Cfg.DB}/devices/$rawId.json?auth=${token()}", o.toString())
                    prefs.edit().putString("host", host).putString("port", port.toString()).apply()
                    ui.post { toast("تم الحفظ"); reload { showList() } }
                } catch (e: Exception) {
                    ui.post { save.isEnabled = true; toast("فشل الحفظ: " + friendly(e)) }
                }
            }
        }
        share.setOnClickListener {
            val text = "حمّل تطبيق AJIPTV من هنا:\n" + Cfg.APK +
                "\n\nبعد التثبيت بيظهر لك رمز الجهاز بالشاشة الأولى. ابعتلي إياه وبفعّل حسابك."
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "إرسال"
                )
            )
        }
        del.setOnClickListener {
            AlertDialog.Builder(this).setMessage("حذف هذا الجهاز؟ التطبيق عند الزبون بيضل يشتغل ببياناته المحفوظة.")
                .setPositiveButton("حذف") { _, _ ->
                    io.execute {
                        try {
                            http("DELETE", "${Cfg.DB}/devices/$id.json?auth=${token()}")
                            ui.post { toast("تم الحذف"); reload { showList() } }
                        } catch (e: Exception) {
                            ui.post { toast("فشل الحذف: " + friendly(e)) }
                        }
                    }
                }.setNegativeButton("إلغاء", null).show()
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(col) })
    }
}

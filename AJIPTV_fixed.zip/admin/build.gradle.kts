plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toInt()

android {
    namespace = "com.aj.iptv.admin"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aj.iptv.admin"; minSdk = 21; targetSdk = 34
        versionCode = 100 + runNo; versionName = "1.1.$runNo"
    }
    signingConfigs {
        create("fixed") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null) {
                storeFile = file(ks); storeType = "pkcs12"
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (System.getenv("KEYSTORE_FILE") != null) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}

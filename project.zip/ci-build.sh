#!/usr/bin/env bash
# Builds both apps. Tries FFmpeg audio with matching media3 versions, shows why a try failed
# (on the run summary page), and finally builds without FFmpeg so there is always an APK.
set +e

summarize() {   # $1 = title, $2 = log file, $3 = annotation level (warning|error)
  local lines msg
  lines=$(grep -E "^e: |error:|What went wrong|Could not resolve|Could not find|Execution failed|Manifest merger failed|Unresolved reference|Duplicate class" -A2 "$2" | head -30)
  [ -z "$lines" ] && lines=$(tail -n 25 "$2")
  {
    echo "### $1"
    echo '```'
    echo "$lines"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
  msg=$(echo "$lines" | head -12 | sed 's/%/%25/g' | sed ':a;N;$!ba;s/\n/%0A/g')
  echo "::$3 title=$1::$msg"
}

attempt() {   # $1 = log name, rest = extra gradle args
  local name="$1"; shift
  gradle assembleDebug --no-daemon "$@" 2>&1 | tee "build-$name.log"
  return "${PIPESTATUS[0]}"
}

for combo in "1.3.1 1.3.1+1" "1.4.1 1.4.1+1"; do
  set -- $combo
  if attempt "ff-$1" "-Pmedia3=$1" "-PffVer=$2"; then
    echo "### Build OK - with FFmpeg audio (media3 $1 + decoder $2)" >> "$GITHUB_STEP_SUMMARY"
    exit 0
  fi
  summarize "FFmpeg build failed (media3 $1 + decoder $2)" "build-ff-$1.log" warning
done

if attempt plain; then
  echo "### Build OK - WITHOUT FFmpeg (fallback)" >> "$GITHUB_STEP_SUMMARY"
  exit 0
fi
summarize "Build failed" build-plain.log error
exit 1

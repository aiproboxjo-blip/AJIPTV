#!/usr/bin/env bash
# Builds both apps with the NEWEST players first, then falls back step by step so there is always an APK:
#   1) newest tools: AGP 8.10.1 / Gradle 8.11.1 / compileSdk 36, Media3 (ExoPlayer) 1.11.1 + libVLC 3.7.6
#   2) known tools:  Media3 1.4.1 + libVLC 3.7.6
#   3) known tools:  Media3 1.4.1 + libVLC 3.6.0
#   4) ExoPlayer only
# Why a try failed is shown on the run summary page and inside the app (Settings > build info).
set +e

INFO=app/src/main/assets/build_info.txt
mkdir -p app/src/main/assets
echo "run #${GITHUB_RUN_NUMBER:-?}" > "$INFO"

errlines() {   # $1 = log file
  local l
  l=$(grep -E "^e: |error:|What went wrong|Could not resolve|Could not find|Execution failed|Manifest merger failed|Unresolved reference|Duplicate class|minSdk|requires libraries" -A2 "$1" | head -30)
  [ -z "$l" ] && l=$(tail -n 25 "$1")
  echo "$l"
}

summarize() {   # $1 = title, $2 = log file, $3 = annotation level (warning|error)
  local lines msg
  [ -f "$2" ] || echo "(no log)" > "$2"
  lines=$(errlines "$2")
  {
    echo "### $1"
    echo '```'
    echo "$lines"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
  {
    echo
    echo "FAILED: $1"
    echo "$lines" | head -14 | cut -c1-200
  } >> "$INFO"
  msg=$(echo "$lines" | head -12 | sed 's/%/%25/g' | sed ':a;N;$!ba;s/\n/%0A/g')
  echo "::$3 title=$1::$msg"
}

restore() { unzip -qo project.zip -x ci-build.sh; }   # back to the known-good build files

latest_tools() {
  echo "TOOLS: AGP 8.10.1 / Gradle 8.11.1 / compileSdk 36 / minSdk 23" >> "$INFO"
  sed -i 's/version "8.5.2"/version "8.10.1"/' build.gradle.kts
  sed -i 's/compileSdk = 34/compileSdk = 36/; s/minSdk = 21/minSdk = 23/' app/build.gradle.kts admin/build.gradle.kts
  echo "android.suppressUnsupportedCompileSdk=36" >> gradle.properties
}

gradle_bin() {   # $1 = version; prints the path of that Gradle (downloads it once)
  local v="$1" d="$HOME/gradle-dist-$1"
  if [ ! -x "$d/gradle-$v/bin/gradle" ]; then
    mkdir -p "$d"
    curl -fsSL "https://services.gradle.org/distributions/gradle-$v-bin.zip" -o "$d/g.zip" && unzip -q "$d/g.zip" -d "$d"
  fi
  echo "$d/gradle-$v/bin/gradle"
}

attempt() {   # $1 = log name, $2 = gradle binary, rest = extra gradle args
  local name="$1" bin="$2"
  shift 2
  echo "TRY: $name $*" >> "$INFO"
  "$bin" assembleDebug --no-daemon "$@" 2>&1 | tee "build-$name.log"
  return "${PIPESTATUS[0]}"
}

ok() { echo "### Build OK - $1" >> "$GITHUB_STEP_SUMMARY"; }

# 1) newest everything
latest_tools
G=$(gradle_bin 8.11.1)
if [ -x "$G" ] && attempt "latest" "$G" -Pmedia3=1.11.1 -PvlcVer=3.7.6; then
  ok "NEWEST: Media3 1.11.1 + libVLC 3.7.6"
  exit 0
fi
summarize "Newest build failed (Media3 1.11.1 + libVLC 3.7.6)" build-latest.log warning
restore

# 2) and 3) known tools with VLC
for v in 3.7.6 3.6.0; do
  if attempt "vlc-$v" gradle "-PvlcVer=$v"; then
    ok "Media3 1.4.1 + libVLC $v"
    exit 0
  fi
  summarize "VLC build failed (libVLC $v)" "build-vlc-$v.log" warning
done

# 4) ExoPlayer only
if attempt plain gradle; then
  ok "ExoPlayer only (no VLC)"
  exit 0
fi
summarize "Build failed" build-plain.log error
exit 1

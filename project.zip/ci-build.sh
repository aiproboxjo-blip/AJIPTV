#!/usr/bin/env bash
# Builds both apps. Tries with FFmpeg audio first; if that fails it shows why
# (on the run summary page) and builds again without FFmpeg, so there is always an APK.
set +e

summarize() {   # $1 = title, $2 = log file, $3 = annotation level (warning|error)
  local lines msg
  lines=$(grep -E "^e: |error:|What went wrong|Could not resolve|Could not find|Execution failed|Manifest merger failed|Unresolved reference|Duplicate class" -A2 "$2" | head -30)
  [ -z "$lines" ] && lines=$(tail -n 25 "$2")
  {
    echo "### $1"
    echo '```'
    echo "$lines"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
  msg=$(echo "$lines" | head -12 | sed 's/%/%25/g' | sed ':a;N;$!ba;s/\n/%0A/g')
  echo "::$3 title=$1::$msg"
}

gradle assembleDebug --no-daemon -PwithFfmpeg=true 2>&1 | tee build-ffmpeg.log
if [ "${PIPESTATUS[0]}" -eq 0 ]; then
  echo "### Build OK - with FFmpeg audio" >> "$GITHUB_STEP_SUMMARY"
  exit 0
fi
summarize "FFmpeg build failed" build-ffmpeg.log warning

gradle assembleDebug --no-daemon 2>&1 | tee build-plain.log
if [ "${PIPESTATUS[0]}" -eq 0 ]; then
  echo "### Build OK - WITHOUT FFmpeg (fallback)" >> "$GITHUB_STEP_SUMMARY"
  exit 0
fi
summarize "Build failed" build-plain.log error
exit 1

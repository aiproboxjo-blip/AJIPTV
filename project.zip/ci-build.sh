#!/usr/bin/env bash
# Builds both apps with ALL engines (ExoPlayer + FFmpeg audio decoders + VLC), newest first,
# then falls back step by step so there is always an APK. Why a try failed is shown on the
# run summary page and inside the app (Settings > build info).
set +e

INFO=app/src/main/assets/build_info.txt
mkdir -p app/src/main/assets
echo "run #${GITHUB_RUN_NUMBER:-?}" > "$INFO"

errlines() {   # $1 = log file
  local l
  l=$(grep -E "^e: |error:|What went wrong|Could not resolve|Could not find|Execution failed|Manifest merger failed|Unresolved reference|Duplicate class|minSdk|requires libraries" -A2 "$1" | head -30)
  [ -z "$l" ] && l=$(tail -n 25 "$1")
  echo "$l"
}

summarize() {   # $1 = title, $2 = log file, $3 = annotation level (warning|error)
  local lines msg
  [ -f "$2" ] || echo "(no log)" > "$2"
  lines=$(errlines "$2")
  {
    echo "### $1"
    echo '```'
    echo "$lines"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
  {
    echo
    echo "FAILED: $1"
    echo "$lines" | head -14 | cut -c1-200
  } >> "$INFO"
  msg=$(echo "$lines" | head -12 | sed 's/%/%25/g' | sed ':a;N;$!ba;s/\n/%0A/g')
  echo "::$3 title=$1::$msg"
}

restore() { unzip -qo project.zip -x ci-build.sh; }   # back to the known-good build files

latest_tools() {
  echo "TOOLS: AGP 8.10.1 / Gradle 8.11.1 / compileSdk 36 / minSdk 23" >> "$INFO"
  sed -i 's/version "8.5.2"/version "8.10.1"/' build.gradle.kts
  sed -i 's/compileSdk = 34/compileSdk = 36/; s/minSdk = 21/minSdk = 23/' app/build.gradle.kts admin/build.gradle.kts
  echo "android.suppressUnsupportedCompileSdk=36" >> gradle.properties
}

gradle_bin() {   # $1 = version; prints the path of that Gradle (downloads it once)
  local v="$1" d="$HOME/gradle-dist-$1"
  if [ ! -x "$d/gradle-$v/bin/gradle" ]; then
    mkdir -p "$d"
    curl -fsSL "https://services.gradle.org/distributions/gradle-$v-bin.zip" -o "$d/g.zip" && unzip -q "$d/g.zip" -d "$d"
  fi
  echo "$d/gradle-$v/bin/gradle"
}

try_build() {   # $1 = name, $2 = tools (latest|known), rest = -P arguments
  local name="$1" tools="$2" bin=gradle
  shift 2
  restore
  if [ "$tools" = latest ]; then
    latest_tools
    bin=$(gradle_bin 8.11.1)
    [ -x "$bin" ] || { echo "could not download Gradle 8.11.1" > "build-$name.log"; return 1; }
  fi
  echo "TRY: $name $*" >> "$INFO"
  "$bin" assembleDebug --no-daemon "$@" 2>&1 | tee "build-$name.log"
  return "${PIPESTATUS[0]}"
}

ok() { echo "### Build OK - $1" >> "$GITHUB_STEP_SUMMARY"; }

# name | tools | gradle properties        (media3 = ExoPlayer, ffVer = FFmpeg decoder, vlcVer = libVLC)
TRIES=(
  "all-latest|latest|-Pmedia3=1.9.0 -PffVer=1.9.0+1 -PvlcVer=3.7.6"
  "exo-latest|latest|-Pmedia3=1.11.1 -PvlcVer=3.7.6"
  "all-known|known|-Pmedia3=1.3.1 -PffVer=1.3.1+1 -PvlcVer=3.7.6"
  "vlc-known|known|-PvlcVer=3.7.6"
  "vlc-old|known|-PvlcVer=3.6.0"
)

for t in "${TRIES[@]}"; do
  IFS='|' read -r name tools args <<< "$t"
  if try_build "$name" "$tools" $args; then
    ok "$name  ($args)"
    exit 0
  fi
  summarize "Build failed: $name ($args)" "build-$name.log" warning
done

# last resort: ExoPlayer only
restore
echo "TRY: plain" >> "$INFO"
gradle assembleDebug --no-daemon 2>&1 | tee build-plain.log
if [ "${PIPESTATUS[0]}" -eq 0 ]; then
  ok "ExoPlayer only (no VLC, no FFmpeg)"
  exit 0
fi
summarize "Build failed" build-plain.log error
exit 1

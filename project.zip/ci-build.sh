#!/usr/bin/env bash
# Builds both apps. Tries the built-in VLC engine (two libvlc versions), records why a try failed
# (on the run summary page AND inside the app: Settings > build info), and finally builds
# without FFmpeg so there is always an APK.
set +e

INFO=app/src/main/assets/build_info.txt
mkdir -p app/src/main/assets
echo "run #${GITHUB_RUN_NUMBER:-?}" > "$INFO"

errlines() {   # $1 = log file
  local l
  l=$(grep -E "^e: |error:|What went wrong|Could not resolve|Could not find|Execution failed|Manifest merger failed|Unresolved reference|Duplicate class|minSdk" -A2 "$1" | head -30)
  [ -z "$l" ] && l=$(tail -n 25 "$1")
  echo "$l"
}

summarize() {   # $1 = title, $2 = log file, $3 = annotation level (warning|error)
  local lines msg
  lines=$(errlines "$2")
  {
    echo "### $1"
    echo '```'
    echo "$lines"
    echo '```'
  } >> "$GITHUB_STEP_SUMMARY"
  {
    echo
    echo "FAILED: $1"
    echo "$lines" | head -14 | cut -c1-200
  } >> "$INFO"
  msg=$(echo "$lines" | head -12 | sed 's/%/%25/g' | sed ':a;N;$!ba;s/\n/%0A/g')
  echo "::$3 title=$1::$msg"
}

attempt() {   # $1 = log name, rest = extra gradle args
  local name="$1"; shift
  echo "TRY: $name $*" >> "$INFO"
  gradle assembleDebug --no-daemon "$@" 2>&1 | tee "build-$name.log"
  return "${PIPESTATUS[0]}"
}

for v in 3.6.0 3.7.6; do
  if attempt "vlc-$v" "-PvlcVer=$v"; then
    echo "### Build OK - with VLC engine (libvlc $v)" >> "$GITHUB_STEP_SUMMARY"
    exit 0
  fi
  summarize "VLC build failed (libvlc $v)" "build-vlc-$v.log" warning
done

if attempt plain; then
  echo "### Build OK - WITHOUT VLC (fallback)" >> "$GITHUB_STEP_SUMMARY"
  exit 0
fi
summarize "Build failed" build-plain.log error
exit 1

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// Each GitHub build gets a higher number, so updates install over the old app.
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toInt()

android {
    namespace = "com.aj.iptv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aj.iptv"; minSdk = 21; targetSdk = 34
        versionCode = 100 + runNo; versionName = "2.2.$runNo"
    }
    signingConfigs {
        create("fixed") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null) {
                storeFile = file(ks); storeType = "pkcs12"
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (System.getenv("KEYSTORE_FILE") != null) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    // FFmpeg software audio decoders (AC3, E-AC3, DTS, TrueHD...) for devices without them
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+1")
}

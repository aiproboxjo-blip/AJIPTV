package com.aj.iptv.player

import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.aj.iptv.Img
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * Second playback engine (LibVLC) inside the app. It decodes AC3 / E-AC3 / DTS and most
 * odd formats in software, so content plays with sound without any external app.
 * Uses the same PlayQueue as the ExoPlayer screen.
 */
class VlcActivity : AppCompatActivity() {

    private var vlc: LibVLC? = null
    private var mp: MediaPlayer? = null
    private lateinit var video: VLCVideoLayout
    private lateinit var spinner: ProgressBar
    private lateinit var title: TextView
    private lateinit var bar: LinearLayout
    private lateinit var chList: ListView
    private lateinit var pill: LinearLayout
    private lateinit var pillIcon: ImageView
    private lateinit var pillName: TextView
    private lateinit var pillL1: TextView
    private lateinit var pillL2: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private var index = 0
    private var live = true
    private var resumed = false
    private var scaleIdx = 0
    private val scales = arrayOf(
        MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
        MediaPlayer.ScaleType.SURFACE_BEST_FIT,
        MediaPlayer.ScaleType.SURFACE_FILL
    )
    private val scaleNames = arrayOf("ملء الشاشة", "ملائم", "تمديد")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setBackgroundDrawable(ColorDrawable(0xFF000000.toInt()))
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        if (PlayQueue.urls.isEmpty()) { finish(); return }
        index = intent.getIntExtra("index", 0).coerceIn(0, PlayQueue.urls.size - 1)
        live = intent.getBooleanExtra("live", true)
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    chList.visibility == View.VISIBLE -> hideList()
                    bar.visibility == View.VISIBLE -> bar.visibility = View.GONE
                    else -> finish()
                }
            }
        })

        val v = LibVLC(this, arrayListOf("--network-caching=1500", "--no-drop-late-frames", "--no-skip-frames"))
        vlc = v
        val p = MediaPlayer(v)
        mp = p
        p.attachViews(video, null, false, false)
        p.setVideoScale(scales[scaleIdx])
        p.setEventListener { e -> onEvent(e) }
        start()
    }

    // ---------- UI ----------
    private fun btn(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        video = VLCVideoLayout(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1))
        spinner = ProgressBar(this)
        root.addView(spinner, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            setShadowLayer(6f, 0f, 0f, 0xFF000000.toInt()); setPadding(32, 24, 32, 0)
        }
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        if (live) {
            bar.addView(btn("القنوات") { bar.visibility = View.GONE; showList() })
        } else {
            bar.addView(btn("⏪") { seek(-Seek.stepMs(prefs)) })
            bar.addView(btn("⏯") { togglePause() })
            bar.addView(btn("⏩") { seek(Seek.stepMs(prefs)) })
        }
        bar.addView(btn("الصوت") { audioDialog() })
        bar.addView(btn("نسبة العرض") {
            scaleIdx = (scaleIdx + 1) % scales.size
            mp?.setVideoScale(scales[scaleIdx])
            title.text = scaleNames[scaleIdx]
        })
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))

        val maxW = (resources.displayMetrics.widthPixels * 0.6).toInt()
        pillIcon = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x22FFFFFF) }
            clipToOutline = true
        }
        pillName = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; maxWidth = maxW
        }
        pillL1 = TextView(this).apply { setTextColor(0xFF7FB0FF.toInt()); textSize = 13f; maxLines = 1; maxWidth = maxW }
        pillL2 = TextView(this).apply {
            setTextColor(0xFFC9D1DB.toInt()); textSize = 12f; maxLines = 1; maxWidth = maxW
            ellipsize = TextUtils.TruncateAt.END
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 8, 0) }
        texts.addView(pillName); texts.addView(pillL1); texts.addView(pillL2)
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 44, 16); visibility = View.GONE
            background = GradientDrawable().apply {
                setColor(0xD90A0F18.toInt()); setStroke(2, 0x884C8DFF.toInt()); cornerRadius = 200f
            }
        }
        pill.addView(pillIcon, LinearLayout.LayoutParams(88, 88))
        pill.addView(texts)
        root.addView(
            pill,
            FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = (resources.displayMetrics.heightPixels * 0.06).toInt() }
        )

        chList = ListView(this).apply {
            visibility = View.GONE
            divider = null
            setBackgroundColor(0xE6080B10.toInt())
            selector = ColorDrawable(0x55D9B26B)
            setOnItemClickListener { _, _, i, _ -> savePos(); index = i; start(); hideList() }
        }
        root.addView(chList, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.38).toInt(), -1, Gravity.START))

        root.setOnClickListener { toggleBar() }
        setContentView(root)
    }

    private fun toggleBar() {
        bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (bar.visibility == View.VISIBLE) bar.getChildAt(0)?.requestFocus()
    }

    private fun showList() {
        val labels = PlayQueue.names.mapIndexed { i, n -> (if (i == index) "▶ " else "") + n }
        chList.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, labels) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(0xFFFFFFFF.toInt()); t.textSize = 17f
                t.setPadding(32, 24, 32, 24); t.maxLines = 1; t.ellipsize = TextUtils.TruncateAt.END
                return t
            }
        }
        chList.visibility = View.VISIBLE
        chList.setSelection(index)
        chList.requestFocus()
    }

    private fun hideList() {
        chList.visibility = View.GONE
    }

    private fun audioDialog() {
        val p = mp ?: return
        val tr = p.audioTracks ?: return
        val names = tr.map { it.name ?: ("Track " + it.id) }.toTypedArray()
        AlertDialog.Builder(this).setTitle("اختر الصوت")
            .setItems(names) { _, i -> p.setAudioTrack(tr[i].id) }
            .show()
    }

    // ---------- info pill ----------
    private val tick = object : Runnable {
        override fun run() {
            val (l1, l2) = lines()
            pillL1.text = l1
            pillL2.text = l2
            if (pill.visibility == View.VISIBLE) handler.postDelayed(this, 1000)
        }
    }
    private val hideInfo = Runnable { pill.visibility = View.GONE }

    private fun lines(): Pair<String, String> {
        val p = mp ?: return Pair("", "")
        val v = p.currentVideoTrack
        val l1 = if (v != null && v.width > 0) {
            val fps = if (v.frameRateDen > 0) Math.round(v.frameRateNum.toFloat() / v.frameRateDen) else 0
            listOf(
                StreamInfo.quality(v.width, v.height), "${v.width}x${v.height}",
                if (fps > 0) "${fps}fps" else "", "VLC"
            ).filter { it.isNotEmpty() }.joinToString("  •  ")
        } else {
            "VLC  •  جارٍ قياس الجودة..."
        }
        val cur = p.audioTrack
        val aud = p.audioTracks?.firstOrNull { it.id == cur }?.name.orEmpty()
        val st = p.media?.stats
        val lost = if (st != null && st.lostPictures > 0) "⚠ ${st.lostPictures} إطار" else ""
        val l2 = listOf(if (aud.isNotEmpty()) "🔊 $aud" else "", "🚀 محرك VLC", lost)
            .filter { it.isNotEmpty() }.joinToString("  •  ")
        return Pair(l1, l2)
    }

    private fun flashInfo() {
        pillName.text = PlayQueue.names.getOrElse(index) { "" }
        val icon = PlayQueue.icons.getOrElse(index) { "" }
        if (icon.isBlank()) {
            pillIcon.visibility = View.GONE
        } else {
            pillIcon.visibility = View.VISIBLE
            Img.load(icon, pillIcon, 96)
        }
        pill.visibility = View.VISIBLE
        handler.removeCallbacks(tick); handler.post(tick)
        handler.removeCallbacks(hideInfo); handler.postDelayed(hideInfo, 8000)
    }

    // ---------- playback ----------
    private fun posKey() = "pos_" + PlayQueue.urls[index].hashCode()

    private fun start() {
        val p = mp ?: return
        resumed = false
        title.text = PlayQueue.names[index]
        spinner.visibility = View.VISIBLE
        val m = Media(vlc!!, Uri.parse(PlayQueue.urls[index]))
        m.setHWDecoderEnabled(true, false)
        p.setMedia(m)
        m.release()
        p.play()
        flashInfo()
    }

    private fun onEvent(e: MediaPlayer.Event) {
        when (e.type) {
            MediaPlayer.Event.Buffering ->
                spinner.visibility = if (e.buffering < 100f) View.VISIBLE else View.GONE
            MediaPlayer.Event.Playing -> {
                spinner.visibility = View.GONE
                if (!resumed && !live) {
                    resumed = true
                    val s = prefs.getLong(posKey(), 0L)
                    if (s > 10_000L) mp?.setTime(s)
                }
                flashInfo()
            }
            MediaPlayer.Event.EndReached -> {
                if (!live) {
                    prefs.edit().remove(posKey()).apply()
                    if (index < PlayQueue.urls.size - 1) { index++; start() }
                }
            }
            MediaPlayer.Event.EncounteredError -> {
                spinner.visibility = View.GONE
                title.text = "تعذّر التشغيل: " + PlayQueue.names[index]
            }
        }
    }

    private fun savePos() {
        val p = mp ?: return
        if (live) return
        val d = p.length
        val t = p.time
        val e = prefs.edit()
        if (d > 0 && t > d - 30_000L) e.remove(posKey()) else e.putLong(posKey(), t)
        e.apply()
    }

    private fun zap(d: Int) {
        val n = PlayQueue.urls.size
        index = (index + d + n) % n
        start()
    }

    private fun seek(ms: Long) {
        val p = mp ?: return
        val len = p.length
        var t = p.time + ms
        t = if (len > 0) t.coerceIn(0L, maxOf(0L, len - 1000L)) else t.coerceAtLeast(0L)
        p.setTime(t)
        title.text = (if (ms > 0) "⏩ +" else "⏪ -") + Seek.label(Math.abs(ms)) + "   " + Seek.time(t) +
            (if (len > 0) " / " + Seek.time(len) else "")
    }

    private fun togglePause() {
        val p = mp ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    /** Live: up/down change channel, OK opens the list. Movies: OK pauses, left/right seek. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (::chList.isInitialized && e.action == KeyEvent.ACTION_DOWN) {
            if (chList.visibility == View.VISIBLE) {
                if (e.keyCode == KeyEvent.KEYCODE_MENU) { hideList(); return true }
                return super.dispatchKeyEvent(e)
            }
            if (bar.visibility == View.VISIBLE) {
                if (e.keyCode == KeyEvent.KEYCODE_MENU) { bar.visibility = View.GONE; return true }
                return super.dispatchKeyEvent(e)
            }
            when (e.keyCode) {
                KeyEvent.KEYCODE_MENU -> { toggleBar(); return true }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> if (live) { zap(1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> if (live) { zap(-1); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> if (!live) { seek(-Seek.accelerate(Seek.stepMs(prefs), e.repeatCount)); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT -> if (!live) { seek(Seek.accelerate(Seek.stepMs(prefs), e.repeatCount)); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (live) showList() else togglePause()
                    return true
                }
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePause(); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onStop() {
        super.onStop()
        savePos()
        mp?.pause()
    }

    override fun onStart() {
        super.onStart()
        mp?.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        try {
            mp?.stop()
            mp?.detachViews()
            mp?.release()
            vlc?.release()
        } catch (_: Exception) { }
    }
}

package com.aj.iptv.player

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.BehindLiveWindowException
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/** Builds Xtream Codes stream URLs. */
object Xtream {
    const val HOST = "Maveniptv.tv"
    const val PORT = 2095

    fun live(user: String, pass: String, streamId: String, ext: String = "m3u8") =
        "http://$HOST:$PORT/live/$user/$pass/$streamId.$ext"

    fun movie(user: String, pass: String, id: String, ext: String = "mp4") =
        "http://$HOST:$PORT/movie/$user/$pass/$id.$ext"

    fun episode(user: String, pass: String, id: String, ext: String = "mp4") =
        "http://$HOST:$PORT/series/$user/$pass/$id.$ext"
}

/** Playlist handed from the lists to the player (same process, no Intent size limits). */
object PlayQueue {
    var urls: List<String> = emptyList()
    var names: List<String> = emptyList()
}

/**
 * One ExoPlayer reused for every channel (fast zapping), buffer sized by preset,
 * short network timeouts, automatic retry.
 */
@OptIn(UnstableApi::class)
class AjPlayer(context: Context, live: Boolean, buf: Int, tunnel: Boolean = false) {

    enum class State { LOADING, PLAYING, ERROR, ENDED }

    var onState: ((State) -> Unit)? = null
    var lastError: PlaybackException? = null

    private var currentUrl: String? = null
    private var retries = 0

    private val http = DefaultHttpDataSource.Factory()
        .setUserAgent("AJIPTV/1.6")
        .setConnectTimeoutMs(8_000)
        .setReadTimeoutMs(8_000)
        .setAllowCrossProtocolRedirects(true)

    private val b = buf.coerceIn(0, 2)

    private val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            if (live) intArrayOf(15_000, 25_000, 40_000)[b] else intArrayOf(25_000, 40_000, 60_000)[b],
            if (live) intArrayOf(30_000, 50_000, 80_000)[b] else intArrayOf(50_000, 70_000, 90_000)[b],
            1_000,
            2_500
        )
        .setTargetBufferBytes(intArrayOf(40, 80, 128)[b] * 1024 * 1024)
        .setPrioritizeTimeOverSizeThresholds(false)
        .build()

    // 4K: always pick the highest supported quality; optional tunneled playback for TV chipsets
    private val selector = DefaultTrackSelector(context.applicationContext).also {
        it.parameters = it.buildUponParameters()
            .setForceHighestSupportedBitrate(true)
            .setTunnelingEnabled(tunnel)
            .build()
    }

    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext)
        .setTrackSelector(selector)
        .setMediaSourceFactory(DefaultMediaSourceFactory(http))
        .setLoadControl(loadControl)
        .setRenderersFactory(
            DefaultRenderersFactory(context.applicationContext)
                .setEnableDecoderFallback(true)
                .forceEnableMediaCodecAsynchronousQueueing()
        )
        .setAudioAttributes(AudioAttributes.DEFAULT, true)
        .setHandleAudioBecomingNoisy(true)
        .build()
        .also { it.playWhenReady = true }

    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> onState?.invoke(State.LOADING)
                    Player.STATE_READY -> { retries = 0; onState?.invoke(State.PLAYING) }
                    Player.STATE_ENDED -> onState?.invoke(State.ENDED)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                lastError = error
                if (error.cause is BehindLiveWindowException) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                if (retries < 3) {
                    retries++
                    player.prepare()
                } else {
                    onState?.invoke(State.ERROR)
                }
            }
        })
    }

    fun play(url: String, startMs: Long = 0L) {
        if (url == currentUrl && startMs == 0L && player.playbackState != Player.STATE_IDLE) return
        currentUrl = url
        retries = 0
        onState?.invoke(State.LOADING)
        player.setMediaItem(MediaItem.fromUri(url), if (startMs > 0L) startMs else C.TIME_UNSET)
        player.prepare()
    }

    fun stop() = player.stop()
    fun pause() = player.pause()
    fun resume() = player.play()
    fun release() = player.release()
}

/** Full-screen player. Queue comes from PlayQueue; extras: "index", "live". */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var aj: AjPlayer
    private lateinit var pv: PlayerView
    private lateinit var title: TextView
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private var index = 0
    private var live = true
    private var triedTs = false
    private var mode = 0
    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val modeNames = arrayOf("تلقائي", "ملائم", "تمديد", "تكبير")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setBackgroundDrawable(ColorDrawable(0xFF000000.toInt()))
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        mode = prefs.getInt("aspect", 0).coerceIn(0, 3)
        if (PlayQueue.urls.isEmpty()) { finish(); return }
        index = intent.getIntExtra("index", 0).coerceIn(0, PlayQueue.urls.size - 1)
        live = intent.getBooleanExtra("live", true)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        pv = PlayerView(this).apply {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShutterBackgroundColor(0xFF000000.toInt())
            setBackgroundColor(0xFF000000.toInt())
            setShowSubtitleButton(true)
            setShowNextButton(false)
            setShowPreviousButton(false)
            controllerShowTimeoutMs = 4000
        }
        val spinner = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
        }
        title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            setShadowLayer(6f, 0f, 0f, 0xFF000000.toInt())
            setPadding(32, 24, 32, 0)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
        }
        val ratio = Button(this).apply {
            text = "نسبة العرض"
            setOnClickListener {
                mode = (mode + 1) % modes.size
                prefs.edit().putInt("aspect", mode).apply()
                applyMode()
                Toast.makeText(this@PlayerActivity, modeNames[mode], Toast.LENGTH_SHORT).show()
            }
        }
        val ext = Button(this).apply {
            text = "مشغّل خارجي"
            setOnClickListener { openExternal() }
        }
        bar.addView(ratio); bar.addView(ext)
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            bar.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
        })

        root.addView(pv, FrameLayout.LayoutParams(-1, -1))
        root.addView(spinner)
        root.addView(title, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        setContentView(root)

        aj = AjPlayer(this, live, prefs.getInt("buf", 1), prefs.getBoolean("tunnel", false))
        pv.player = aj.player
        aj.player.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                if (mode == 0) autoFit(videoSize)
            }
        })
        applyMode()
        aj.onState = { s ->
            spinner.visibility = if (s == AjPlayer.State.LOADING) View.VISIBLE else View.GONE
            when (s) {
                AjPlayer.State.ERROR -> {
                    val u = PlayQueue.urls[index]
                    if (!triedTs && u.endsWith(".m3u8")) {
                        triedTs = true
                        aj.play(u.removeSuffix(".m3u8") + ".ts")
                    } else {
                        val code = aj.lastError?.errorCode
                        val unsupported = code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
                            code == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED
                        title.text = if (unsupported) "جهازك لا يدعم هذه الجودة. جرّب «مشغّل خارجي»"
                        else "تعذّر التشغيل: " + PlayQueue.names[index]
                    }
                }
                AjPlayer.State.ENDED -> {
                    if (!live) {
                        prefs.edit().remove(posKey()).apply()
                        if (index < PlayQueue.urls.size - 1) { index++; start() }
                    }
                }
                else -> {}
            }
        }
        start()
    }

    private fun applyMode() {
        if (mode == 0) autoFit(aj.player.videoSize) else pv.resizeMode = modes[mode]
    }

    /** Auto: fill the screen when the video is close to it, keep cinema bars for very wide films. */
    private fun autoFit(v: VideoSize) {
        if (v.width == 0 || v.height == 0) {
            pv.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            return
        }
        val vr = v.width * v.pixelWidthHeightRatio / v.height
        val dm = resources.displayMetrics
        val sr = dm.widthPixels.toFloat() / dm.heightPixels
        val d = Math.abs(vr / sr - 1f)
        pv.resizeMode =
            if (d < 0.22f) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private fun posKey() = "pos_" + PlayQueue.urls[index].hashCode()

    private fun start() {
        triedTs = false
        title.text = PlayQueue.names[index]
        val saved = if (live) 0L else prefs.getLong(posKey(), 0L)
        aj.play(PlayQueue.urls[index], if (saved > 10_000L) saved else 0L)
    }

    private fun savePos() {
        if (live || !::aj.isInitialized) return
        val d = aj.player.duration
        val p = aj.player.currentPosition
        val e = prefs.edit()
        if (d != C.TIME_UNSET && p > d - 30_000L) e.remove(posKey()) else e.putLong(posKey(), p)
        e.apply()
    }

    private fun zap(d: Int) {
        val n = PlayQueue.urls.size
        index = (index + d + n) % n
        start()
    }

    private fun openExternal() {
        aj.pause()
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(PlayQueue.urls[index]), "video/*")
        try {
            startActivity(Intent.createChooser(i, "افتح بواسطة"))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "ما في مشغّل خارجي مثبّت", Toast.LENGTH_LONG).show()
        }
    }

    /** Live: up/down (or channel keys) change channel while controls are hidden. */
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (live && e.action == KeyEvent.ACTION_DOWN && ::pv.isInitialized && !pv.isControllerFullyVisible) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onStart() { super.onStart(); if (::aj.isInitialized) aj.resume() }
    override fun onStop() { super.onStop(); savePos(); if (::aj.isInitialized) aj.pause() }
    override fun onDestroy() { super.onDestroy(); if (::aj.isInitialized) aj.release() }
}

package com.aj.iptv.player

import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.view.Gravity
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.BehindLiveWindowException
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

/** Builds Xtream Codes stream URLs. Prefer m3u8 (HLS); fall back to ts. */
object Xtream {
    const val HOST = "Maveniptv.tv"
    const val PORT = 2095

    fun live(user: String, pass: String, streamId: String, ext: String = "m3u8") =
        "http://$HOST:$PORT/live/$user/$pass/$streamId.$ext"
}

/**
 * One ExoPlayer instance reused for every channel (fast zapping),
 * small start buffer, short network timeouts, automatic retry.
 */
@OptIn(UnstableApi::class)
class AjPlayer(context: Context) {

    enum class State { LOADING, PLAYING, ERROR }

    var onState: ((State) -> Unit)? = null

    private var currentUrl: String? = null
    private var retries = 0

    private val http = DefaultHttpDataSource.Factory()
        .setUserAgent("AJIPTV/1.0")
        .setConnectTimeoutMs(8_000)
        .setReadTimeoutMs(8_000)
        .setAllowCrossProtocolRedirects(true)

    // Start playing after 1s of data; keep 15-30s ahead for stability.
    private val loadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(15_000, 30_000, 1_000, 2_500)
        .setPrioritizeTimeOverSizeThresholds(true)
        .build()

    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext)
        .setMediaSourceFactory(DefaultMediaSourceFactory(http))
        .setLoadControl(loadControl)
        .setRenderersFactory(
            DefaultRenderersFactory(context.applicationContext)
                .setEnableDecoderFallback(true)
        )
        .build()
        .also { it.playWhenReady = true }

    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> onState?.invoke(State.LOADING)
                    Player.STATE_READY -> {
                        retries = 0
                        onState?.invoke(State.PLAYING)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (error.cause is BehindLiveWindowException) {
                    player.seekToDefaultPosition()
                    player.prepare()
                    return
                }
                if (retries < 3) {
                    retries++
                    player.prepare()          // retry same channel
                } else {
                    onState?.invoke(State.ERROR)
                }
            }
        })
    }

    /** Switch channel without recreating the player. */
    fun play(url: String) {
        if (url == currentUrl && player.playbackState != Player.STATE_IDLE) return
        currentUrl = url
        retries = 0
        onState?.invoke(State.LOADING)
        player.setMediaItem(MediaItem.fromUri(url))
        player.prepare()
    }

    fun pause() = player.pause()
    fun resume() = player.play()
    fun release() = player.release()
}

/** Full-screen player. Start with extras: "url" and "name". */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var aj: AjPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        val view = PlayerView(this).apply {
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShutterBackgroundColor(0xFF000000.toInt())
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        val spinner = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
        }
        val title = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            setPadding(32, 32, 32, 0)
            text = intent.getStringExtra("name").orEmpty()
        }
        root.addView(view); root.addView(spinner); root.addView(title)
        setContentView(root)

        aj = AjPlayer(this)
        view.player = aj.player
        val url = intent.getStringExtra("url").orEmpty()
        var triedTs = false
        aj.onState = { s ->
            spinner.visibility =
                if (s == AjPlayer.State.LOADING) android.view.View.VISIBLE else android.view.View.GONE
            if (s == AjPlayer.State.ERROR) {
                if (!triedTs && url.endsWith(".m3u8")) {
                    triedTs = true
                    aj.play(url.removeSuffix(".m3u8") + ".ts")
                } else title.text = "تعذّر تشغيل القناة"
            }
        }
        if (url.isNotEmpty()) aj.play(url)
    }

    override fun onStop() { super.onStop(); aj.pause() }
    override fun onStart() { super.onStart(); if (::aj.isInitialized) aj.resume() }
    override fun onDestroy() { super.onDestroy(); aj.release() }
}

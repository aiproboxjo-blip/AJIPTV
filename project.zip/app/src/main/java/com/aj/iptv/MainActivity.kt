package com.aj.iptv

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Base64
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.aj.iptv.player.AjPlayer
import com.aj.iptv.player.PlayQueue
import com.aj.iptv.player.PlayerActivity
import com.aj.iptv.player.Xtream
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

enum class Kind(val label: String, val catAction: String, val listAction: String) {
    LIVE("بث مباشر", "get_live_categories", "get_live_streams"),
    MOVIE("أفلام", "get_vod_categories", "get_vod_streams"),
    SERIES("مسلسلات", "get_series_categories", "get_series")
}

data class Item(
    val id: String, val name: String, val ext: String = "",
    val img: String = "", val rating: String = ""
)

data class Fav(val kind: Kind, val item: Item)

private fun JSONObject.str(k: String): String {
    val s = optString(k, "")
    return if (s == "null") "" else s.trim()
}

private fun JSONObject.firstOf(vararg ks: String): String =
    ks.map { str(it) }.firstOrNull { it.isNotEmpty() } ?: ""

/** Small image loader: background download, downsample, memory cache. */
object Img {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(4)
    private val ui = Handler(Looper.getMainLooper())

    fun load(url: String, iv: ImageView, w: Int) {
        iv.tag = url
        iv.setImageDrawable(null)
        if (url.isBlank()) return
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        pool.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8_000
                c.readTimeout = 8_000
                val bytes = c.inputStream.use { it.readBytes() }
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= w) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: return@execute
                cache.put(url, bmp)
                ui.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
            } catch (_: Exception) { }
        }
    }
}

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private val bg = Color.parseColor("#0B1A2E")
    private val accent = Color.parseColor("#4C8DFF")
    private val palette = intArrayOf(
        Color.parseColor("#2E7BFF"), Color.parseColor("#7A4DFF"), Color.parseColor("#E0457B"),
        Color.parseColor("#19A974"), Color.parseColor("#E69F00"), Color.parseColor("#00A6C8")
    )
    private var user = ""
    private var pass = ""
    private var screen = 0
    private var onBack: (() -> Unit)? = null
    private val lastCat = HashMap<Kind, String>()
    private var onVoice: ((String) -> Unit)? = null

    // inline live preview (TV / large screens)
    private var preview: AjPlayer? = null
    private var selId = ""
    private var selItem: Item? = null

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrEmpty()) onVoice?.invoke(t)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val b = onBack
                if (b != null) b() else finish()
            }
        })
        user = prefs.getString("u", "").orEmpty()
        pass = prefs.getString("p", "").orEmpty()
        showSplash()
    }

    override fun onStop() {
        super.onStop()
        preview?.stop()
        selId = ""
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePreview()
    }

    private fun releasePreview() {
        preview?.release(); preview = null
        selId = ""; selItem = null
    }

    private fun setScreen(v: View) {
        releasePreview()
        setContentView(v)
    }

    // ---------- network + cache ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(extra: String = ""): String {
        val u = "http://${Xtream.HOST}:${Xtream.PORT}/player_api.php?username=${enc(user)}&password=${enc(pass)}$extra"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Shows cached data instantly, then refreshes from the server. */
    private fun load(key: String, extra: String, tok: Int, show: (String) -> Unit) {
        val f = File(cacheDir, "$key.json")
        if (f.exists()) try { show(f.readText()) } catch (_: Exception) { }
        io.execute {
            try {
                val t = api(extra)
                JSONTokener(t).nextValue()
                f.writeText(t)
                ui.post {
                    if (tok == screen && !isFinishing) try { show(t) } catch (_: Exception) { }
                }
            } catch (e: Exception) {
                ui.post {
                    if (tok == screen && !f.exists()) toast("تعذّر التحميل، تحقق من الاتصال")
                }
            }
        }
    }

    private fun parseItems(kind: Kind, t: String): List<Item> {
        val idKey = if (kind == Kind.SERIES) "series_id" else "stream_id"
        val imgKey = if (kind == Kind.SERIES) "cover" else "stream_icon"
        val arr = JSONArray(t)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Item(o.get(idKey).toString(), o.getString("name"), o.str("container_extension"), o.str(imgKey), o.str("rating"))
        }
    }

    /** Items of the first category (cached, shared with the browse screens). */
    private fun loadFirst(kind: Kind, tok: Int, cb: (List<Item>) -> Unit) {
        load("cats_${kind.name}_${user.hashCode()}", "&action=${kind.catAction}", tok) { t ->
            val arr = JSONArray(t)
            if (arr.length() > 0) {
                val c = arr.getJSONObject(0).get("category_id").toString()
                load("it_${kind.name}_${user.hashCode()}_$c", "&action=${kind.listAction}&category_id=$c", tok) { t2 ->
                    cb(parseItems(kind, t2))
                }
            }
        }
    }

    private fun loadEpg(streamId: String, tv: TextView) {
        io.execute {
            val txt = try {
                val a = JSONObject(api("&action=get_short_epg&stream_id=$streamId&limit=3")).optJSONArray("epg_listings")
                val sb = StringBuilder()
                if (a != null) {
                    for (i in 0 until a.length()) {
                        val e = a.getJSONObject(i)
                        val title = String(Base64.decode(e.optString("title"), Base64.DEFAULT), Charsets.UTF_8)
                        val st = e.optString("start_timestamp").toLongOrNull()
                        val time = if (st != null) SimpleDateFormat("HH:mm", Locale.US).format(Date(st * 1000)) else ""
                        val tag = if (i == 0) "الآن" else if (i == 1) "التالي" else "لاحقاً"
                        sb.append(tag).append("   ").append(time).append("   ").append(title).append("\n\n")
                    }
                }
                if (sb.isEmpty()) "لا يوجد دليل برامج لهذه القناة" else sb.toString()
            } catch (e: Exception) {
                "لا يوجد دليل برامج لهذه القناة"
            }
            ui.post { if (selId == streamId) tv.text = txt }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun startVoice(cb: (String) -> Unit) {
        onVoice = cb
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "تكلّم الآن")
            )
        } catch (e: Exception) {
            toast("البحث الصوتي غير متاح على هذا الجهاز")
        }
    }

    // ---------- favorites + recent ----------
    private fun readList(key: String): MutableList<Fav> {
        val out = ArrayList<Fav>()
        try {
            val a = JSONArray(prefs.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Fav(
                        Kind.valueOf(o.getString("k")),
                        Item(o.getString("id"), o.getString("n"), o.optString("e"), o.optString("i"))
                    )
                )
            }
        } catch (_: Exception) { }
        return out
    }

    private fun writeList(key: String, l: List<Fav>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("k", it.kind.name).put("id", it.item.id).put("n", it.item.name)
                    .put("e", it.item.ext).put("i", it.item.img)
            )
        }
        prefs.edit().putString(key, a.toString()).apply()
    }

    private fun favs() = readList("fav")

    private fun toggleFav(k: Kind, item: Item) {
        val l = favs()
        val ex = l.find { it.kind == k && it.item.id == item.id }
        if (ex != null) l.remove(ex) else l.add(Fav(k, item))
        writeList("fav", l)
    }

    private fun addRecent(k: Kind, item: Item) {
        val l = readList("recent")
        l.removeAll { it.kind == k && it.item.id == item.id }
        l.add(0, Fav(k, item))
        writeList("recent", l.take(12))
    }

    // ---------- UI helpers ----------
    private fun adapter(items: List<String>) =
        object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(Color.WHITE)
                t.textSize = 17f
                t.setPadding(40, 26, 40, 26)
                return t
            }
        }

    private fun newList() = ListView(this).apply {
        divider = null
        isFocusable = true
        selector = ColorDrawable(Color.parseColor("#664C8DFF"))
    }

    private fun roundBg(normal: Int, focused: Int): StateListDrawable {
        fun rect(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = 28f }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), rect(focused))
            addState(intArrayOf(android.R.attr.state_pressed), rect(focused))
            addState(intArrayOf(), rect(normal))
        }
    }

    private fun tile(label: String) = Button(this).apply {
        text = label; textSize = 20f; isAllCaps = false
        setTextColor(Color.WHITE); background = roundBg(Color.parseColor("#17304F"), accent)
    }

    private fun cellBg(): StateListDrawable {
        val on = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(5, accent); cornerRadius = 20f }
        val off = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), on)
            addState(intArrayOf(), off)
        }
    }

    /** Left icon rail on every main screen. */
    private fun withRail(sel: Int, content: View): View {
        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#070F1A")); setPadding(0, 16, 0, 16)
        }
        rail.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(64, 64).apply { bottomMargin = 8 })
        val icons = listOf("🏠", "📺", "🎬", "🎞️", "⭐", "👤", "⚙️")
        val acts: List<() -> Unit> = listOf(
            { showHome() }, { showBrowse(Kind.LIVE) }, { showBrowse(Kind.MOVIE) }, { showBrowse(Kind.SERIES) },
            { showFavorites() }, { showAccount() }, { showSettings() }
        )
        icons.forEachIndexed { i, ic ->
            val b = Button(this).apply {
                text = ic; textSize = 22f; isAllCaps = false; setTextColor(Color.WHITE); setPadding(0, 0, 0, 0)
                background = roundBg(if (i == sel) Color.parseColor("#17304F") else Color.TRANSPARENT, accent)
            }
            b.setOnClickListener { acts[i]() }
            rail.addView(b, LinearLayout.LayoutParams(80, 0, 1f).apply { setMargins(6, 4, 6, 4) })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(bg) }
        root.addView(rail, LinearLayout.LayoutParams(96, -1))
        root.addView(content, LinearLayout.LayoutParams(0, -1, 1f))
        return root
    }

    private fun page(title: String, content: View, extra: View? = null, sel: Int = -1) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        col.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 22f; setPadding(48, 24, 48, 12)
        })
        extra?.let { col.addView(it) }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setScreen(withRail(sel, col))
    }

    /** Poster tile: coloured initial behind, image on top. Empty/failed image = auto-filled tile. */
    private fun makePoster(crop: Boolean): FrameLayout {
        val f = FrameLayout(this)
        f.addView(TextView(this).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 28f
        })
        f.addView(ImageView(this).apply {
            scaleType = if (crop) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        })
        return f
    }

    private fun bindPoster(f: FrameLayout, item: Item, w: Int) {
        val c = palette[(item.name.hashCode() and 0x7fffffff) % palette.size]
        f.background = GradientDrawable().apply { setColor(c); cornerRadius = 16f }
        (f.getChildAt(0) as TextView).text = item.name.trim().take(1)
        Img.load(item.img, f.getChildAt(1) as ImageView, w)
    }

    private fun posterAdapter(items: List<Item>, favIds: Set<String>, w: Int): BaseAdapter {
        val h = w * 3 / 2
        return object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val cell = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(makePoster(true), LinearLayout.LayoutParams(-1, h))
                    addView(TextView(this@MainActivity).apply {
                        setTextColor(Color.WHITE); textSize = 13f; maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END; setPadding(4, 6, 4, 0)
                    })
                }
                val item = items[p]
                bindPoster(cell.getChildAt(0) as FrameLayout, item, w)
                (cell.getChildAt(1) as TextView).text = (if (item.id in favIds) "★ " else "") + item.name
                return cell
            }
        }
    }

    private fun rowAdapter(items: List<Item>, favIds: Set<String>, sel: String = ""): BaseAdapter =
        object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val row = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(32, 12, 32, 12)
                    addView(makePoster(false), LinearLayout.LayoutParams(120, 90))
                    addView(TextView(this@MainActivity).apply {
                        setTextColor(Color.WHITE); textSize = 17f; maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END; setPadding(24, 0, 0, 0)
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                val item = items[p]
                bindPoster(row.getChildAt(0) as FrameLayout, item, 120)
                val mark = if (item.id == sel) "▶ " else if (item.id in favIds) "★ " else ""
                (row.getChildAt(1) as TextView).text = mark + item.name
                return row
            }
        }

    private fun play(urls: List<String>, names: List<String>, index: Int, live: Boolean) {
        PlayQueue.urls = urls
        PlayQueue.names = names
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", index).putExtra("live", live))
    }

    /** Live plays directly (with channel zapping); movies and series open the details page. */
    private fun openItem(kind: Kind, s: List<Item>, i: Int, back: () -> Unit) {
        if (kind == Kind.LIVE) {
            play(s.map { Xtream.live(user, pass, it.id) }, s.map { it.name }, i, true)
        } else {
            showDetails(kind, s[i], back)
        }
    }

    // ---------- screens ----------
    private fun showSplash() {
        val f = FrameLayout(this).apply { setBackgroundColor(bg) }
        f.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, FrameLayout.LayoutParams(360, 360, Gravity.CENTER))
        setScreen(f)
        ui.postDelayed({
            if (!isFinishing) { if (user.isNotEmpty()) showHome() else showLogin() }
        }, 900)
    }

    private fun showLogin() {
        screen++; onBack = null
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 32, 64, 32); setBackgroundColor(bg)
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(260, 260))
        fun field(h: String, secret: Boolean) = EditText(this).apply {
            hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val u = field("اسم المستخدم", false)
        val p = field("كلمة المرور", true)
        val err = TextView(this).apply { setTextColor(Color.parseColor("#FF6B6B")); gravity = Gravity.CENTER }
        val btn = tile("دخول")
        btn.setOnClickListener {
            user = u.text.toString().trim(); pass = p.text.toString().trim()
            if (user.isEmpty() || pass.isEmpty()) { err.text = "أدخل اسم المستخدم وكلمة المرور"; return@setOnClickListener }
            btn.isEnabled = false; err.text = "جارٍ التحقق..."
            io.execute {
                val ok = try { JSONObject(api()).getJSONObject("user_info").optInt("auth") == 1 } catch (e: Exception) { false }
                ui.post {
                    if (ok) {
                        prefs.edit().putString("u", user).putString("p", pass).apply()
                        showHome()
                    } else {
                        btn.isEnabled = true; err.text = "فشل الدخول: تحقق من البيانات أو الاتصال"
                    }
                }
            }
        }
        col.addView(u, LinearLayout.LayoutParams(-1, -2))
        col.addView(p, LinearLayout.LayoutParams(-1, -2))
        col.addView(err, LinearLayout.LayoutParams(-1, -2))
        col.addView(btn, LinearLayout.LayoutParams(-1, 140).apply { topMargin = 16 })
        setScreen(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(col) })
        u.requestFocus()
    }

    private fun fillRow(holder: LinearLayout, title: String, list: List<Fav>, w: Int) {
        holder.removeAllViews()
        if (list.isEmpty()) return
        holder.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 20f; setPadding(8, 24, 0, 8)
        })
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        list.take(30).forEach { f ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; isFocusable = true; isClickable = true
                background = cellBg(); setPadding(8, 8, 8, 8)
            }
            val p = makePoster(true)
            bindPoster(p, f.item, w)
            cell.addView(p, LinearLayout.LayoutParams(w, w * 3 / 2))
            cell.addView(TextView(this).apply {
                text = f.item.name; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; setPadding(2, 6, 2, 0)
            }, LinearLayout.LayoutParams(w, -2))
            cell.setOnClickListener { showDetails(f.kind, f.item) { showHome() } }
            strip.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 12, 0) })
        }
        holder.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) })
    }

    /** Hero banner + rows (continue watching, movies, series). */
    private fun showHome() {
        val tok = ++screen; onBack = null
        val dm = resources.displayMetrics
        val posterW = (dm.widthPixels * 0.16).toInt().coerceAtLeast(160)
        val rowW = (dm.widthPixels * 0.095).toInt().coerceAtLeast(120)
        var hero: Item? = null

        val kicker = TextView(this).apply { text = "اقتراح AJIPTV"; setTextColor(accent); textSize = 13f }
        val titleTv = TextView(this).apply { text = "AJIPTV"; setTextColor(Color.WHITE); textSize = 34f; setPadding(0, 8, 0, 8) }
        val metaTv = TextView(this).apply { setTextColor(Color.parseColor("#9FB4CC")); textSize = 15f }
        val plotTv = TextView(this).apply {
            setTextColor(Color.parseColor("#CBD6E2")); textSize = 15f; maxLines = 3
            ellipsize = TextUtils.TruncateAt.END; setPadding(0, 12, 0, 0)
        }
        val playB = tile("▶  تشغيل")
        val listB = tile("＋  قائمتي")
        val infoB = tile("ⓘ  تفاصيل")
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(playB, listB, infoB).forEach { btns.addView(it, LinearLayout.LayoutParams(250, 110).apply { setMargins(0, 20, 16, 0) }) }
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        text.addView(kicker); text.addView(titleTv); text.addView(metaTv); text.addView(plotTv); text.addView(btns)
        val poster = makePoster(true)
        val heroRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heroRow.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        heroRow.addView(poster, LinearLayout.LayoutParams(posterW, posterW * 3 / 2))

        playB.setOnClickListener {
            hero?.let { h ->
                addRecent(Kind.MOVIE, h)
                play(listOf(Xtream.movie(user, pass, h.id, h.ext.ifEmpty { "mp4" })), listOf(h.name), 0, false)
            }
        }
        listB.setOnClickListener { hero?.let { h -> toggleFav(Kind.MOVIE, h); toast("تم تحديث قائمتك") } }
        infoB.setOnClickListener { hero?.let { h -> showDetails(Kind.MOVIE, h) { showHome() } } }

        fun setHero(h: Item) {
            if (hero?.id == h.id) return
            hero = h
            titleTv.text = h.name
            metaTv.text = if (h.rating.isNotEmpty()) "⭐ ${h.rating}" else ""
            plotTv.text = ""
            bindPoster(poster, h, posterW)
            load("vi_${user.hashCode()}_${h.id}", "&action=get_vod_info&vod_id=${h.id}", tok) { t ->
                if (hero?.id == h.id) {
                    val o = JSONObject(t).optJSONObject("info")
                    if (o != null) {
                        val meta = listOf(
                            if (h.rating.isNotEmpty()) "⭐ ${h.rating}" else "",
                            o.firstOf("releasedate", "releaseDate", "release_date", "year").take(4),
                            o.str("genre"), o.str("duration")
                        ).filter { it.isNotEmpty() }
                        metaTv.text = meta.joinToString("  •  ")
                        plotTv.text = o.firstOf("plot", "description")
                    }
                }
            }
        }

        val recentHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val moviesHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val seriesHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fillRow(recentHolder, "متابعة المشاهدة", readList("recent"), rowW)

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 32, 40, 32) }
        col.addView(heroRow); col.addView(recentHolder); col.addView(moviesHolder); col.addView(seriesHolder)
        setScreen(withRail(0, ScrollView(this).apply { setBackgroundColor(bg); addView(col) }))
        playB.requestFocus()

        loadFirst(Kind.MOVIE, tok) { items ->
            items.firstOrNull { it.img.isNotEmpty() }?.let { setHero(it) }
            fillRow(moviesHolder, "أفلام", items.map { Fav(Kind.MOVIE, it) }, rowW)
        }
        loadFirst(Kind.SERIES, tok) { items ->
            fillRow(seriesHolder, "مسلسلات", items.map { Fav(Kind.SERIES, it) }, rowW)
        }
    }

    /** Categories | content | (live only, wide screens) preview with program guide. */
    private fun showBrowse(kind: Kind) {
        val tok = ++screen; onBack = { showHome() }
        val live = kind == Kind.LIVE
        val dm = resources.displayMetrics
        val wide = live && dm.widthPixels / dm.density >= 900
        val availW = dm.widthPixels - 96
        val paneW = (availW * 0.68).toInt()
        val cols = (paneW / (140 * dm.density)).toInt().coerceIn(2, 8)
        val gap = 16
        val cellW = (paneW - gap * (cols + 1)) / cols

        var ids: List<String> = emptyList()
        var names: List<String> = emptyList()
        val labels = ArrayList<String>()
        var cur = ""
        var all: List<Item> = emptyList()
        var shown: List<Item> = emptyList()

        val catList = newList()
        catList.adapter = adapter(labels)
        val q = EditText(this).apply {
            hint = "بحث"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
        }
        val mic = tile("🎤")
        val grid = GridView(this).apply {
            numColumns = cols; horizontalSpacing = gap; verticalSpacing = gap
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(gap, gap, gap, gap); clipToPadding = false
            selector = ColorDrawable(Color.parseColor("#664C8DFF")); isFocusable = true
        }
        val rows = newList()
        val content: View = if (live) rows else grid

        // preview pane widgets (wide live only)
        val pvView = PlayerView(this).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT }
        val pvTitle = TextView(this).apply { setTextColor(Color.WHITE); textSize = 20f; setPadding(0, 16, 0, 8); text = "اختر قناة للمعاينة" }
        val pvEpg = TextView(this).apply { setTextColor(Color.parseColor("#CBD6E2")); textSize = 15f; setLineSpacing(0f, 1.1f) }
        val pvFav = tile("☆  المفضلة")
        fun updPvFav() {
            val s = selItem
            pvFav.text = if (s != null && favs().any { it.kind == kind && it.item.id == s.id }) "★  بالمفضلة" else "☆  المفضلة"
        }

        fun render() {
            val t = q.text.toString().trim().lowercase()
            val favIds = favs().filter { it.kind == kind }.map { it.item.id }.toSet()
            shown = all.filter { t.isEmpty() || it.name.lowercase().contains(t) }
            if (live) {
                val pos = rows.firstVisiblePosition
                rows.adapter = rowAdapter(shown, favIds, selId)
                rows.setSelection(pos)
            } else {
                val pos = grid.firstVisiblePosition
                grid.adapter = posterAdapter(shown, favIds, cellW)
                grid.setSelection(pos)
            }
        }

        fun selectCat(i: Int) {
            cur = ids[i]; lastCat[kind] = cur
            for (j in names.indices) labels[j] = (if (j == i) "▶ " else "") + names[j]
            (catList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
            all = emptyList(); render()
            val c = cur
            load("it_${kind.name}_${user.hashCode()}_$c", "&action=${kind.listAction}&category_id=$c", tok) { t ->
                if (cur == c) { all = parseItems(kind, t); render() }
            }
        }

        val clickBack = { showBrowse(kind) }
        val itemClick = AdapterView.OnItemClickListener { _, _, i, _ ->
            val ch = shown[i]
            if (wide) {
                if (ch.id == selId) {
                    preview?.stop()
                    openItem(kind, shown, i, clickBack)
                } else {
                    selId = ch.id; selItem = ch
                    preview?.play(Xtream.live(user, pass, ch.id))
                    pvTitle.text = ch.name; pvEpg.text = "جارٍ تحميل دليل البرامج..."
                    loadEpg(ch.id, pvEpg)
                    updPvFav(); render()
                }
            } else {
                openItem(kind, shown, i, clickBack)
            }
        }
        val itemLong = AdapterView.OnItemLongClickListener { _, _, i, _ ->
            toggleFav(kind, shown[i]); render(); updPvFav(); true
        }
        if (live) { rows.onItemClickListener = itemClick; rows.onItemLongClickListener = itemLong }
        else { grid.onItemClickListener = itemClick; grid.onItemLongClickListener = itemLong }
        pvFav.setOnClickListener { selItem?.let { toggleFav(kind, it); updPvFav(); render() } }
        catList.setOnItemClickListener { _, _, i, _ -> selectCat(i) }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = render()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        mic.setOnClickListener { startVoice { q.setText(it) } }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextView(this).apply {
            text = kind.label; setTextColor(Color.WHITE); textSize = 22f; setPadding(40, 24, 24, 12)
        })
        left.addView(catList, LinearLayout.LayoutParams(-1, 0, 1f))
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 12, 16, 0) }
        searchRow.addView(q, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(mic, LinearLayout.LayoutParams(130, 110))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(searchRow)
        right.addView(TextView(this).apply {
            text = if (wide) "اضغط على القناة للمعاينة، وضغطة ثانية للشاشة الكاملة. مطولاً للمفضلة"
            else "اضغط مطولاً على أي عنصر لإضافته للمفضلة"
            setTextColor(Color.GRAY); textSize = 12f; setPadding(32, 4, 16, 0)
        })
        right.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(bg) }
        if (wide) {
            val pvW = (availW * 0.45).toInt() - 48
            val pane = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
            pane.addView(FrameLayout(this).apply { setBackgroundColor(Color.BLACK); addView(pvView) }, LinearLayout.LayoutParams(-1, pvW * 9 / 16))
            pane.addView(pvTitle)
            pane.addView(ScrollView(this).apply { addView(pvEpg) }, LinearLayout.LayoutParams(-1, 0, 1f))
            pane.addView(pvFav, LinearLayout.LayoutParams(-1, 110).apply { topMargin = 8 })
            root.addView(left, LinearLayout.LayoutParams(0, -1, 22f))
            root.addView(right, LinearLayout.LayoutParams(0, -1, 33f))
            root.addView(pane, LinearLayout.LayoutParams(0, -1, 45f))
        } else {
            root.addView(left, LinearLayout.LayoutParams(0, -1, 32f))
            root.addView(right, LinearLayout.LayoutParams(0, -1, 68f))
        }
        setScreen(withRail(if (live) 1 else if (kind == Kind.MOVIE) 2 else 3, root))
        if (wide) {
            val p = AjPlayer(this, true, prefs.getInt("buf", 1))
            preview = p
            pvView.player = p.player
        }
        catList.requestFocus()

        load("cats_${kind.name}_${user.hashCode()}", "&action=${kind.catAction}", tok) { t ->
            val arr = JSONArray(t)
            val nid = ArrayList<String>(); val nn = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                nid.add(o.get("category_id").toString()); nn.add(o.getString("category_name"))
            }
            if (nid != ids && nid.isNotEmpty()) {
                ids = nid; names = nn
                labels.clear(); labels.addAll(nn)
                (catList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
                val start = ids.indexOf(lastCat[kind] ?: "").let { if (it >= 0) it else 0 }
                selectCat(start)
                catList.setSelection(start)
            }
        }
    }

    private fun showDetails(kind: Kind, item: Item, back: () -> Unit) {
        val tok = ++screen; onBack = back
        val dm = resources.displayMetrics
        val posterW = (dm.widthPixels * 0.22).toInt().coerceAtLeast(180)
        val posterH = posterW * 3 / 2
        val poster = makePoster(true)
        bindPoster(poster, item, posterW)

        val titleTv = TextView(this).apply { text = item.name; setTextColor(Color.WHITE); textSize = 22f; setPadding(0, 8, 0, 8) }
        val metaTv = TextView(this).apply { setTextColor(Color.parseColor("#9FB4CC")); textSize = 15f }
        val plotTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setPadding(0, 16, 0, 16); setLineSpacing(0f, 1.2f) }
        val playBtn = tile("▶  تشغيل")
        val favBtn = tile("")
        fun updFav() {
            favBtn.text = if (favs().any { it.kind == kind && it.item.id == item.id }) "★  بالمفضلة" else "☆  أضف للمفضلة"
        }
        updFav()
        favBtn.setOnClickListener { toggleFav(kind, item); updFav() }

        val epList = newList()
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 24, 24, 24) }
        left.addView(poster, LinearLayout.LayoutParams(posterW, posterH))
        left.addView(playBtn, LinearLayout.LayoutParams(posterW, 120).apply { topMargin = 24 })
        left.addView(favBtn, LinearLayout.LayoutParams(posterW, 120).apply { topMargin = 12 })
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 40, 24) }
        right.addView(titleTv); right.addView(metaTv)
        if (kind == Kind.SERIES) {
            plotTv.maxLines = 4; plotTv.ellipsize = TextUtils.TruncateAt.END
            right.addView(plotTv); right.addView(epList, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            right.addView(ScrollView(this).apply { addView(plotTv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(bg) }
        root.addView(ScrollView(this).apply { addView(left) }, LinearLayout.LayoutParams(-2, -1))
        root.addView(right, LinearLayout.LayoutParams(0, -1, 1f))
        setScreen(root)
        playBtn.requestFocus()

        fun showInfo(o: JSONObject?) {
            if (o == null) return
            val rt = o.str("rating")
            val meta = listOf(
                if (rt.isNotEmpty()) "⭐ $rt" else "",
                o.firstOf("releasedate", "releaseDate", "release_date", "year").take(10),
                o.str("genre"), o.str("duration")
            ).filter { it.isNotEmpty() }
            metaTv.text = meta.joinToString("  •  ")
            val cast = o.str("cast"); val dir = o.str("director")
            plotTv.text = listOf(
                o.firstOf("plot", "description"),
                if (cast.isNotEmpty()) "الممثلون: $cast" else "",
                if (dir.isNotEmpty()) "المخرج: $dir" else ""
            ).filter { it.isNotEmpty() }.joinToString("\n\n")
            val img = o.firstOf("movie_image", "cover")
            if (img.isNotEmpty() && item.img.isEmpty()) Img.load(img, poster.getChildAt(1) as ImageView, posterW)
            val t = o.str("name")
            if (t.isNotEmpty()) titleTv.text = t
        }

        if (kind == Kind.MOVIE) {
            var movieExt = item.ext
            playBtn.setOnClickListener {
                addRecent(Kind.MOVIE, item)
                play(listOf(Xtream.movie(user, pass, item.id, movieExt.ifEmpty { "mp4" })), listOf(item.name), 0, false)
            }
            load("vi_${user.hashCode()}_${item.id}", "&action=get_vod_info&vod_id=${item.id}", tok) { t ->
                val r = JSONObject(t)
                showInfo(r.optJSONObject("info"))
                val e = r.optJSONObject("movie_data")?.str("container_extension").orEmpty()
                if (e.isNotEmpty()) movieExt = e
            }
        } else {
            var eps: List<Item> = emptyList()
            fun playEpisodes(list: List<Item>, i: Int) {
                addRecent(Kind.SERIES, item)
                play(
                    list.map { Xtream.episode(user, pass, it.id, it.ext.ifEmpty { "mp4" }) },
                    list.map { item.name + " - " + it.name }, i, false
                )
            }
            playBtn.setOnClickListener { if (eps.isEmpty()) toast("لا توجد حلقات بعد") else playEpisodes(eps, 0) }
            load("ep_${user.hashCode()}_${item.id}", "&action=get_series_info&series_id=${item.id}", tok) { t ->
                val r = JSONObject(t)
                showInfo(r.optJSONObject("info"))
                val raw = r.opt("episodes")
                val seasons = LinkedHashMap<String, JSONArray>()
                if (raw is JSONObject) {
                    raw.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { seasons[it] = raw.getJSONArray(it) }
                } else if (raw is JSONArray) {
                    for (i in 0 until raw.length()) seasons["${i + 1}"] = raw.optJSONArray(i) ?: JSONArray()
                }
                val list = ArrayList<Item>()
                for ((s, arr) in seasons) {
                    for (j in 0 until arr.length()) {
                        val o = arr.getJSONObject(j)
                        val num = o.optString("episode_num", "${j + 1}")
                        val ttl = o.str("title")
                        val label = "الموسم $s - الحلقة $num" + if (ttl.isNotEmpty()) " | $ttl" else ""
                        list.add(Item(o.get("id").toString(), label, o.str("container_extension")))
                    }
                }
                eps = list
                epList.adapter = adapter(list.map { it.name })
                epList.setOnItemClickListener { _, _, i, _ -> playEpisodes(list, i) }
            }
        }
    }

    private fun showFavorites() {
        screen++; onBack = { showHome() }
        val list = newList()
        page("المفضلة  (اضغط مطولاً للحذف)", list, sel = 4)
        list.requestFocus()
        fun render() {
            val fl = favs()
            list.adapter = rowAdapter(fl.map { it.item }, emptySet())
            list.setOnItemClickListener { _, _, i, _ ->
                val f = fl[i]
                if (f.kind == Kind.LIVE) {
                    val l = fl.filter { it.kind == Kind.LIVE }.map { it.item }
                    openItem(Kind.LIVE, l, l.indexOf(f.item)) { showFavorites() }
                } else {
                    openItem(f.kind, listOf(f.item), 0) { showFavorites() }
                }
            }
            list.setOnItemLongClickListener { _, _, i, _ -> toggleFav(fl[i].kind, fl[i].item); render(); true }
        }
        render()
    }

    private fun showAccount() {
        val tok = ++screen; onBack = { showHome() }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(64, 32, 64, 32); text = "جارٍ التحميل..."
        }
        page("الحساب", tv, sel = 5)
        load("acc_${user.hashCode()}", "", tok) { t ->
            val u = JSONObject(t).getJSONObject("user_info")
            val exp = u.optString("exp_date").toLongOrNull()
                ?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it * 1000)) } ?: "غير محدود"
            tv.text = "المستخدم: ${u.optString("username")}\n" +
                "الحالة: ${u.optString("status")}\n" +
                "ينتهي: $exp\n" +
                "الاتصالات: ${u.optString("active_cons")} / ${u.optString("max_connections")}"
        }
    }

    private fun showSettings() {
        screen++; onBack = { showHome() }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(64, 16, 64, 16) }
        val sizes = arrayOf("صغير", "متوسط", "كبير")
        val buf = tile("")
        fun upd() { buf.text = "حجم تخزين المشغّل المؤقت: " + sizes[prefs.getInt("buf", 1).coerceIn(0, 2)] }
        upd()
        buf.setOnClickListener {
            prefs.edit().putInt("buf", (prefs.getInt("buf", 1) + 1) % 3).apply(); upd()
        }
        val clear = tile("مسح الكاش")
        clear.setOnClickListener { cacheDir.listFiles()?.forEach { it.delete() }; toast("تم مسح الكاش") }
        val out = tile("تسجيل الخروج")
        out.setOnClickListener {
            prefs.edit().remove("u").remove("p").apply()
            cacheDir.listFiles()?.forEach { it.delete() }
            user = ""; pass = ""; showLogin()
        }
        for (b in listOf(buf, clear, out)) {
            col.addView(b, LinearLayout.LayoutParams(-1, 130).apply { setMargins(0, 12, 0, 12) })
        }
        col.addView(TextView(this).apply { text = "AJIPTV 1.4"; setTextColor(Color.GRAY); gravity = Gravity.CENTER })
        page("الإعدادات", ScrollView(this).apply { addView(col) }, sel = 6)
        buf.requestFocus()
    }
}

package com.aj.iptv

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.aj.iptv.player.PlayQueue
import com.aj.iptv.player.PlayerActivity
import com.aj.iptv.player.Xtream
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

enum class Kind(val label: String, val catAction: String, val listAction: String) {
    LIVE("بث مباشر", "get_live_categories", "get_live_streams"),
    MOVIE("أفلام", "get_vod_categories", "get_vod_streams"),
    SERIES("مسلسلات", "get_series_categories", "get_series")
}

data class Item(val id: String, val name: String, val ext: String = "")
data class Fav(val kind: Kind, val item: Item)

class MainActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private val bg = Color.parseColor("#0B1A2E")
    private var user = ""
    private var pass = ""
    private var screen = 0
    private var onBack: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val b = onBack
                if (b != null) b() else finish()
            }
        })
        user = prefs.getString("u", "").orEmpty()
        pass = prefs.getString("p", "").orEmpty()
        showSplash()
    }

    // ---------- network + cache ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(extra: String = ""): String {
        val u = "http://${Xtream.HOST}:${Xtream.PORT}/player_api.php?username=${enc(user)}&password=${enc(pass)}$extra"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Shows cached data instantly, then refreshes from the server. */
    private fun load(key: String, extra: String, tok: Int, show: (String) -> Unit) {
        val f = File(cacheDir, "$key.json")
        if (f.exists()) try { show(f.readText()) } catch (_: Exception) { }
        io.execute {
            try {
                val t = api(extra)
                JSONTokener(t).nextValue()
                f.writeText(t)
                ui.post {
                    if (tok == screen && !isFinishing) try { show(t) } catch (_: Exception) { }
                }
            } catch (e: Exception) {
                ui.post {
                    if (tok == screen && !f.exists()) toast("تعذّر التحميل، تحقق من الاتصال")
                }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---------- favorites ----------
    private fun favs(): MutableList<Fav> {
        val out = ArrayList<Fav>()
        try {
            val a = JSONArray(prefs.getString("fav", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Fav(Kind.valueOf(o.getString("k")), Item(o.getString("id"), o.getString("n"), o.optString("e"))))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun toggleFav(k: Kind, item: Item) {
        val l = favs()
        val ex = l.find { it.kind == k && it.item.id == item.id }
        if (ex != null) l.remove(ex) else l.add(Fav(k, item))
        val a = JSONArray()
        l.forEach {
            a.put(JSONObject().put("k", it.kind.name).put("id", it.item.id).put("n", it.item.name).put("e", it.item.ext))
        }
        prefs.edit().putString("fav", a.toString()).apply()
    }

    // ---------- UI helpers ----------
    private fun adapter(items: List<String>) =
        object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(Color.WHITE)
                t.textSize = 18f
                t.setPadding(48, 30, 48, 30)
                return t
            }
        }

    private fun newList() = ListView(this).apply {
        divider = null
        isFocusable = true
        selector = ColorDrawable(Color.parseColor("#664C8DFF"))
    }

    private fun tileBg(): StateListDrawable {
        fun rect(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = 28f }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), rect(Color.parseColor("#2E7BFF")))
            addState(intArrayOf(android.R.attr.state_pressed), rect(Color.parseColor("#2E7BFF")))
            addState(intArrayOf(), rect(Color.parseColor("#17304F")))
        }
    }

    private fun tile(label: String) = Button(this).apply {
        text = label; textSize = 22f; isAllCaps = false
        setTextColor(Color.WHITE); background = tileBg()
    }

    private fun page(title: String, content: View, extra: View? = null) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        col.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 22f; setPadding(48, 24, 48, 12)
        })
        extra?.let { col.addView(it) }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(col)
    }

    private fun play(urls: List<String>, names: List<String>, index: Int, live: Boolean) {
        PlayQueue.urls = urls
        PlayQueue.names = names
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", index).putExtra("live", live))
    }

    private fun openItem(kind: Kind, s: List<Item>, i: Int, back: () -> Unit) {
        when (kind) {
            Kind.LIVE -> play(s.map { Xtream.live(user, pass, it.id) }, s.map { it.name }, i, true)
            Kind.MOVIE -> {
                val m = s[i]
                play(listOf(Xtream.movie(user, pass, m.id, m.ext.ifEmpty { "mp4" })), listOf(m.name), 0, false)
            }
            Kind.SERIES -> showEpisodes(s[i].id, s[i].name, back)
        }
    }

    // ---------- screens ----------
    private fun showSplash() {
        val f = FrameLayout(this).apply { setBackgroundColor(bg) }
        f.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, FrameLayout.LayoutParams(360, 360, Gravity.CENTER))
        setContentView(f)
        ui.postDelayed({
            if (!isFinishing) { if (user.isNotEmpty()) showHome() else showLogin() }
        }, 900)
    }

    private fun showLogin() {
        screen++; onBack = null
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 32, 64, 32); setBackgroundColor(bg)
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(260, 260))
        fun field(h: String, secret: Boolean) = EditText(this).apply {
            hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val u = field("اسم المستخدم", false)
        val p = field("كلمة المرور", true)
        val err = TextView(this).apply { setTextColor(Color.parseColor("#FF6B6B")); gravity = Gravity.CENTER }
        val btn = tile("دخول")
        btn.setOnClickListener {
            user = u.text.toString().trim(); pass = p.text.toString().trim()
            if (user.isEmpty() || pass.isEmpty()) { err.text = "أدخل اسم المستخدم وكلمة المرور"; return@setOnClickListener }
            btn.isEnabled = false; err.text = "جارٍ التحقق..."
            io.execute {
                val ok = try { JSONObject(api()).getJSONObject("user_info").optInt("auth") == 1 } catch (e: Exception) { false }
                ui.post {
                    if (ok) {
                        prefs.edit().putString("u", user).putString("p", pass).apply()
                        showHome()
                    } else {
                        btn.isEnabled = true; err.text = "فشل الدخول: تحقق من البيانات أو الاتصال"
                    }
                }
            }
        }
        col.addView(u, LinearLayout.LayoutParams(-1, -2))
        col.addView(p, LinearLayout.LayoutParams(-1, -2))
        col.addView(err, LinearLayout.LayoutParams(-1, -2))
        col.addView(btn, LinearLayout.LayoutParams(-1, 140).apply { topMargin = 16 })
        setContentView(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(col) })
        u.requestFocus()
    }

    private fun showHome() {
        screen++; onBack = null
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 0, 24, 24) }
        val tiles: List<Pair<String, () -> Unit>> = listOf(
            "📺\nبث مباشر" to { showCategories(Kind.LIVE) },
            "🎬\nأفلام" to { showCategories(Kind.MOVIE) },
            "🎞️\nمسلسلات" to { showCategories(Kind.SERIES) },
            "⭐\nالمفضلة" to { showFavorites() },
            "👤\nالحساب" to { showAccount() },
            "⚙️\nالإعدادات" to { showSettings() }
        )
        var first: View? = null
        for (r in 0..1) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0..2) {
                val (label, action) = tiles[r * 3 + c]
                val b = tile(label)
                b.setOnClickListener { action() }
                row.addView(b, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(16, 16, 16, 16) })
                if (first == null) first = b
            }
            grid.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        page("AJIPTV", grid)
        first?.requestFocus()
    }

    private fun showCategories(kind: Kind) {
        val tok = ++screen; onBack = { showHome() }
        val list = newList()
        page(kind.label, list)
        list.requestFocus()
        load("cats_${kind.name}_${user.hashCode()}", "&action=${kind.catAction}", tok) { t ->
            val arr = JSONArray(t)
            val ids = ArrayList<String>(); val names = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                ids.add(o.get("category_id").toString()); names.add(o.getString("category_name"))
            }
            list.adapter = adapter(names)
            list.setOnItemClickListener { _, _, i, _ -> showItems(kind, ids[i], names[i]) }
        }
    }

    private fun showItems(kind: Kind, catId: String, catName: String) {
        val tok = ++screen; onBack = { showCategories(kind) }
        val list = newList()
        val q = EditText(this).apply {
            hint = "بحث  (اضغط مطولاً للمفضلة)"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(); setPadding(48, 20, 48, 20)
        }
        page(catName, list, extra = q)
        list.requestFocus()
        var all: List<Item> = emptyList()
        var shown: List<Item> = emptyList()
        fun render() {
            val pos = list.firstVisiblePosition
            val t = q.text.toString().trim().lowercase()
            val favIds = favs().filter { it.kind == kind }.map { it.item.id }.toSet()
            shown = all.filter { t.isEmpty() || it.name.lowercase().contains(t) }
            list.adapter = adapter(shown.map { (if (it.id in favIds) "★ " else "") + it.name })
            list.setSelection(pos)
            list.setOnItemClickListener { _, _, i, _ ->
                openItem(kind, shown, i) { showItems(kind, catId, catName) }
            }
            list.setOnItemLongClickListener { _, _, i, _ -> toggleFav(kind, shown[i]); render(); true }
        }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = render()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        val idKey = if (kind == Kind.SERIES) "series_id" else "stream_id"
        load("it_${kind.name}_${user.hashCode()}_$catId", "&action=${kind.listAction}&category_id=$catId", tok) { t ->
            val arr = JSONArray(t)
            all = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Item(o.get(idKey).toString(), o.getString("name"), o.optString("container_extension"))
            }
            render()
        }
    }

    private fun showEpisodes(seriesId: String, title: String, back: () -> Unit) {
        val tok = ++screen; onBack = back
        val list = newList()
        page(title, list)
        list.requestFocus()
        load("ep_${user.hashCode()}_$seriesId", "&action=get_series_info&series_id=$seriesId", tok) { t ->
            val raw = JSONObject(t).opt("episodes")
            val seasons = LinkedHashMap<String, JSONArray>()
            if (raw is JSONObject) {
                raw.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { seasons[it] = raw.getJSONArray(it) }
            } else if (raw is JSONArray) {
                for (i in 0 until raw.length()) seasons["${i + 1}"] = raw.optJSONArray(i) ?: JSONArray()
            }
            val items = ArrayList<Item>()
            for ((s, arr) in seasons) {
                for (j in 0 until arr.length()) {
                    val o = arr.getJSONObject(j)
                    val num = o.optString("episode_num", "${j + 1}")
                    val ttl = o.optString("title")
                    val label = "الموسم $s - الحلقة $num" + if (ttl.isNotEmpty()) " | $ttl" else ""
                    items.add(Item(o.get("id").toString(), label, o.optString("container_extension")))
                }
            }
            list.adapter = adapter(items.map { it.name })
            list.setOnItemClickListener { _, _, i, _ ->
                play(
                    items.map { Xtream.episode(user, pass, it.id, it.ext.ifEmpty { "mp4" }) },
                    items.map { title + " - " + it.name },
                    i, false
                )
            }
        }
    }

    private fun showFavorites() {
        screen++; onBack = { showHome() }
        val list = newList()
        page("المفضلة  (اضغط مطولاً للحذف)", list)
        list.requestFocus()
        fun render() {
            val fl = favs()
            val icon = mapOf(Kind.LIVE to "📺 ", Kind.MOVIE to "🎬 ", Kind.SERIES to "🎞️ ")
            list.adapter = adapter(fl.map { icon[it.kind] + it.item.name })
            list.setOnItemClickListener { _, _, i, _ ->
                val f = fl[i]
                if (f.kind == Kind.LIVE) {
                    val l = fl.filter { it.kind == Kind.LIVE }.map { it.item }
                    openItem(Kind.LIVE, l, l.indexOf(f.item)) { showFavorites() }
                } else {
                    openItem(f.kind, listOf(f.item), 0) { showFavorites() }
                }
            }
            list.setOnItemLongClickListener { _, _, i, _ -> toggleFav(fl[i].kind, fl[i].item); render(); true }
        }
        render()
    }

    private fun showAccount() {
        val tok = ++screen; onBack = { showHome() }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(64, 32, 64, 32); text = "جارٍ التحميل..."
        }
        page("الحساب", tv)
        load("acc_${user.hashCode()}", "", tok) { t ->
            val u = JSONObject(t).getJSONObject("user_info")
            val exp = u.optString("exp_date").toLongOrNull()
                ?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it * 1000)) } ?: "غير محدود"
            tv.text = "المستخدم: ${u.optString("username")}\n" +
                "الحالة: ${u.optString("status")}\n" +
                "ينتهي: $exp\n" +
                "الاتصالات: ${u.optString("active_cons")} / ${u.optString("max_connections")}"
        }
    }

    private fun showSettings() {
        screen++; onBack = { showHome() }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(64, 16, 64, 16)
        }
        val sizes = arrayOf("صغير", "متوسط", "كبير")
        val buf = tile("")
        fun upd() { buf.text = "حجم تخزين المشغّل المؤقت: " + sizes[prefs.getInt("buf", 1).coerceIn(0, 2)] }
        upd()
        buf.setOnClickListener {
            prefs.edit().putInt("buf", (prefs.getInt("buf", 1) + 1) % 3).apply(); upd()
        }
        val clear = tile("مسح الكاش")
        clear.setOnClickListener { cacheDir.listFiles()?.forEach { it.delete() }; toast("تم مسح الكاش") }
        val out = tile("تسجيل الخروج")
        out.setOnClickListener {
            prefs.edit().remove("u").remove("p").apply()
            cacheDir.listFiles()?.forEach { it.delete() }
            user = ""; pass = ""; showLogin()
        }
        for (b in listOf(buf, clear, out)) {
            col.addView(b, LinearLayout.LayoutParams(-1, 130).apply { setMargins(0, 12, 0, 12) })
        }
        col.addView(TextView(this).apply { text = "AJIPTV 1.2"; setTextColor(Color.GRAY); gravity = Gravity.CENTER })
        page("الإعدادات", ScrollView(this).apply { addView(col) })
        buf.requestFocus()
    }
}

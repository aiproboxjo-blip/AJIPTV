package com.aj.iptv

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.aj.iptv.player.PlayerActivity
import com.aj.iptv.player.Xtream
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private val bg = Color.parseColor("#0B1A2E")
    private var user = ""
    private var pass = ""
    private var level = 0
    private var screen = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (level == 2) showCategories() else finish()
            }
        })
        user = prefs.getString("u", "").orEmpty()
        pass = prefs.getString("p", "").orEmpty()
        if (user.isNotEmpty()) showCategories() else showLogin()
    }

    // ---------- network + cache ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(extra: String = ""): String {
        val u = "http://${Xtream.HOST}:${Xtream.PORT}/player_api.php?username=${enc(user)}&password=${enc(pass)}$extra"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 25_000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Shows cached data instantly, then refreshes from the server. */
    private fun load(key: String, extra: String, tok: Int, show: (JSONArray) -> Unit) {
        val f = File(cacheDir, "$key.json")
        if (f.exists()) try { show(JSONArray(f.readText())) } catch (_: Exception) { }
        io.execute {
            try {
                val t = api(extra)
                val arr = JSONArray(t)
                f.writeText(t)
                ui.post { if (tok == screen && !isFinishing) show(arr) }
            } catch (e: Exception) {
                ui.post {
                    if (tok == screen && !f.exists()) {
                        android.widget.Toast.makeText(this, "تعذّر التحميل، تحقق من الاتصال", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    // ---------- UI helpers ----------
    private fun adapter(items: List<String>) =
        object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(Color.WHITE)
                t.setPadding(40, 30, 40, 30)
                return t
            }
        }

    private fun page(title: String, content: View, extra: View? = null, right: View? = null) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(40, 40, 40, 20) }
        head.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 20f
        }, LinearLayout.LayoutParams(0, -2, 1f))
        right?.let { head.addView(it) }
        col.addView(head)
        extra?.let { col.addView(it) }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(col)
    }

    // ---------- screens ----------
    private fun showLogin() {
        level = 0; screen++
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64); setBackgroundColor(bg)
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(420, 420))
        fun field(h: String, secret: Boolean) = EditText(this).apply {
            hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val u = field("اسم المستخدم", false)
        val p = field("كلمة المرور", true)
        val err = TextView(this).apply { setTextColor(Color.parseColor("#FF6B6B")); gravity = Gravity.CENTER }
        val btn = Button(this).apply { text = "دخول" }
        btn.setOnClickListener {
            user = u.text.toString().trim(); pass = p.text.toString().trim()
            if (user.isEmpty() || pass.isEmpty()) { err.text = "أدخل اسم المستخدم وكلمة المرور"; return@setOnClickListener }
            btn.isEnabled = false; err.text = "جارٍ التحقق..."
            io.execute {
                val ok = try { JSONObject(api()).getJSONObject("user_info").optInt("auth") == 1 } catch (e: Exception) { false }
                ui.post {
                    if (ok) {
                        prefs.edit().putString("u", user).putString("p", pass).apply()
                        showCategories()
                    } else {
                        btn.isEnabled = true; err.text = "فشل الدخول: تحقق من البيانات أو الاتصال"
                    }
                }
            }
        }
        listOf<View>(u, p, err, btn).forEach { col.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        setContentView(col)
    }

    private fun showCategories() {
        level = 1; val tok = ++screen
        val list = ListView(this).apply { divider = null }
        val out = TextView(this).apply {
            text = "خروج"; setTextColor(Color.parseColor("#7FB4FF")); setPadding(20, 10, 20, 10)
            setOnClickListener {
                prefs.edit().clear().apply()
                cacheDir.listFiles()?.forEach { it.delete() }
                user = ""; pass = ""; showLogin()
            }
        }
        page("AJIPTV", list, right = out)
        load("cats_${user.hashCode()}", "&action=get_live_categories", tok) { arr ->
            val ids = ArrayList<String>(); val names = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                ids.add(o.get("category_id").toString()); names.add(o.getString("category_name"))
            }
            list.adapter = adapter(names)
            list.setOnItemClickListener { _, _, i, _ -> showChannels(ids[i], names[i]) }
        }
    }

    private fun showChannels(catId: String, name: String) {
        level = 2; val tok = ++screen
        val list = ListView(this).apply { divider = null }
        val q = EditText(this).apply {
            hint = "بحث"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(); setPadding(40, 24, 40, 24)
        }
        page(name, list, extra = q)
        var all: List<Pair<String, String>> = emptyList()
        fun render() {
            val t = q.text.toString().trim().lowercase()
            val s = all.filter { t.isEmpty() || it.second.lowercase().contains(t) }
            list.adapter = adapter(s.map { it.second })
            list.setOnItemClickListener { _, _, i, _ ->
                startActivity(
                    Intent(this, PlayerActivity::class.java)
                        .putExtra("url", Xtream.live(user, pass, s[i].first))
                        .putExtra("name", s[i].second)
                )
            }
        }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = render()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        load("ch_${user.hashCode()}_$catId", "&action=get_live_streams&category_id=$catId", tok) { arr ->
            all = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                o.get("stream_id").toString() to o.getString("name")
            }
            render()
        }
    }
}

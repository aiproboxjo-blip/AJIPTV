package com.aj.iptv

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Base64
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.RawResourceDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.aj.iptv.player.AjPlayer
import com.aj.iptv.player.FfmpegInfo
import com.aj.iptv.player.PlayQueue
import com.aj.iptv.player.PlayerActivity
import com.aj.iptv.player.StreamInfo
import com.aj.iptv.player.VlcBridge
import com.aj.iptv.player.Xtream
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

enum class Kind(val label: String, val catAction: String, val listAction: String) {
    LIVE("بث مباشر", "get_live_categories", "get_live_streams"),
    MOVIE("أفلام", "get_vod_categories", "get_vod_streams"),
    SERIES("مسلسلات", "get_series_categories", "get_series")
}

data class Item(
    val id: String, val name: String, val ext: String = "",
    val img: String = "", val rating: String = ""
)

data class Fav(val kind: Kind, val item: Item)

object Cloud {
    const val DB = "https://ajiptv-5b2d8-default-rtdb.firebaseio.com"
}

private fun JSONObject.str(k: String): String {
    val s = optString(k, "")
    return if (s == "null") "" else s.trim()
}

private fun JSONObject.firstOf(vararg ks: String): String =
    ks.map { str(it) }.firstOrNull { it.isNotEmpty() } ?: ""

/** Small image loader: background download, downsample, memory cache. */
object Img {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(4)
    private val ui = Handler(Looper.getMainLooper())

    fun load(url: String, iv: ImageView, w: Int) {
        iv.tag = url
        iv.setImageDrawable(null)
        if (url.isBlank()) return
        cache.get(url)?.let { iv.setImageBitmap(it); return }
        pool.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 8_000
                c.readTimeout = 8_000
                val bytes = c.inputStream.use { it.readBytes() }
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= w) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: return@execute
                cache.put(url, bmp)
                ui.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
            } catch (_: Exception) { }
        }
    }
}

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("aj", MODE_PRIVATE) }
    private val bg = Color.parseColor("#05080D")
    private val surface = Color.parseColor("#0D141F")
    private val railW = 132
    private val accent = Color.parseColor("#4C8DFF")
    private val palette = intArrayOf(
        Color.parseColor("#2E7BFF"), Color.parseColor("#7A4DFF"), Color.parseColor("#E0457B"),
        Color.parseColor("#19A974"), Color.parseColor("#E69F00"), Color.parseColor("#00A6C8")
    )
    private var user = ""
    private var pass = ""
    private var screen = 0
    private var onBack: (() -> Unit)? = null
    private val lastCat = HashMap<Kind, String>()
    private var onVoice: ((String) -> Unit)? = null

    // inline live preview (TV / large screens)
    private var preview: AjPlayer? = null
    private var selId = ""
    private var selItem: Item? = null
    private var pvInfoTv: TextView? = null
    private var intro: ExoPlayer? = null
    private val infoTick = object : Runnable {
        override fun run() {
            val p = preview
            val tv = pvInfoTv
            if (p != null && tv != null) {
                tv.text = if (selId.isEmpty()) "" else StreamInfo.text(p.player, this@MainActivity)
                ui.postDelayed(this, 2000)
            }
        }
    }

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrEmpty()) onVoice?.invoke(t)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val b = onBack
                if (b != null) b() else finish()
            }
        })
        user = prefs.getString("u", "").orEmpty()
        pass = prefs.getString("p", "").orEmpty()
        Xtream.HOST = prefs.getString("host", Xtream.HOST).orEmpty().ifEmpty { Xtream.HOST }
        Xtream.PORT = prefs.getInt("port", Xtream.PORT)
        showSplash()
    }

    override fun onStop() {
        super.onStop()
        preview?.stop()
        selId = ""
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePreview()
    }

    private fun releasePreview() {
        intro?.release(); intro = null
        ui.removeCallbacks(infoTick); pvInfoTv = null
        preview?.release(); preview = null
        selId = ""; selItem = null
    }

    private fun setScreen(v: View) {
        releasePreview()
        v.alpha = 0f
        setContentView(v)
        v.animate().alpha(1f).setDuration(220).start()
    }

    // ---------- network + cache ----------
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun api(extra: String = ""): String {
        val u = "http://${Xtream.HOST}:${Xtream.PORT}/player_api.php?username=${enc(user)}&password=${enc(pass)}$extra"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 30_000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** Shows cached data instantly, then refreshes from the server. */
    private fun load(key: String, extra: String, tok: Int, show: (String) -> Unit) {
        val f = File(cacheDir, "$key.json")
        if (f.exists()) try { show(f.readText()) } catch (_: Exception) { }
        io.execute {
            try {
                val t = api(extra)
                JSONTokener(t).nextValue()
                f.writeText(t)
                ui.post {
                    if (tok == screen && !isFinishing) try { show(t) } catch (_: Exception) { }
                }
            } catch (e: Exception) {
                ui.post {
                    if (tok == screen && !f.exists()) toast("تعذّر التحميل، تحقق من الاتصال")
                }
            }
        }
    }

    private fun parseItems(kind: Kind, t: String): List<Item> {
        val idKey = if (kind == Kind.SERIES) "series_id" else "stream_id"
        val imgKey = if (kind == Kind.SERIES) "cover" else "stream_icon"
        val arr = JSONArray(t)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Item(o.get(idKey).toString(), o.getString("name"), o.str("container_extension"), o.str(imgKey), o.str("rating"))
        }
    }

    /** Items of the first category (cached, shared with the browse screens). */
    private fun loadFirst(kind: Kind, tok: Int, cb: (List<Item>) -> Unit) {
        load("cats_${kind.name}_${user.hashCode()}", "&action=${kind.catAction}", tok) { t ->
            val arr = JSONArray(t)
            if (arr.length() > 0) {
                val c = arr.getJSONObject(0).get("category_id").toString()
                load("it_${kind.name}_${user.hashCode()}_$c", "&action=${kind.listAction}&category_id=$c", tok) { t2 ->
                    cb(parseItems(kind, t2))
                }
            }
        }
    }

    private fun loadEpg(streamId: String, tv: TextView) {
        io.execute {
            val txt = try {
                val a = JSONObject(api("&action=get_short_epg&stream_id=$streamId&limit=3")).optJSONArray("epg_listings")
                val sb = StringBuilder()
                if (a != null) {
                    for (i in 0 until a.length()) {
                        val e = a.getJSONObject(i)
                        val title = String(Base64.decode(e.optString("title"), Base64.DEFAULT), Charsets.UTF_8)
                        val st = e.optString("start_timestamp").toLongOrNull()
                        val time = if (st != null) SimpleDateFormat("HH:mm", Locale.US).format(Date(st * 1000)) else ""
                        val tag = if (i == 0) "الآن" else if (i == 1) "التالي" else "لاحقاً"
                        sb.append(tag).append("   ").append(time).append("   ").append(title).append("\n\n")
                    }
                }
                if (sb.isEmpty()) "لا يوجد دليل برامج لهذه القناة" else sb.toString()
            } catch (e: Exception) {
                "لا يوجد دليل برامج لهذه القناة"
            }
            ui.post { if (selId == streamId) tv.text = txt }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun startVoice(cb: (String) -> Unit) {
        onVoice = cb
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "تكلّم الآن")
            )
        } catch (e: Exception) {
            toast("البحث الصوتي غير متاح على هذا الجهاز")
        }
    }

    // ---------- favorites + recent ----------
    private fun readList(key: String): MutableList<Fav> {
        val out = ArrayList<Fav>()
        try {
            val a = JSONArray(prefs.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(
                    Fav(
                        Kind.valueOf(o.getString("k")),
                        Item(o.getString("id"), o.getString("n"), o.optString("e"), o.optString("i"))
                    )
                )
            }
        } catch (_: Exception) { }
        return out
    }

    private fun writeList(key: String, l: List<Fav>) {
        val a = JSONArray()
        l.forEach {
            a.put(
                JSONObject().put("k", it.kind.name).put("id", it.item.id).put("n", it.item.name)
                    .put("e", it.item.ext).put("i", it.item.img)
            )
        }
        prefs.edit().putString(key, a.toString()).apply()
    }

    private fun favs() = readList("fav")

    private fun toggleFav(k: Kind, item: Item) {
        val l = favs()
        val ex = l.find { it.kind == k && it.item.id == item.id }
        if (ex != null) l.remove(ex) else l.add(Fav(k, item))
        writeList("fav", l)
    }

    private fun addRecent(k: Kind, item: Item) {
        val l = readList("recent")
        l.removeAll { it.kind == k && it.item.id == item.id }
        l.add(0, Fav(k, item))
        writeList("recent", l.take(12))
    }

    // ---------- UI helpers ----------
    private fun adapter(items: List<String>) =
        object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val t = super.getView(p, v, g) as TextView
                t.setTextColor(Color.WHITE)
                t.textSize = 17f
                t.setPadding(40, 26, 40, 26)
                return t
            }
        }

    private fun newList() = ListView(this).apply {
        divider = null
        isFocusable = true
        selector = ColorDrawable(Color.parseColor("#664C8DFF"))
    }

    private fun roundBg(normal: Int, focused: Int, stroke: Int = Color.parseColor("#1F2C3F")): StateListDrawable {
        fun rect(c: Int, sw: Int, sc: Int) = GradientDrawable().apply {
            setColor(c); cornerRadius = 22f; if (sw > 0) setStroke(sw, sc)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), rect(focused, 4, accent))
            addState(intArrayOf(android.R.attr.state_pressed), rect(focused, 4, accent))
            addState(intArrayOf(), rect(normal, 2, stroke))
        }
    }

    private fun tile(label: String) = Button(this).apply {
        text = label; textSize = 20f; isAllCaps = false; stateListAnimator = null
        setTextColor(Color.WHITE); background = roundBg(surface, Color.parseColor("#14223A"))
    }

    /** Main action button: silver fill, turns blue when focused. */
    private fun primaryTile(label: String) = Button(this).apply {
        text = label; textSize = 20f; isAllCaps = false; stateListAnimator = null
        setTextColor(
            ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_focused), intArrayOf()),
                intArrayOf(Color.WHITE, Color.parseColor("#0A0F18"))
            )
        )
        background = roundBg(Color.parseColor("#E8EDF4"), accent, Color.TRANSPARENT)
    }

    private fun fieldBg() = GradientDrawable().apply {
        setColor(surface); setStroke(2, Color.parseColor("#1F2C3F")); cornerRadius = 18f
    }

    private fun newBackdrop() = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.4f
    }

    /** Blurred poster behind the content (tiny bitmap scaled up = soft), with dark scrims. */
    private fun backdropFrame(backdrop: ImageView, content: View): FrameLayout {
        val f = FrameLayout(this).apply { setBackgroundColor(bg) }
        f.addView(backdrop, FrameLayout.LayoutParams(-1, -1))
        f.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(bg, Color.TRANSPARENT))
        }, FrameLayout.LayoutParams(-1, -1))
        f.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, bg))
        }, FrameLayout.LayoutParams(-1, -1))
        f.addView(content, FrameLayout.LayoutParams(-1, -1))
        return f
    }

    private fun cellBg(): StateListDrawable {
        val on = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(5, accent); cornerRadius = 20f }
        val off = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), on)
            addState(intArrayOf(), off)
        }
    }

    /** Left rail: icon + label for every main section. */
    private fun withRail(sel: Int, content: View): View {
        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#03050A")); setPadding(0, 16, 0, 16)
        }
        rail.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(72, 72).apply { bottomMargin = 8 })
        val icons = listOf("🏠", "📺", "🎬", "🎞️", "⭐", "👤", "⚙️")
        val names = listOf("الرئيسية", "مباشر", "أفلام", "مسلسلات", "المفضلة", "حسابي", "الإعدادات")
        val acts: List<() -> Unit> = listOf(
            { showHome() }, { showBrowse(Kind.LIVE) }, { showBrowse(Kind.MOVIE) }, { showBrowse(Kind.SERIES) },
            { showFavorites() }, { showAccount() }, { showSettings() }
        )
        icons.forEachIndexed { i, ic ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                isFocusable = true; isClickable = true
                background = roundBg(
                    if (i == sel) Color.parseColor("#101C2E") else Color.TRANSPARENT,
                    Color.parseColor("#14223A"),
                    if (i == sel) accent else Color.TRANSPARENT
                )
            }
            cell.addView(TextView(this).apply { text = ic; textSize = 20f; gravity = Gravity.CENTER })
            cell.addView(TextView(this).apply {
                text = names[i]; textSize = 10f; gravity = Gravity.CENTER
                setTextColor(if (i == sel) Color.WHITE else Color.parseColor("#8FA0B5"))
            })
            cell.setOnClickListener { acts[i]() }
            rail.addView(cell, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(10, 4, 10, 4) })
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(bg) }
        root.addView(rail, LinearLayout.LayoutParams(railW, -1))
        root.addView(content, LinearLayout.LayoutParams(0, -1, 1f))
        return root
    }

    private fun page(title: String, content: View, extra: View? = null, sel: Int = -1) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        col.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.SERIF; setPadding(48, 24, 48, 12)
        })
        extra?.let { col.addView(it) }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setScreen(withRail(sel, col))
    }

    private fun badge() = TextView(this).apply {
        setTextColor(Color.WHITE); textSize = 10f; setPadding(12, 4, 12, 4); visibility = View.GONE
        background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = 10f }
    }

    /** Poster tile: coloured initial behind, image on top, rating + 4K badges. */
    private fun makePoster(crop: Boolean): FrameLayout {
        val f = FrameLayout(this)
        f.addView(TextView(this).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 28f
        })
        f.addView(ImageView(this).apply {
            scaleType = if (crop) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        })
        f.addView(badge(), FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(8, 8, 8, 8) })
        f.addView(badge(), FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(8, 8, 8, 8) })
        return f
    }

    private val fourK = Regex("(?i)(^|[^a-z0-9])(4k|uhd)([^a-z0-9]|$)")

    private fun bindPoster(f: FrameLayout, item: Item, w: Int) {
        val c = palette[(item.name.hashCode() and 0x7fffffff) % palette.size]
        f.background = GradientDrawable().apply { setColor(c); cornerRadius = 16f }
        (f.getChildAt(0) as TextView).text = item.name.trim().take(1)
        Img.load(item.img, f.getChildAt(1) as ImageView, w)
        val rt = f.getChildAt(2) as TextView
        if (item.rating.isNotEmpty() && item.rating != "0") {
            rt.text = "★ " + item.rating; rt.visibility = View.VISIBLE
        } else rt.visibility = View.GONE
        val qt = f.getChildAt(3) as TextView
        if (fourK.containsMatchIn(item.name)) {
            qt.text = "4K"; qt.setTextColor(accent); qt.visibility = View.VISIBLE
        } else qt.visibility = View.GONE
    }

    private fun posterAdapter(items: List<Item>, favIds: Set<String>, w: Int): BaseAdapter {
        val h = w * 3 / 2
        return object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val cell = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(makePoster(true), LinearLayout.LayoutParams(-1, h))
                    addView(TextView(this@MainActivity).apply {
                        setTextColor(Color.WHITE); textSize = 13f; maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END; setPadding(4, 6, 4, 0)
                    })
                }
                val item = items[p]
                bindPoster(cell.getChildAt(0) as FrameLayout, item, w)
                (cell.getChildAt(1) as TextView).text = (if (item.id in favIds) "★ " else "") + item.name
                return cell
            }
        }
    }

    private fun rowAdapter(items: List<Item>, favIds: Set<String>, sel: () -> String = { "" }): BaseAdapter =
        object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val row = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(32, 12, 32, 12)
                    addView(makePoster(false), LinearLayout.LayoutParams(120, 90))
                    addView(TextView(this@MainActivity).apply {
                        setTextColor(Color.WHITE); textSize = 17f; maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END; setPadding(24, 0, 0, 0)
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                val item = items[p]
                bindPoster(row.getChildAt(0) as FrameLayout, item, 120)
                val mark = if (item.id == sel()) "▶ " else if (item.id in favIds) "★ " else ""
                (row.getChildAt(1) as TextView).text = mark + item.name
                return row
            }
        }

    private fun play(urls: List<String>, names: List<String>, index: Int, live: Boolean, icons: List<String> = emptyList()) {
        PlayQueue.urls = urls
        PlayQueue.names = names
        PlayQueue.icons = icons
        startActivity(Intent(this, PlayerActivity::class.java).putExtra("index", index).putExtra("live", live))
    }

    /** Live plays directly (with channel zapping); movies and series open the details page. */
    private fun openItem(kind: Kind, s: List<Item>, i: Int, back: () -> Unit) {
        if (kind == Kind.LIVE) {
            play(s.map { Xtream.live(user, pass, it.id) }, s.map { it.name }, i, true, s.map { it.img })
        } else {
            showDetails(kind, s[i], back)
        }
    }

    // ---------- remote activation (from the owner's admin app) ----------
    private fun deviceId(): String {
        var d = prefs.getString("did", "").orEmpty()
        if (d.length != 8) {
            val a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
            val r = java.security.SecureRandom()
            d = (1..8).map { a[r.nextInt(a.length)] }.joinToString("")
            prefs.edit().putString("did", d).apply()
        }
        return d
    }

    private fun codeText() = deviceId().let { it.substring(0, 4) + "-" + it.substring(4) }

    /** Copy / share buttons for the device code. */
    private fun codeActions(): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val copy = tile("📋  نسخ الرمز")
        copy.textSize = 14f
        copy.setOnClickListener {
            val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("device", codeText()))
            toast("تم نسخ الرمز: " + codeText())
        }
        val share = tile("📤  مشاركة")
        share.textSize = 14f
        share.setOnClickListener {
            startActivity(
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, "رمز جهازي في AJIPTV: " + codeText()),
                    "مشاركة"
                )
            )
        }
        row.addView(copy, LinearLayout.LayoutParams(0, 110, 1f).apply { setMargins(6, 8, 6, 0) })
        row.addView(share, LinearLayout.LayoutParams(0, 110, 1f).apply { setMargins(6, 8, 6, 0) })
        return row
    }

    private fun prettyId() = deviceId().let { it.substring(0, 4) + " - " + it.substring(4) }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun expired(rec: JSONObject): Boolean {
        val e = rec.optString("exp")
        return e.isNotEmpty() && e < today()
    }

    private fun usable(rec: JSONObject) =
        rec.optBoolean("active", true) && !expired(rec) &&
            rec.optString("user").isNotEmpty() && rec.optString("pass").isNotEmpty()

    /** (reachable, record). Record is null when the owner has not registered this device yet. */
    private fun fetchDevice(): Pair<Boolean, JSONObject?> = try {
        val c = URL("${Cloud.DB}/devices/${deviceId()}.json").openConnection() as HttpURLConnection
        c.connectTimeout = 8_000
        c.readTimeout = 8_000
        val t = c.inputStream.bufferedReader().use { it.readText() }.trim()
        Pair(true, if (t == "null" || t.isEmpty()) null else JSONObject(t))
    } catch (e: Exception) {
        Pair(false, null)
    }

    private fun applyRecord(rec: JSONObject) {
        val h = rec.optString("host").ifEmpty { Xtream.HOST }
        val p = rec.optInt("port", 0).let { if (it > 0) it else Xtream.PORT }
        val changed = rec.optString("user") != user || h != Xtream.HOST || p != Xtream.PORT
        if (changed) cacheDir.listFiles()?.forEach { it.delete() }
        user = rec.optString("user"); pass = rec.optString("pass")
        Xtream.HOST = h; Xtream.PORT = p
        prefs.edit().putString("u", user).putString("p", pass).putString("host", h).putInt("port", p)
            .putBoolean("loggedout", false).apply()
    }

    /** On every start: refresh credentials, show owner messages, enforce stop / expiry. */
    private fun checkDevice() {
        io.execute {
            val (ok, rec) = fetchDevice()
            ui.post {
                if (!ok || rec == null || isFinishing) return@post
                if (!rec.optBoolean("active", true) || expired(rec)) { showBlocked(rec); return@post }
                val m = rec.optString("msg")
                if (m.isNotEmpty() && m != prefs.getString("lastmsg", "")) {
                    toast(m); prefs.edit().putString("lastmsg", m).apply()
                }
                val differs = rec.optString("user") != user || rec.optString("pass") != pass ||
                    rec.optString("host").ifEmpty { Xtream.HOST } != Xtream.HOST
                if (usable(rec) && differs) { applyRecord(rec); showHome() }
            }
        }
    }

    /** Login screen: waits for the owner to activate this device code. */
    private fun pollDevice(tok: Int, status: TextView) {
        io.execute {
            val (ok, rec) = fetchDevice()
            ui.post {
                if (tok != screen || isFinishing) return@post
                if (rec != null && usable(rec)) {
                    applyRecord(rec); showHome(); return@post
                }
                status.text = when {
                    !ok -> "تحقق من اتصال الإنترنت..."
                    rec != null -> "الحساب موقوف أو منتهي. تواصل مع المزوّد"
                    else -> "بانتظار التفعيل من المزوّد..."
                }
                ui.postDelayed({ if (tok == screen) pollDevice(tok, status) }, 5000)
            }
        }
    }

    private fun showBlocked(rec: JSONObject) {
        screen++; onBack = null
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 32, 64, 32); setBackgroundColor(bg)
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(180, 180))
        col.addView(TextView(this).apply {
            text = if (expired(rec)) "انتهى اشتراكك" else "الحساب موقوف"
            setTextColor(Color.WHITE); textSize = 24f; typeface = Typeface.SERIF
            gravity = Gravity.CENTER; setPadding(0, 24, 0, 8)
        })
        col.addView(TextView(this).apply {
            text = "تواصل مع مزوّد الخدمة وأعطِه رمز جهازك:\n" + prettyId()
            setTextColor(Color.parseColor("#A9B4C2")); textSize = 15f; gravity = Gravity.CENTER
        })
        col.addView(codeActions(), LinearLayout.LayoutParams(-1, -2))
        val retry = tile("إعادة المحاولة")
        retry.setOnClickListener {
            io.execute {
                val (_, r2) = fetchDevice()
                ui.post {
                    if (r2 != null && usable(r2)) { applyRecord(r2); showHome() } else toast("لا يزال الحساب موقوفاً")
                }
            }
        }
        col.addView(retry, LinearLayout.LayoutParams(-1, 130).apply { topMargin = 24 })
        setScreen(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(col) })
        retry.requestFocus()
    }

    // ---------- in-app updates (GitHub releases) ----------
    private var updateChecked = false

    private fun localCode(): Long = try {
        PackageInfoCompat.getLongVersionCode(packageManager.getPackageInfo(packageName, 0))
    } catch (e: Exception) { 0L }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName.orEmpty()
    } catch (e: Exception) { "" }

    /** Asks GitHub for the newest release (once per launch, or on demand) and offers the update. */
    private fun checkUpdate(manual: Boolean = false) {
        if (updateChecked && !manual) return
        updateChecked = true
        io.execute {
            try {
                val c = URL("https://api.github.com/repos/aiproboxjo-blip/AJIPTV/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 8_000
                c.readTimeout = 8_000
                c.setRequestProperty("User-Agent", "AJIPTV")
                val tag = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optString("tag_name")
                val n = Regex("v(\\d+)").find(tag)?.groupValues?.get(1)?.toLongOrNull() ?: return@execute
                if (100 + n > localCode()) {
                    ui.post { if (!isFinishing) offerUpdate(tag) }
                } else if (manual) {
                    ui.post { toast("أنت على آخر إصدار (" + versionName() + ")") }
                }
            } catch (e: Exception) {
                if (manual) ui.post { toast("تعذّر فحص التحديثات") }
            }
        }
    }

    private fun offerUpdate(tag: String) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("تحديث جديد متوفر")
            .setMessage("في إصدار أحدث من AJIPTV ($tag). بدك تحدّث هلأ؟")
            .setPositiveButton("تحديث الآن") { _, _ -> downloadUpdate() }
            .setNegativeButton("لاحقاً", null)
            .show()
    }

    private fun downloadUpdate() {
        val dlg = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("جارٍ تنزيل التحديث").setMessage("0%").setCancelable(false).show()
        io.execute {
            try {
                val dir = getExternalFilesDir("updates") ?: cacheDir
                dir.mkdirs()
                val f = File(dir, "AJIPTV.apk")
                val c = URL("https://github.com/aiproboxjo-blip/AJIPTV/releases/latest/download/AJIPTV.apk").openConnection() as HttpURLConnection
                c.connectTimeout = 10_000
                c.readTimeout = 30_000
                val total = c.contentLength.toLong()
                c.inputStream.use { inp ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = -1
                        while (true) {
                            val r = inp.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r)
                            done += r
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; ui.post { dlg.setMessage("$p%") } }
                            }
                        }
                    }
                }
                ui.post { dlg.dismiss(); installApk(f) }
            } catch (e: Exception) {
                ui.post { dlg.dismiss(); toast("فشل التنزيل، جرّب لاحقاً") }
            }
        }
    }

    private fun installApk(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            toast("فعّل «السماح بالتثبيت من هذا المصدر» لتطبيق AJIPTV، وارجع اضغط تحديث")
            startActivity(
                Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ---------- screens ----------
    private fun route() { if (user.isNotEmpty()) { showHome(); checkDevice(); checkUpdate() } else showLogin() }

    /** Plays res/raw/intro.mp4 once, zoomed to fill the whole screen (tap / OK / back skips it). */
    private fun showSplash() {
        val id = resources.getIdentifier("intro", "raw", packageName)
        val f = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isFocusable = true; isClickable = true }
        if (id == 0) {
            f.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, FrameLayout.LayoutParams(360, 360, Gravity.CENTER))
            setScreen(f)
            ui.postDelayed({ if (!isFinishing) route() }, 900)
            return
        }
        var done = false
        fun skip() {
            if (done) return
            done = true
            intro?.release(); intro = null
            route()
        }
        setScreen(f)
        val pl = ExoPlayer.Builder(this).build()
        intro = pl
        val pv = PlayerView(this).apply {
            useController = false
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            setBackgroundColor(Color.BLACK)
        }
        pv.player = pl
        f.addView(pv, FrameLayout.LayoutParams(-1, -1))
        pl.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) ui.post { skip() } }
            override fun onPlayerError(error: PlaybackException) { ui.post { skip() } }
        })
        f.setOnClickListener { skip() }
        onBack = { skip() }
        f.requestFocus()
        pl.setMediaItem(MediaItem.fromUri(RawResourceDataSource.buildRawResourceUri(id)))
        pl.prepare()
        pl.playWhenReady = true
    }

    private fun showLogin() {
        val tok = ++screen; onBack = null
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(64, 32, 64, 32); setBackgroundColor(bg)
        }
        col.addView(ImageView(this).apply { setImageResource(R.drawable.logo) }, LinearLayout.LayoutParams(180, 180))
        col.addView(TextView(this).apply {
            text = "رمز جهازك: أعطِه لمزوّد الخدمة وبيفعّل حسابك لحاله"
            setTextColor(Color.parseColor("#A9B4C2")); textSize = 12f; gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = prettyId(); setTextColor(Color.WHITE); textSize = 26f
            typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER; setPadding(0, 6, 0, 2); setTextIsSelectable(true)
        })
        val statusTv = TextView(this).apply {
            setTextColor(accent); textSize = 12f; gravity = Gravity.CENTER; text = "بانتظار التفعيل من المزوّد..."
        }
        col.addView(statusTv)
        col.addView(codeActions(), LinearLayout.LayoutParams(-1, -2))
        fun field(h: String, secret: Boolean) = EditText(this).apply {
            hint = h; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
            background = fieldBg(); setPadding(36, 28, 36, 28)
            if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val u = field("اسم المستخدم", false)
        val p = field("كلمة المرور", true)
        val err = TextView(this).apply { setTextColor(Color.parseColor("#FF6B6B")); gravity = Gravity.CENTER }
        val btn = tile("دخول")
        btn.setOnClickListener {
            user = u.text.toString().trim(); pass = p.text.toString().trim()
            if (user.isEmpty() || pass.isEmpty()) { err.text = "أدخل اسم المستخدم وكلمة المرور"; return@setOnClickListener }
            btn.isEnabled = false; err.text = "جارٍ التحقق..."
            io.execute {
                val ok = try { JSONObject(api()).getJSONObject("user_info").optInt("auth") == 1 } catch (e: Exception) { false }
                ui.post {
                    if (ok) {
                        prefs.edit().putString("u", user).putString("p", pass).putBoolean("loggedout", false).apply()
                        showHome()
                    } else {
                        btn.isEnabled = true; err.text = "فشل الدخول: تحقق من البيانات أو الاتصال"
                    }
                }
            }
        }
        col.addView(u, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        col.addView(p, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 16 })
        col.addView(err, LinearLayout.LayoutParams(-1, -2))
        col.addView(btn, LinearLayout.LayoutParams(-1, 140).apply { topMargin = 16 })
        setScreen(ScrollView(this).apply { isFillViewport = true; setBackgroundColor(bg); addView(col) })
        u.requestFocus()
        if (prefs.getBoolean("loggedout", false)) {
            statusTv.text = "تم تسجيل الخروج. أدخل بياناتك، أو فعّل التفعيل التلقائي من المزوّد"
            val autoBtn = tile("🔓  تفعيل تلقائي من المزوّد")
            autoBtn.setOnClickListener {
                prefs.edit().putBoolean("loggedout", false).apply()
                autoBtn.visibility = View.GONE
                statusTv.text = "بانتظار التفعيل من المزوّد..."
                pollDevice(tok, statusTv)
            }
            col.addView(autoBtn, LinearLayout.LayoutParams(-1, 120).apply { topMargin = 12 })
        } else {
            pollDevice(tok, statusTv)
        }
    }

    private fun fillRow(holder: LinearLayout, title: String, list: List<Fav>, w: Int) {
        holder.removeAllViews()
        if (list.isEmpty()) return
        holder.addView(TextView(this).apply {
            text = title; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.SERIF; setPadding(8, 24, 0, 6)
        })
        holder.addView(View(this).apply { setBackgroundColor(accent) }, LinearLayout.LayoutParams(48, 4).apply { setMargins(8, 0, 0, 6) })
        val strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(8, 16, 8, 16); clipToPadding = false; clipChildren = false
        }
        list.take(30).forEach { f ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; isFocusable = true; isClickable = true
                background = cellBg(); setPadding(8, 8, 8, 8)
            }
            val p = makePoster(true)
            bindPoster(p, f.item, w)
            cell.addView(p, LinearLayout.LayoutParams(w, w * 3 / 2))
            cell.addView(TextView(this).apply {
                text = f.item.name; setTextColor(Color.WHITE); textSize = 12f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; setPadding(2, 6, 2, 0)
            }, LinearLayout.LayoutParams(w, -2))
            cell.setOnFocusChangeListener { v, has ->
                v.animate().scaleX(if (has) 1.07f else 1f).scaleY(if (has) 1.07f else 1f).setDuration(140).start()
            }
            cell.setOnClickListener { showDetails(f.kind, f.item) { showHome() } }
            strip.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, 12, 0) })
        }
        holder.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; clipToPadding = false; clipChildren = false; addView(strip)
        })
    }

    /** Hero banner + rows (continue watching, movies, series). */
    private fun showHome() {
        val tok = ++screen; onBack = null
        val dm = resources.displayMetrics
        val posterW = (dm.widthPixels * 0.16).toInt().coerceAtLeast(160)
        val rowW = (dm.widthPixels * 0.095).toInt().coerceAtLeast(120)
        var hero: Item? = null
        val backdrop = newBackdrop()
        val clock = TextClock(this).apply {
            format12Hour = "hh:mm a   •   EEE d MMM"; format24Hour = "HH:mm   •   EEE d MMM"
            setTextColor(Color.parseColor("#A9B4C2")); textSize = 14f; gravity = Gravity.END
        }

        val kicker = TextView(this).apply { text = "اقتراح AJIPTV"; setTextColor(accent); textSize = 13f }
        val titleTv = TextView(this).apply { text = "AJIPTV"; setTextColor(Color.WHITE); textSize = 40f; typeface = Typeface.SERIF; setPadding(0, 8, 0, 8) }
        val metaTv = TextView(this).apply { setTextColor(Color.parseColor("#A9B4C2")); textSize = 15f }
        val plotTv = TextView(this).apply {
            setTextColor(Color.parseColor("#C9D1DB")); textSize = 15f; maxLines = 3
            ellipsize = TextUtils.TruncateAt.END; setPadding(0, 12, 0, 0)
        }
        val playB = primaryTile("▶  تشغيل")
        val listB = tile("＋  قائمتي")
        val infoB = tile("ⓘ  تفاصيل")
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(playB, listB, infoB).forEach { btns.addView(it, LinearLayout.LayoutParams(250, 110).apply { setMargins(0, 20, 16, 0) }) }
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        text.addView(kicker); text.addView(titleTv); text.addView(metaTv); text.addView(plotTv); text.addView(btns)
        val poster = makePoster(true)
        val heroRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heroRow.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        heroRow.addView(poster, LinearLayout.LayoutParams(posterW, posterW * 3 / 2))

        playB.setOnClickListener {
            hero?.let { h ->
                addRecent(Kind.MOVIE, h)
                play(listOf(Xtream.movie(user, pass, h.id, h.ext.ifEmpty { "mp4" })), listOf(h.name), 0, false, listOf(h.img))
            }
        }
        listB.setOnClickListener { hero?.let { h -> toggleFav(Kind.MOVIE, h); toast("تم تحديث قائمتك") } }
        infoB.setOnClickListener { hero?.let { h -> showDetails(Kind.MOVIE, h) { showHome() } } }

        fun setHero(h: Item) {
            if (hero?.id == h.id) return
            hero = h
            titleTv.text = h.name
            metaTv.text = if (h.rating.isNotEmpty()) "⭐ ${h.rating}" else ""
            plotTv.text = ""
            bindPoster(poster, h, posterW)
            Img.load(h.img, backdrop, 64)
            load("vi_${user.hashCode()}_${h.id}", "&action=get_vod_info&vod_id=${h.id}", tok) { t ->
                if (hero?.id == h.id) {
                    val o = JSONObject(t).optJSONObject("info")
                    if (o != null) {
                        val meta = listOf(
                            if (h.rating.isNotEmpty()) "⭐ ${h.rating}" else "",
                            o.firstOf("releasedate", "releaseDate", "release_date", "year").take(4),
                            o.str("genre"), o.str("duration")
                        ).filter { it.isNotEmpty() }
                        metaTv.text = meta.joinToString("  •  ")
                        plotTv.text = o.firstOf("plot", "description")
                    }
                }
            }
        }

        val recentHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val moviesHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val seriesHolder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fillRow(recentHolder, "متابعة المشاهدة", readList("recent"), rowW)

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 32, 40, 32) }
        col.addView(clock); col.addView(heroRow); col.addView(recentHolder); col.addView(moviesHolder); col.addView(seriesHolder)
        setScreen(withRail(0, backdropFrame(backdrop, ScrollView(this).apply { addView(col) })))
        playB.requestFocus()

        loadFirst(Kind.MOVIE, tok) { items ->
            items.firstOrNull { it.img.isNotEmpty() }?.let { setHero(it) }
            fillRow(moviesHolder, "أفلام", items.map { Fav(Kind.MOVIE, it) }, rowW)
        }
        loadFirst(Kind.SERIES, tok) { items ->
            fillRow(seriesHolder, "مسلسلات", items.map { Fav(Kind.SERIES, it) }, rowW)
        }
    }

    /**
     * Categories | content | (live only) preview.
     * Live: moving over a channel previews it automatically; OK goes fullscreen.
     */
    private fun showBrowse(kind: Kind) {
        val tok = ++screen; onBack = { showHome() }
        val live = kind == Kind.LIVE
        val icon = if (live) "📺" else if (kind == Kind.MOVIE) "🎬" else "🎞️"
        val dm = resources.displayMetrics
        val wide = live && dm.widthPixels / dm.density >= 640
        val availW = dm.widthPixels - railW
        val paneW = (availW * 0.68).toInt()
        val cols = (paneW / (140 * dm.density)).toInt().coerceIn(2, 8)
        val gap = 16
        val cellW = (paneW - gap * (cols + 1)) / cols

        var ids: List<String> = emptyList()
        var names: List<String> = emptyList()
        val labels = ArrayList<String>()
        var cur = ""
        var all: List<Item> = emptyList()
        var shown: List<Item> = emptyList()
        var focusId = ""
        var wantRows = false
        var pending: Runnable? = null

        val catList = newList()
        catList.adapter = adapter(labels)
        val q = EditText(this).apply {
            hint = "بحث"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine()
            background = fieldBg(); setPadding(32, 20, 32, 20)
        }
        val mic = tile("🎤")
        val grid = GridView(this).apply {
            numColumns = cols; horizontalSpacing = gap; verticalSpacing = gap
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            setPadding(gap, gap, gap, gap); clipToPadding = false
            selector = ColorDrawable(Color.parseColor("#664C8DFF")); isFocusable = true
        }
        val rows = newList()
        val content: View = if (live) rows else grid
        val pkgTitle = TextView(this).apply {
            setTextColor(accent); textSize = 16f; typeface = Typeface.SERIF; setPadding(32, 16, 16, 0)
        }

        // preview pane widgets (wide live only)
        val pvView = PlayerView(this).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT }
        val pvTitle = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.SERIF
            setPadding(0, 16, 0, 8); text = "اختر قناة للمعاينة"
        }
        val pvInfo = TextView(this).apply { setTextColor(accent); textSize = 14f }
        val pvEpg = TextView(this).apply { setTextColor(Color.parseColor("#C9D1DB")); textSize = 15f; setLineSpacing(0f, 1.1f) }
        val pvFav = tile("☆  المفضلة")
        fun updPvFav() {
            val sI = selItem
            pvFav.text = if (sI != null && favs().any { it.kind == kind && it.item.id == sI.id }) "★  بالمفضلة" else "☆  المفضلة"
        }

        fun render() {
            val t = q.text.toString().trim().lowercase()
            val favIds = favs().filter { it.kind == kind }.map { it.item.id }.toSet()
            shown = all.filter { t.isEmpty() || it.name.lowercase().contains(t) }
            if (live) {
                val keep = if (rows.selectedItemPosition >= 0) rows.selectedItemPosition else rows.firstVisiblePosition
                rows.adapter = rowAdapter(shown, favIds) { selId }
                rows.setSelection(keep.coerceIn(0, maxOf(shown.size - 1, 0)))
            } else {
                val pos = grid.firstVisiblePosition
                grid.adapter = posterAdapter(shown, favIds, cellW)
                grid.setSelection(pos)
            }
        }

        fun startPreview(ch: Item) {
            selId = ch.id; selItem = ch
            preview?.play(Xtream.live(user, pass, ch.id))
            pvTitle.text = ch.name; pvEpg.text = "جارٍ تحميل دليل البرامج..."
            loadEpg(ch.id, pvEpg)
            updPvFav()
            (rows.adapter as? BaseAdapter)?.notifyDataSetChanged()
        }

        fun selectCat(i: Int) {
            cur = ids[i]; lastCat[kind] = cur
            for (j in names.indices) labels[j] = (if (j == i) "▶ " else "") + names[j]
            (catList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
            pkgTitle.text = icon + "  " + names[i]
            content.alpha = 0.25f
            all = emptyList(); render()
            val c = cur
            load("it_${kind.name}_${user.hashCode()}_$c", "&action=${kind.listAction}&category_id=$c", tok) { t ->
                if (cur == c) {
                    all = parseItems(kind, t); render()
                    pkgTitle.text = icon + "  " + names[i] + "  •  " + all.size
                    content.animate().alpha(1f).setDuration(300).start()
                    if (wantRows && all.isNotEmpty()) { wantRows = false; content.requestFocus() }
                }
            }
        }

        val clickBack = { showBrowse(kind) }
        val itemClick = AdapterView.OnItemClickListener { _, _, i, _ ->
            val ch = shown[i]
            if (wide) {
                if (ch.id == selId || ch.id == focusId) {
                    pending?.let { ui.removeCallbacks(it) }
                    preview?.stop()
                    openItem(kind, shown, i, clickBack)
                } else {
                    startPreview(ch)
                }
            } else {
                openItem(kind, shown, i, clickBack)
            }
        }
        val itemLong = AdapterView.OnItemLongClickListener { _, _, i, _ ->
            toggleFav(kind, shown[i]); render(); updPvFav(); true
        }
        if (live) {
            rows.onItemClickListener = itemClick; rows.onItemLongClickListener = itemLong
            if (wide) {
                rows.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        if (pos !in shown.indices) return
                        val ch = shown[pos]
                        focusId = ch.id
                        pending?.let { ui.removeCallbacks(it) }
                        val r = Runnable { if (focusId == ch.id && ch.id != selId) startPreview(ch) }
                        pending = r
                        ui.postDelayed(r, 450)
                    }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            }
        } else {
            grid.onItemClickListener = itemClick; grid.onItemLongClickListener = itemLong
        }
        pvFav.setOnClickListener { selItem?.let { toggleFav(kind, it); updPvFav(); render() } }
        catList.setOnItemClickListener { _, _, i, _ -> wantRows = true; selectCat(i) }
        q.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) = render()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        mic.setOnClickListener { startVoice { q.setText(it) } }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(TextView(this).apply {
            text = kind.label; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.SERIF
            setPadding(40, 24, 24, 12)
        })
        left.addView(catList, LinearLayout.LayoutParams(-1, 0, 1f))
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(16, 12, 16, 0) }
        searchRow.addView(q, LinearLayout.LayoutParams(0, -2, 1f))
        searchRow.addView(mic, LinearLayout.LayoutParams(130, 110))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(pkgTitle)
        right.addView(searchRow)
        right.addView(TextView(this).apply {
            text = if (wide) "حرّك على القناة لمعاينتها، واضغط OK للشاشة الكاملة. مطولاً للمفضلة"
            else "اضغط مطولاً على أي عنصر لإضافته للمفضلة"
            setTextColor(Color.GRAY); textSize = 12f; setPadding(32, 4, 16, 0)
        })
        right.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))

        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(bg) }
        if (wide) {
            val pvW = (availW * 0.45).toInt() - 48
            val pane = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
            pane.addView(FrameLayout(this).apply { setBackgroundColor(Color.BLACK); addView(pvView) }, LinearLayout.LayoutParams(-1, pvW * 9 / 16))
            pane.addView(pvTitle)
            pane.addView(pvInfo)
            pane.addView(ScrollView(this).apply { addView(pvEpg) }, LinearLayout.LayoutParams(-1, 0, 1f))
            pane.addView(pvFav, LinearLayout.LayoutParams(-1, 110).apply { topMargin = 8 })
            root.addView(left, LinearLayout.LayoutParams(0, -1, 22f))
            root.addView(right, LinearLayout.LayoutParams(0, -1, 33f))
            root.addView(pane, LinearLayout.LayoutParams(0, -1, 45f))
        } else {
            root.addView(left, LinearLayout.LayoutParams(0, -1, 32f))
            root.addView(right, LinearLayout.LayoutParams(0, -1, 68f))
        }
        setScreen(withRail(if (live) 1 else if (kind == Kind.MOVIE) 2 else 3, root))
        if (wide) {
            val p = AjPlayer(this, true, prefs.getInt("buf", 1), prefs.getBoolean("tunnel", false))
            preview = p
            pvView.player = p.player
            pvInfoTv = pvInfo
            ui.post(infoTick)
        }
        catList.requestFocus()

        load("cats_${kind.name}_${user.hashCode()}", "&action=${kind.catAction}", tok) { t ->
            val arr = JSONArray(t)
            val nid = ArrayList<String>(); val nn = ArrayList<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                nid.add(o.get("category_id").toString()); nn.add(o.getString("category_name"))
            }
            if (nid != ids && nid.isNotEmpty()) {
                ids = nid; names = nn
                labels.clear(); labels.addAll(nn)
                (catList.adapter as ArrayAdapter<*>).notifyDataSetChanged()
                val start = ids.indexOf(lastCat[kind] ?: "").let { if (it >= 0) it else 0 }
                selectCat(start)
                catList.setSelection(start)
            }
        }
    }

    private fun showDetails(kind: Kind, item: Item, back: () -> Unit) {
        val tok = ++screen; onBack = back
        val dm = resources.displayMetrics
        val posterW = (dm.widthPixels * 0.22).toInt().coerceAtLeast(180)
        val posterH = posterW * 3 / 2
        val poster = makePoster(true)
        bindPoster(poster, item, posterW)

        val titleTv = TextView(this).apply { text = item.name; setTextColor(Color.WHITE); textSize = 22f; typeface = Typeface.SERIF; setPadding(0, 8, 0, 8) }
        val metaTv = TextView(this).apply { setTextColor(Color.parseColor("#A9B4C2")); textSize = 15f }
        val plotTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; setPadding(0, 16, 0, 16); setLineSpacing(0f, 1.2f) }
        val playBtn = primaryTile("▶  تشغيل")
        val favBtn = tile("")
        fun updFav() {
            favBtn.text = if (favs().any { it.kind == kind && it.item.id == item.id }) "★  بالمفضلة" else "☆  أضف للمفضلة"
        }
        updFav()
        favBtn.setOnClickListener { toggleFav(kind, item); updFav() }

        val epList = newList()
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 24, 24, 24) }
        left.addView(poster, LinearLayout.LayoutParams(posterW, posterH))
        left.addView(playBtn, LinearLayout.LayoutParams(posterW, 120).apply { topMargin = 24 })
        left.addView(favBtn, LinearLayout.LayoutParams(posterW, 120).apply { topMargin = 12 })
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 40, 24) }
        right.addView(titleTv); right.addView(metaTv)
        if (kind == Kind.SERIES) {
            plotTv.maxLines = 4; plotTv.ellipsize = TextUtils.TruncateAt.END
            right.addView(plotTv); right.addView(epList, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            right.addView(ScrollView(this).apply { addView(plotTv) }, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(bg) }
        root.addView(ScrollView(this).apply { addView(left) }, LinearLayout.LayoutParams(-2, -1))
        root.addView(right, LinearLayout.LayoutParams(0, -1, 1f))
        root.setBackgroundColor(Color.TRANSPARENT)
        val bd = newBackdrop()
        Img.load(item.img, bd, 64)
        setScreen(backdropFrame(bd, root))
        playBtn.requestFocus()

        fun showInfo(o: JSONObject?) {
            if (o == null) return
            val rt = o.str("rating")
            val meta = listOf(
                if (rt.isNotEmpty()) "⭐ $rt" else "",
                o.firstOf("releasedate", "releaseDate", "release_date", "year").take(10),
                o.str("genre"), o.str("duration")
            ).filter { it.isNotEmpty() }
            metaTv.text = meta.joinToString("  •  ")
            val cast = o.str("cast"); val dir = o.str("director")
            plotTv.text = listOf(
                o.firstOf("plot", "description"),
                if (cast.isNotEmpty()) "الممثلون: $cast" else "",
                if (dir.isNotEmpty()) "المخرج: $dir" else ""
            ).filter { it.isNotEmpty() }.joinToString("\n\n")
            val img = o.firstOf("movie_image", "cover")
            if (img.isNotEmpty() && item.img.isEmpty()) {
                Img.load(img, poster.getChildAt(1) as ImageView, posterW)
                Img.load(img, bd, 64)
            }
            val t = o.str("name")
            if (t.isNotEmpty()) titleTv.text = t
        }

        if (kind == Kind.MOVIE) {
            var movieExt = item.ext
            playBtn.setOnClickListener {
                addRecent(Kind.MOVIE, item)
                play(listOf(Xtream.movie(user, pass, item.id, movieExt.ifEmpty { "mp4" })), listOf(item.name), 0, false, listOf(item.img))
            }
            load("vi_${user.hashCode()}_${item.id}", "&action=get_vod_info&vod_id=${item.id}", tok) { t ->
                val r = JSONObject(t)
                showInfo(r.optJSONObject("info"))
                val e = r.optJSONObject("movie_data")?.str("container_extension").orEmpty()
                if (e.isNotEmpty()) movieExt = e
            }
        } else {
            var eps: List<Item> = emptyList()
            fun playEpisodes(list: List<Item>, i: Int) {
                addRecent(Kind.SERIES, item)
                play(
                    list.map { Xtream.episode(user, pass, it.id, it.ext.ifEmpty { "mp4" }) },
                    list.map { item.name + " - " + it.name }, i, false, list.map { item.img }
                )
            }
            playBtn.setOnClickListener { if (eps.isEmpty()) toast("لا توجد حلقات بعد") else playEpisodes(eps, 0) }
            load("ep_${user.hashCode()}_${item.id}", "&action=get_series_info&series_id=${item.id}", tok) { t ->
                val r = JSONObject(t)
                showInfo(r.optJSONObject("info"))
                val raw = r.opt("episodes")
                val seasons = LinkedHashMap<String, JSONArray>()
                if (raw is JSONObject) {
                    raw.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { seasons[it] = raw.getJSONArray(it) }
                } else if (raw is JSONArray) {
                    for (i in 0 until raw.length()) seasons["${i + 1}"] = raw.optJSONArray(i) ?: JSONArray()
                }
                val list = ArrayList<Item>()
                for ((s, arr) in seasons) {
                    for (j in 0 until arr.length()) {
                        val o = arr.getJSONObject(j)
                        val num = o.optString("episode_num", "${j + 1}")
                        val ttl = o.str("title")
                        val label = "الموسم $s - الحلقة $num" + if (ttl.isNotEmpty()) " | $ttl" else ""
                        list.add(Item(o.get("id").toString(), label, o.str("container_extension")))
                    }
                }
                eps = list
                epList.adapter = adapter(list.map { it.name })
                epList.setOnItemClickListener { _, _, i, _ -> playEpisodes(list, i) }
            }
        }
    }

    private fun showFavorites() {
        screen++; onBack = { showHome() }
        val list = newList()
        page("المفضلة  (اضغط مطولاً للحذف)", list, sel = 4)
        list.requestFocus()
        fun render() {
            val fl = favs()
            list.adapter = rowAdapter(fl.map { it.item }, emptySet())
            list.setOnItemClickListener { _, _, i, _ ->
                val f = fl[i]
                if (f.kind == Kind.LIVE) {
                    val l = fl.filter { it.kind == Kind.LIVE }.map { it.item }
                    openItem(Kind.LIVE, l, l.indexOf(f.item)) { showFavorites() }
                } else {
                    openItem(f.kind, listOf(f.item), 0) { showFavorites() }
                }
            }
            list.setOnItemLongClickListener { _, _, i, _ -> toggleFav(fl[i].kind, fl[i].item); render(); true }
        }
        render()
    }

    private fun showAccount() {
        val tok = ++screen; onBack = { showHome() }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 20f; setPadding(64, 32, 64, 32); text = "جارٍ التحميل..."
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(tv)
        box.addView(codeActions(), LinearLayout.LayoutParams(-1, -2).apply { setMargins(48, 0, 48, 0) })
        page("الحساب", box, sel = 5)
        load("acc_${user.hashCode()}", "", tok) { t ->
            val u = JSONObject(t).getJSONObject("user_info")
            val exp = u.optString("exp_date").toLongOrNull()
                ?.let { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it * 1000)) } ?: "غير محدود"
            tv.text = "المستخدم: ${u.optString("username")}\n" +
                "الحالة: ${u.optString("status")}\n" +
                "ينتهي: $exp\n" +
                "الاتصالات: ${u.optString("active_cons")} / ${u.optString("max_connections")}\n" +
                "رمز الجهاز: " + prettyId()
        }
    }

    private fun showSettings() {
        screen++; onBack = { showHome() }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(64, 16, 64, 16) }
        val sizes = arrayOf("صغير", "متوسط", "كبير")
        val buf = tile("")
        fun upd() { buf.text = "حجم تخزين المشغّل المؤقت: " + sizes[prefs.getInt("buf", 1).coerceIn(0, 2)] }
        upd()
        buf.setOnClickListener {
            prefs.edit().putInt("buf", (prefs.getInt("buf", 1) + 1) % 3).apply(); upd()
        }
        val tun = tile("")
        fun updT() { tun.text = "وضع 4K المتقدم (Tunneling): " + if (prefs.getBoolean("tunnel", false)) "مفعّل" else "معطّل" }
        updT()
        tun.setOnClickListener { prefs.edit().putBoolean("tunnel", !prefs.getBoolean("tunnel", false)).apply(); updT() }
        val mq = tile("")
        fun updM() { mq.text = "أعلى جودة دائماً (4K): " + if (prefs.getBoolean("maxq", false)) "مفعّل" else "تلقائي" }
        updM()
        mq.setOnClickListener { prefs.edit().putBoolean("maxq", !prefs.getBoolean("maxq", false)).apply(); updM() }
        val ff = tile("")
        fun updF() { ff.text = "فك الصوت: " + if (prefs.getBoolean("ffaudio", false)) "FFmpeg دائماً" else "تلقائي" }
        updF()
        ff.setOnClickListener { prefs.edit().putBoolean("ffaudio", !prefs.getBoolean("ffaudio", false)).apply(); updF() }
        val steps = intArrayOf(5, 10, 20, 30, 60)
        val sk = tile("")
        fun updS() { sk.text = "خطوة التقديم والترجيع: " + prefs.getInt("seekStep", 10) + " ثانية" }
        updS()
        sk.setOnClickListener {
            val i = steps.indexOf(prefs.getInt("seekStep", 10)).let { if (it < 0) 1 else it }
            prefs.edit().putInt("seekStep", steps[(i + 1) % steps.size]).apply(); updS()
        }
        val aoNames = arrayOf("تلقائي", "AudioTrack", "OpenSL ES")
        val ao = tile("")
        fun updA() { ao.text = "مخرج صوت VLC: " + aoNames[prefs.getInt("vlcAout", 0).coerceIn(0, 2)] }
        updA()
        ao.setOnClickListener { prefs.edit().putInt("vlcAout", (prefs.getInt("vlcAout", 0) + 1) % 3).apply(); updA() }
        val eng = tile("")
        val engNames = arrayOf("تلقائي", "ExoPlayer فقط", "VLC فقط")
        fun updE() {
            eng.text = "المشغّل: " + engNames[prefs.getInt("engine", 0).coerceIn(0, 2)] +
                (if (VlcBridge.available()) "" else "  (VLC غير مضمّن بهالبناء)")
        }
        updE()
        eng.setOnClickListener { prefs.edit().putInt("engine", (prefs.getInt("engine", 0) + 1) % 3).apply(); updE() }
        val info = tile("ℹ️  معلومات البناء")
        info.setOnClickListener {
            val txt = try {
                assets.open("build_info.txt").bufferedReader().use { it.readText() }
            } catch (e: Exception) { "(ما في معلومات بناء)" }
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("معلومات البناء")
                .setMessage("محرك VLC: " + (if (VlcBridge.available()) "مضمّن ✓" else "غير مضمّن ✗") + "\nNextLib / FFmpeg: " + FfmpegInfo.status() + "\n\n" + txt)
                .setPositiveButton("حسناً", null)
                .show()
        }
        val upd = tile("🔄  التحقق من التحديثات")
        upd.setOnClickListener { toast("جارٍ الفحص..."); checkUpdate(true) }
        val clear = tile("مسح الكاش")
        clear.setOnClickListener { cacheDir.listFiles()?.forEach { it.delete() }; toast("تم مسح الكاش") }
        val out = tile("تسجيل الخروج")
        out.setOnClickListener {
            prefs.edit().remove("u").remove("p").putBoolean("loggedout", true).apply()
            cacheDir.listFiles()?.forEach { it.delete() }
            user = ""; pass = ""; showLogin()
        }
        for (b in listOf(buf, tun, mq, ff, sk, eng, ao, upd, info, clear, out)) {
            col.addView(b, LinearLayout.LayoutParams(-1, 130).apply { setMargins(0, 12, 0, 12) })
        }
        col.addView(TextView(this).apply { text = "AJIPTV " + versionName() + "   •   FFmpeg: " + (if (FfmpegInfo.available()) "✓" else "✗"); setTextColor(Color.GRAY); gravity = Gravity.CENTER })
        page("الإعدادات", ScrollView(this).apply { addView(col) }, sel = 6)
        buf.requestFocus()
    }
}

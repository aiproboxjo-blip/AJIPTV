plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// Each GitHub build gets a higher number, so updates install over the old app.
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toInt()

// FFmpeg audio decoders (AC3 / E-AC3 / DTS) are optional. CI passes -Pmedia3=... -PffVer=... and
// tries several matching pairs, then falls back to a plain build.
val ffVer = project.findProperty("ffVer") as String?
// Second playback engine (LibVLC, LGPL). CI passes -PvlcVer=...; without it the app builds as before.
val vlcVer = project.findProperty("vlcVer") as String?
// NextLib: FFmpeg decoders for Media3 (version looks like "1.7.1-0.9.0" = media3 version + NextLib version).
val nextVer = project.findProperty("nextVer") as String?
val media3 = (project.findProperty("media3") as String?) ?: "1.4.1"

android {
    namespace = "com.aj.iptv"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.aj.iptv"; minSdk = 21; targetSdk = 34
        versionCode = 100 + runNo; versionName = "2.2.$runNo"
        ndk { abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a")) }
    }
    if (vlcVer != null) sourceSets.getByName("main").java.srcDir("src/vlc/java")
    signingConfigs {
        create("fixed") {
            val ks = System.getenv("KEYSTORE_FILE")
            if (ks != null) {
                storeFile = file(ks); storeType = "pkcs12"
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("debug") {
            if (System.getenv("KEYSTORE_FILE") != null) signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    // More stream types for IPTV: DASH, RTSP and SmoothStreaming (picked up automatically by ExoPlayer)
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.media3:media3-exoplayer-rtsp:$media3")
    implementation("androidx.media3:media3-exoplayer-smoothstreaming:$media3")
    // FFmpeg software audio decoders (AC3, E-AC3, DTS, TrueHD...) for devices without them
    if (ffVer != null) implementation("org.jellyfin.media3:media3-ffmpeg-decoder:$ffVer")
    if (nextVer != null) implementation("io.github.anilbeesetti:nextlib-media3ext:$nextVer")
    if (vlcVer != null) implementation("org.videolan.android:libvlc-all:$vlcVer")
}
